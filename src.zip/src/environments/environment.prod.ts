export const environment = {
  production: true,
  apiUrl: 'https://dev.api.irisgst.com/irisgst',
  uumUrl: 'https://dev.app.irisgst.com/logout-all-session'
};
