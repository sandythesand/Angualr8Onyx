import { Component, HostListener } from '@angular/core';
import { AuthService } from './auth/services/auth.service';
import { Router } from '@angular/router';
import { ToasterService } from './shared/services/toaster.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'irisgstonyx';
  showHead = false;

  //@HostListener("window:beforeunload",["$event"])
  // clearSessiionStorage(event){
  //     sessionStorage.clear();
  // }

  constructor(
    private auth: AuthService,
    private router: Router,
    private toaster: ToasterService
  ) {
    // this.showheader();
    this.auth.getLoginIndicator().subscribe((value) => {
      if (value === 0) {
        this.showHead = false;
      } else if (value === 1) {
        this.showHead = false;
      } else if (value === 2) {
        this.showHead = true;
      }
    });
  }
}


