export interface ErrorModel {
    field(field: any);
    type: string;
    description: string;
    msg: string;
}
export interface BaseResponse {
    status: string;
    errors: ErrorModel[];
    message: string;
    response: any;
    errorList: ErrorModel[];
}
