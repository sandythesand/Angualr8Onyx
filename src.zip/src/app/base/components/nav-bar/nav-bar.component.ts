import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd, NavigationStart } from '@angular/router';
import { APP_NAME } from '../../../shared/constant'
import { GetterSetterService } from '../../../shared/services/getter-setter.service';
import { StorageService } from '../../../shared/services/storage.service';
import { GenerateService } from '../../../onyx/services/generate.service';
import { BaseResponse } from '../../../models/response';
import { ToasterService } from '../../../shared/services/toaster.service';


@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit {
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  navContext = { entityName: '', isTaxPayer: false, entityType: '' };
  activeLink: string = 'Dashboard';
  role: any;
  flag: boolean;

  constructor(
    private router: Router,
    private GS: GetterSetterService,
    private route: ActivatedRoute
  ) {
    this.APP_NAME = APP_NAME;
    // console.log(this.route, 'ROUTES PARMS')
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        if (event.urlAfterRedirects === '/onyx/dashboard') {
          this.activeLink = 'Dashboard';
        }
      }
    });

  }

  ngOnInit() {
    this.GS.checkEntityType.subscribe((value) => {
      this.navContext = value;
      this.flag = true;
    })
    this.role = this.GS.setGet_UserRole();
  }


  dashboard() {
    this.activeLink = 'Dashboard';
    this.router.navigate([`${this.APP_NAME.ONYX}/dashboard`]);
  }

  upload() {
    this.activeLink = 'Upload';
    this.router.navigate([`${this.APP_NAME.ONYX}/upload`]);
  }

  generate() {
    this.activeLink = 'Generate';
    this.router.navigate([`${this.APP_NAME.ONYX}/generate`]);
  }

  utilities() {
    this.activeLink = 'Utilites';
    this.router.navigate([`${this.APP_NAME.ONYX}/utilities`]);
  }

  mis() {
    this.activeLink = 'MIS';
    this.router.navigate([`${this.APP_NAME.ONYX}/mis`]);
  }
  master() {
    this.activeLink = 'Master';
    this.router.navigate([`${this.APP_NAME.ONYX}/master`]);
  }

  invoiceEditor() {
    this.activeLink = 'invoiceTemp';
    this.router.navigate(['/settings/templates']);
  }
  gotoArchive() {
    this.activeLink = 'goArchive';
    this.router.navigate([`${this.APP_NAME.ONYX}/archive-data`]);
  }
  invoiceRepository() {
    this.activeLink = 'invoiceRepo';
    this.router.navigate([`${this.APP_NAME.ONYX}/invoice-repository`])
  }
  generateHistory() {
    this.router.navigate([`${this.APP_NAME.ONYX}/generate-history`]);
  }

}
