import { Component, OnInit } from '@angular/core';
import { GetterSetterService } from '../../../shared/services/getter-setter.service';
import { GenerateService } from '../../../onyx/services/generate.service';
import { ToasterService } from '../../../shared/services/toaster.service';
import { BaseResponse } from '../../../models/response';
import { StorageService } from '../../../shared/services/storage.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit {
  navContext: any;
  req: any;
  invConsideredCnt: any;
  invSuccessCnt: any;
  invFailCnt: any;
  status: boolean = false;
  downloadPath: any;
  checkStatusFlag: boolean;
  checkDwdFlag: boolean = false;
  isDownloadClick: boolean;
  dwdDisabled: boolean;
  subscription;

  constructor(
    private GS: GetterSetterService,
    private generateServices: GenerateService,
    private toaster: ToasterService,
    private SS: StorageService
  ) { }

  ngOnInit() {
    this.GS.checkEntityType.subscribe((value) => {
      this.navContext = value;
      if (this.navContext.entityType === 'FILING') {
        this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
        this.initialize();
      }
    })
    this.subscription = this.SS.notificationFlag$.subscribe((value) => {
      if (value) {
        this.addClass();
        if (value.type === 'irn') {
          this.status = false;
        } else if (value.type === 'download') {
          this.checkDwdFlag = false;
        }
      }
    })
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }


  addClass() {
    const el = document.getElementById('navigation-bar');
    el.classList.add('show');
  }

  removeClass() {
    const el = document.getElementById('navigation-bar');
    el.classList.remove('show');
  }

  initialize(): any {
    this.checkIRNstatus();
    this.checkDwdStatus();
  }



  checkIRNstatus() {
    let gstin = this.req.gstin;
    this.generateServices.generatedIRNstatus(gstin).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        if (response.response.status === 'COMPLETE') {
          this.invConsideredCnt = response.response.invConsideredCnt;
          this.invSuccessCnt = response.response.invSuccessCnt;
          this.invFailCnt = response.response.invFailCnt;
          this.status = true;
          //this.removeClass();
          this.SS.setBtnFlag({ type: 'generate', disable: false });
        } else if (response.response.status === 'INPROGRESS') {
          this.status = false;
        } else if (response.response.status === 'NEW') {
          this.status = false;
        }
      } else {
        this.toaster.showError(response.message);
      }
    });
  }

  checkDwdStatus() {
    const gstin = this.req.gstin;
    this.generateServices.downloadStatus(gstin).subscribe((response: BaseResponse) => {
      if (response.status === 'SUCCESS') {
        this.downloadPath = response.response.filePath;
        this.checkStatusFlag = false;
        this.checkDwdFlag = true;
        this.isDownloadClick = false;
        this.dwdDisabled = false;
        this.SS.setBtnFlag({ type: 'download', disable: false });
      } else if (response.status === 'INPROGRESS') {
        this.isDownloadClick = true;
        this.checkDwdFlag = false;
        this.dwdDisabled = true;
      } else {
        // this.toaster.showError(response.message);
      }
    })
  }

  downloadFile(downloadPath) {
    this.removeClass();
    window.location.href = downloadPath;
    this.isDownloadClick = false;
    this.checkDwdFlag = true;
  }

}
