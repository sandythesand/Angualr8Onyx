import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TokenService } from '../../../shared/services/token.service';
import { AuthService } from '../../../auth/services/auth.service';
import { Router } from '@angular/router';
import { ToasterService } from '../../../shared/services/toaster.service';
import { BusinessEntityService } from '../../../shared/services/business-entity.service';
import { BaseResponse } from '../../../models/response';
import { GetterSetterService } from '../../../shared/services/getter-setter.service';
import { APP_NAME, UserRoleMap } from '../../../shared/constant';
import { Subject, BehaviorSubject } from 'rxjs';
@Component({
  selector: 'app-business-header',
  templateUrl: './business-header.component.html',
  styleUrls: ['./business-header.component.scss'],
})
export class BusinessHeaderComponent implements OnInit {

  BNBusinessList: any = [];
  subArrowShow: boolean;
  BNSelectedComs: any;
  NavEntityContext: any;
  isRole: any;
  companyId: any;
  BNModel: any;
  businessName: any;
  familyData: any;
  business_role: any;
  count: number;
  gstin_count: number;
  companyList: any;
  gstnMsg: boolean;
  currentUser: String;
  selectedcom: any;
  userRole: any;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  pobCodeForHeader: any;
  allEntity: any;
  pobData: any;

  constructor(
    private tokenService: TokenService,
    private authService: AuthService,
    private router: Router,
    private toaster: ToasterService,
    private entityService: BusinessEntityService,
    private GetSet: GetterSetterService,
    private getterSetter: GetterSetterService,
  ) {
    this.APP_NAME = APP_NAME
    this.userRole = UserRoleMap;
  }

  keyword = "name";

  selectEvent(item) {
    console.log(item);
    if (item) {
          // console.log(this.BNModel);
          if (this.BNModel.childCompanies != null && this.BNModel.childCompanies.length > 0) {
              let parentChildDict = {};
              let childParentList = [];
              let topLevelIds = [];

              for (var i = 0; i < this.BNModel.childCompanies.length; i++)
                  topLevelIds.push(this.BNModel.childCompanies[i].companyId);

              function searchCompany(company) {
                  if (company.companyId == item.id) {
                      return company.companyId;
                  }
                  if(company.childCompanies)
                      if (company.childCompanies.length > 0)
                          for (var i = 0; i < company.childCompanies.length; i++) {
                              // map child to parent.
                              parentChildDict[company.childCompanies[i].companyId] = company.companyId;
                              // call child companies in recursion.
                              searchCompany(company.childCompanies[i]);
                          }
              }
              searchCompany(this.BNModel);
              // var topLevelCompany = this.BNModel.childCompanies.rootCompanyId;
              var company = item.id;

              // iterate to parent of company untill toplevel comoany is found.
              childParentList.push(company);
              if (topLevelIds.indexOf(company) == -1){
                if (topLevelIds.indexOf(parentChildDict[company]) != -1) {
                      company = topLevelIds.indexOf(parentChildDict[company]);
                      childParentList.push(company);
                  } else {
                      while (true) {
                          company = parentChildDict[company];
                          childParentList.push(company);
                          if (topLevelIds.indexOf(parentChildDict[company]) != -1) {
                              company = topLevelIds.indexOf(parentChildDict[company]);
                              break;
                          }
                      }
                  }
              } else {
                  company = topLevelIds.indexOf(company);
              }

              childParentList = childParentList.reverse();

              this.onBNComSelected("", this.BNModel.childCompanies[company], 0);

              var nestedCompany = this.BNModel.childCompanies[company];

              childParentList.forEach((currentCompanyId, index) => {
                if(nestedCompany.childCompanies) {
                  for (var i = 0; i < (nestedCompany.childCompanies?nestedCompany.childCompanies.length: 0); i++) {
                      if (nestedCompany.childCompanies[i].companyId == currentCompanyId) {
                          nestedCompany = nestedCompany.childCompanies[i];
                          this.onBNComSelected("", nestedCompany, index + 1);
                      }
                  }
                }
              });
          }
          // setTimeout(() => {
          //   this.openModelEwb();
          // }, 2000);
  } else {
      console.log('cleared');
  }
  }

  onChangeSearch(search: string) {
    // fetch remote data from here
    // And reassign the 'data' which is binded to 'data' property.
  }

  onFocused(e) {
    // do something
  }

  ngOnInit() {
    this.initializeData();
    // this.initializeEntityList();
  }

  initializeData() {
    this.currentUser = sessionStorage.getItem('user');
    // let cmpId = sessionStorage.getItem('companyId');
    // this.changeBusiness(sessionStorage.getItem('companyId'));
    this.GotoUserDash();
  }

  initializeEntityList() {
    this.entityService.fetchEntity().subscribe((response: BaseResponse) => {
      if (response.status === 'SUCCESS') {
        this.BNBusinessList = response.response;
      }
    })
  }

  GotoUserDash() {
    this.NavEntityContext = { entityName: '', isTaxPayer: false, entityType: 'Business' };
    this.getSetNavContext(this.NavEntityContext);
    this.BNModel = {};
    this.subArrowShow = true;
    this.BNSelectedComs = [];
    this.getBusinessHierarchy();
    if (this.GetSet.getSetCompanyId()) {
      this.viewBusinessHierarchy(this.GetSet.getSetCompanyId());

    }
    this.router.navigate([`${this.APP_NAME.ONYX}`]);
  }

  navigateDashboard() {
    this.router.navigate([`${this.APP_NAME.ONYX}`]);
  }

  GotoDash(com) {
    this.isRole = com.roleName;
    this.BNSelectedComs = [];
    let businessHierarchy = this.viewBusinessHierarchy(this.GetSet.getSetCompanyId());

    this.NavEntityContext = { entityName: '', isTaxPayer: false, entityType: 'Business' };
    if(this.NavEntityContext && com.entityType == 'BUSINESS') {
      this.NavEntityContext.pan = com.pan;
    }
    this.getSetNavContext(this.NavEntityContext);
    this.gstnMsg = false;
    this.router.navigate([`${this.APP_NAME.ONYX}`]);
  }

  validateGstn(gstinno) {
    if (gstinno != null) {
      this.entityService.validateGstnSessionUrl(gstinno).subscribe((response: BaseResponse) => {
        if (response && response.status == 'SUCCESS' && response.response != null) {
          if (response.response.nicCredentialsVerified == 'N') {
            this.gstnMsg = true;
          } else {
            this.gstnMsg = false;
          }
        } else {
          this.gstnMsg = true;
        }
        this.setgstnConnection(!this.gstnMsg);
      }, (e) => {
        this.toaster.showError("Network Error" + e);
      })
    } else {
      this.gstnMsg = false;
    }
    //}
  }

  getSetNavContext(navContext?) {
    if (navContext) {
      // console.log('IF', navContext);
      sessionStorage.setItem('navContext', JSON.stringify(navContext));
      // this.getterSetter.checkEntityType.next(navContext);
      this.getterSetter.setBusinessData(navContext);
    } else {
      navContext = JSON.parse(sessionStorage.getItem('navContext'));
      if (!navContext) {
        navContext = { entityName: '', isTaxPayer: false }
      }
    }
    return navContext;
  }

  setgstnConnection(value) {
    if (value) {
      sessionStorage.setItem("gstnCon", value);
    } else {
      sessionStorage.setItem("gstnCon", 'false');
    }
  }

  changeBusiness(companyId) {
    // console.log('Change business');
    if (companyId) {
      this.entityService.changeCompany(companyId).subscribe((response: BaseResponse) => {
        this.BNSelectedComs = [];
        if (response.status === 'SUCCESS') {
          if (response.response && response.response.length > 0 && response.response[0].companyid) {
            let companyId = response.response[0].companyid;
            let company = response.response[0].company;
            this.NavEntityContext = { entityName: '', isTaxPayer: false, entityType: 'Business' };
            this.getSetNavContext(this.NavEntityContext);
            this.subArrowShow = true;
            this.GetSet.getSetCompanyId(companyId);
            this.GetSet.getSetCompany(company);
            this.viewBusinessHierarchy(companyId);
            this.getBusinessHierarchy();
            if(response.response[0].products.length > 0) {
              this.GetSet.setProduct(response.response[0].products);
            }
            this.toaster.showSuccess(response.message);
            this.router.navigate([`${this.APP_NAME.ONYX}`]);
          }
        } else {
          this.toaster.showInfo(response)
        }
      }, (err) => {
        this.toaster.showError("Network Error!");
      });
    }
  }


  findCompanyObj(comId, obj) {
    return obj.find((com) => {
      if (comId == com.companyId)
        return com;
    }
    );
  }

  selectAllChildVal(item, childNodes) {
    if (item.childCompanies != null && item.childCompanies.length > 0) {
      for (var i = 0; i < item.childCompanies.length; i++) {
        if (item.childCompanies[i].roleName == 'Admin' || item.childCompanies[i].roleName == 'Preparer' ||
          item.childCompanies[i].roleName == 'Signatory' || item.childCompanies[i].roleName == 'Guest'
          || item.childCompanies[i].roleName == 'Maker') {
          childNodes.push({
            'name': item.childCompanies[i].companyName,
            'id': item.childCompanies[i].companyId
          });
        }

        this.selectAllChildVal(item.childCompanies[i], childNodes);
      }
      this.allEntity = childNodes;
    }
  }


  getBusinessHierarchy() {
    let cmpId = sessionStorage.getItem('companyId');
    this.entityService.fetchEntity().subscribe((response: BaseResponse) => {
      this.BNBusinessList = response.response;
      this.BNBusinessList.sort((a,b) => a.company.localeCompare(b.company));
      if (cmpId) {
        this.entityService.fetchBusinessHierarchy(cmpId).subscribe((response: BaseResponse) => {
          this.BNModel = response.response;
          this.isRole = response.response.roleName;
          this.GetSet.setGet_UserRole(this.isRole);
          this.selectAllChildVal(this.BNModel, []);
          if(this.NavEntityContext && this.BNModel.entityType == 'BUSINESS') {
            this.NavEntityContext.pan = this.BNModel.pan;
          }
          if(this.BNModel.childCompanies != undefined) {
            var leng = Object.keys(this.BNModel.childCompanies).length;
            for (var i = 0; i < leng; i++) {
              this.showPath(this.BNModel.childCompanies[i]);
            }
            this.BNModel.childCompanies.sort((a,b) => a.companyName.localeCompare(b.companyName));
          }
          this.getSetNavContext(this.NavEntityContext);

          if (this.NavEntityContext && this.NavEntityContext.companyId) {
            this.companyId = this.NavEntityContext.companyId;
            var navCompanies = this.BNModel;
            this.BNSelectedComs = [];
            for (var i = 0; i < this.NavEntityContext.navBarHierarchy.length; i++) {
              navCompanies = this.findCompanyObj(this.NavEntityContext.navBarHierarchy[i], navCompanies.childCompanies);
              if (navCompanies.childCompanies != '' && navCompanies.childCompanies != null) {
                for (var j = 0; j < navCompanies.childCompanies.length; j++) {
                  this.showPath(navCompanies.childCompanies[j]);
                }
              }
              this.BNSelectedComs.push(navCompanies);
            }
          }
        }, (err) => {
          this.toaster.showError("Network Error");
        });
      }
    });
  }

  viewBusinessHierarchy(cmpId?, com?) {
    // console.log(cmpId, com, 'POPOP')
    if (com) {
      this.businessName = com.companyName;
      this.familyData = com;
      this.business_role = com.roleName;
      this.isRole = com.roleName;
      if (com.childCompanies != '') {
        this.countG(com.childCompanies);
      } else {
        this.countG([com], false);
      }
    } else if (cmpId) {
      this.entityService.fetchBusinessHierarchy(cmpId).subscribe((response: BaseResponse) => {
        if (response.status == 'SUCCESS' && response.response != null) {
          this.businessName = response.response.companyName;
          this.familyData = response.response;
          this.business_role = response.response.roleName;

          if (response.response != null && response.response.childCompanies == '') {
            this.countG([response.response]);
          } else if (response.response) {
            this.countG(response.response.childCompanies);
          } else {
            this.gstin_count = 0;
          }
        } else {
          this.gstin_count = 0;
        }
        this.NavEntityContext = this.getSetNavContext();
        if (this.NavEntityContext && this.NavEntityContext.companyId) {
          if (this.NavEntityContext.childCompaniesNo) {
            this.gstin_count = this.NavEntityContext.childCompaniesNo;
          }
          this.companyId = this.NavEntityContext.companyId;
          let compHierarchy = this.familyData;
          let businessHierarchy;
          for (var i = 0; i < this.NavEntityContext.navBarHierarchy.length; i++) {
            compHierarchy = this.findCompanyObj(this.NavEntityContext.navBarHierarchy[i], compHierarchy.childCompanies);
            businessHierarchy = compHierarchy;
          }
          this.familyData = businessHierarchy;
        }

      }, (err) => {
        this.toaster.showError("Network Error");
      });
    } else {
      this.toaster.showError("No Business Entity found!");
    }
  }

  countG(obj?, isRecursive?) {

    if (!isRecursive) {
      this.count = 0;
    }
    if(obj != undefined) {
      var leng = Object.keys(obj).length;
    for (var i = 0; i < leng; i++) {
      if (obj[i].entityType == "FILING" && obj[i].roleName != 'NoRole') {
        this.count++;
      } else if (obj[i].entityType == "LEGAL") {
        this.countG(obj[i].childCompanies, true);
      }
    }
    }

    this.gstin_count = this.count;
    this.NavEntityContext.childCompaniesNo = this.count;
  }

  showPath = function (obj) {
    if (obj.roleName != 'NoRole') {
      if (obj.childCompanies != null && obj.childCompanies.length > 0) {
        var l = Object.keys(obj.childCompanies).length;
      }
      for (var i = 0; i < l; i++) {
        var state = this.showPath(obj.childCompanies[i]);
        if (state == true) {
          return obj.visible = true;
        }
      }
      return obj.visible = true;
    } else {
      if (obj.childCompanies != null && obj.childCompanies.length > 0) {
        var l = Object.keys(obj.childCompanies).length;
      }
      for (var i = 0; i < l; i++) {
        var state = this.showPath(obj.childCompanies[i]);
        if (state == true) {
          return obj.visible = true;
        }
      }
      return obj.visible = false;
    }
  }


  onBNComSelected(companyName, com, index) {
    // console.log('ON BN COM SELECTED')
    this.isRole = com.roleName;
    if (com.entityType == "FILING") {
      sessionStorage.setItem('filingEntityName', companyName);
    }
    if(this.NavEntityContext && com.entityType == 'LEGAL') {
        this.NavEntityContext.pan = com.pan;
    }
    this.getSetNavContext(this.NavEntityContext);
    if (index == 0) {
      this.BNSelectedComs = [];
      this.NavEntityContext.navBarHierarchy = [];
    }
    for (var i = 0; i < this.BNSelectedComs.length; i++) {
      var isAvail = this.BNSelectedComs.findIndex(function (e) {
        if (com.parentCompanyId == e.parentCompanyId)
          return true
      });
      if (isAvail != -1) {
        this.BNSelectedComs.pop();
        this.NavEntityContext.navBarHierarchy.pop();
      }
    }
    if (com.childCompanies != null && com.childCompanies.length > 0) {
      for (var i = 0; i < com.childCompanies.length; i++) {
        this.showPath(com.childCompanies[i]);
      }
    }
    this.BNSelectedComs.push(com);
    if(com.entityType == "FILING") {
      this.entityService.setPobVal(com.childCompanies);
    }
    if(com.entityType === 'LEGAL') {
      this.entityService.setLegalHierarchy(com.childCompanies);
    }
    this.entityService.fetchFillingBusiness().subscribe((response: BaseResponse) => {
      if (response.status == 'FAILURE') {
        this.toaster.showError(response.errors[0].field);
      } else if (response.status == 'SUCCESS') {
        this.companyList = response.response;
        if (com.entityType == 'FILING') {
          var L = this.companyList.find((rt) => {
            if (rt.id == com.companyId)
              return rt;
          });
          this.getSetFilling(L);
          this.GoToDashboard(com, true, L);
        } else {
          this.GoToDashboard(com, true);
        }
      }
    });
  }
  GoToDashboard(com, isForward, selectedCompObj?): any {
    let companyId;
    //        debugger;
    if (!isForward) {
      for (var i = this.NavEntityContext.navBarHierarchy.length - 1; i > 0; i--) {
        if (this.NavEntityContext.navBarHierarchy[i] != com.companyId) {
          this.NavEntityContext.navBarHierarchy.pop();
        }
      }
      for (var i = this.BNSelectedComs.length - 1; i > 0; i--) {
        if (this.BNSelectedComs[i].companyId != com.companyId) {
          this.BNSelectedComs.pop();
        } else
          break;
      }
    }
    this.NavEntityContext.entityType = com.entityType;
    if (this.NavEntityContext.navBarHierarchy) {
      if (this.NavEntityContext.navBarHierarchy.indexOf(com.companyId) == -1)
        this.NavEntityContext.navBarHierarchy.push(com.companyId);
    }
    this.NavEntityContext.isTaxPayer = false;

    if (com.entityType == 'FILING') {
      //            console.log(JSON.stringify(LS.get('selectedFilling')!=null ? LS.get('selectedFilling').gstin:null));
      this.NavEntityContext.isTaxPayer = true;
      this.validateGstn(JSON.parse(sessionStorage.getItem('selectedFilling')) != null ? JSON.parse(sessionStorage.getItem('selectedFilling')).gstin : null);
      if (isForward)
        this.NavEntityContext.gstin = selectedCompObj.gstin;
    } else {
      this.validateGstn(null);
    }
    this.NavEntityContext.entityName = com.companyName;
    if(com.pobCode) {
      this.NavEntityContext.pobCode = com.pobCode;
      this.pobCodeForHeader = com.pobCode;
    } else {
      this.NavEntityContext.pobCode = null;
      this.pobCodeForHeader = '';
    }
    if (com.companyId) {
      this.NavEntityContext.companyId = com.companyId;
      companyId = com.companyId;
    } else {
      companyId = this.GetSet.getSetCompanyId();
    }
    this.selectedcom = com;
    this.viewBusinessHierarchy(companyId, com);

    this.getSetNavContext(this.NavEntityContext);
    this.router.navigate([`${this.APP_NAME.ONYX}`]);

  }

  getSetFilling(selectedFilling) {
    if (selectedFilling) {
      sessionStorage.setItem('selectedFilling', JSON.stringify(selectedFilling));
    } else {
      selectedFilling = JSON.parse(sessionStorage.getItem('selectedFilling'));
    }
    return selectedFilling;
  }

  addBusiness() {
    this.router.navigate(['add-business']);
  }

  getCompanyList() {
    this.authService.comapnyList().subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {

      } else {
        this.toaster.showError(response.message)
      }
    });
  }

  settings(familyDataVal: any) {
    this.getterSetter.setViewHierarchyData(familyDataVal);
    this.router.navigate(['settings']);
  }

  logout() {
    if (this.tokenService.destroy()) {
      this.authService.setLoginIndicator(0);
      window.open(this.tokenService.getUumUrl(), '_self');
      // this.router.navigate(['login']);
    } else {
      this.toaster.showError('Something Went wrong !');
    }
  }

  myPreference(data: any) {
    // console.log(data, '[DARA');
    this.router.navigate([`${this.APP_NAME.ONYX}/preference`]);
  }

}
