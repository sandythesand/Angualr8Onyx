import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { BusinessService } from 'src/app/businessManagement/services/business.service';

@Injectable({
  providedIn: 'root'
  })
  export class ImageResolverService implements Resolve<any> {
    constructor(private bms: BusinessService) { }
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      return this.bms.fetchImages();
    }
  }
