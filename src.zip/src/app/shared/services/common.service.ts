import { Injectable } from '@angular/core';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  filingPeriodData: any;
  constructor() { }

  getFilingPeriod() {
    // return [
    //   {key: 'Mar-2020', value: '032020'},
    //   {key: 'Feb-2020', value: '022020'},
    //   {key: 'Jan-2020', value: '012020'},
    // ]
    var filingPeriodDates = [];
    var d = new Date();
    //IF DATE IS AFTER
    var temp;
    var regDate = "2020-01-01";
    var finalVal = moment(d).diff(moment(regDate), 'months', true);
    while (finalVal > 0) {
      temp = regDate;
      filingPeriodDates.push({ name: moment(temp).format("MMM-YYYY"), value: moment(temp).format("MMYYYY") });
      temp = moment(regDate).add(1, 'M').format('YYYY-MM-DD');
      regDate = temp;
      finalVal--;
    }
    return filingPeriodDates.reverse();
  }
  
  getFilingPeriodForReport() {
    var filingPeriodDates = [];
    var d = new Date();
    //IF DATE IS AFTER
    var temp;
    var regDate = "2020-10-01";
    var finalVal = moment(d).diff(moment(regDate), 'months', true);
    while (finalVal > 0) {
      temp = regDate;
      filingPeriodDates.push({ name: moment(temp).format("MMM-YYYY"), value: moment(temp).format("MMYYYY") });
      temp = moment(regDate).add(1, 'M').format('YYYY-MM-DD');
      regDate = temp;
      finalVal--;
    }
    return filingPeriodDates.reverse();
  }

  setFillingPeriodData() {
    //TODO this feature started from 1st of october 2020
    let regDate = '2020-01-01';
    var filingPeriodDates = [];
    var d = new Date();
    var res = moment(regDate).isSame(d);
    if (res) {
        return false;
    } else {
        //IF DATE IS AFTER
        var temp;
        var julyDate = "2020-01-01";
        if (moment(regDate).isBefore(julyDate)) {
            regDate = julyDate;
        }

        var finalVal = moment(d).diff(moment(regDate), 'years', true);

        while (finalVal > 0) {
            temp = regDate;
            filingPeriodDates.push({name: moment(temp).format("YYYY"), value: moment(temp).format("YYYY")});

            temp = moment(regDate).add(1, 'years').format('YYYY-MM-DD');

            regDate = temp;
            finalVal--;
        }
    }
    return filingPeriodDates.reverse();
}
}
