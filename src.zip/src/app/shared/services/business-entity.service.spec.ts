import { TestBed } from '@angular/core/testing';

import { BusinessEntityService } from './business-entity.service';

describe('BusinessEntityService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BusinessEntityService = TestBed.get(BusinessEntityService);
    expect(service).toBeTruthy();
  });
});
