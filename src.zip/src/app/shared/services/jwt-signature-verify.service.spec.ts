import { TestBed } from '@angular/core/testing';

//import { JwtSignatureVerifyService } from './jwt-signature-verify.service';

describe('JwtSignatureVerifyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    //const service: JwtSignatureVerifyService = TestBed.get(JwtSignatureVerifyService);
    //expect(service).toBeTruthy();
  });
});
