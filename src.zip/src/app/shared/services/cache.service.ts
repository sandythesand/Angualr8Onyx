import { Injectable } from '@angular/core';
import { HttpRequest, HttpResponse } from '@angular/common/http';

const maxAge = 3600000;
@Injectable({
  providedIn: 'root'
})
export class RequestCache {

  cache = new Map();


  get(req: HttpRequest<any>): HttpResponse<any> | undefined {
    const url = req.urlWithParams;
    // console.log(url, 'LKLLK')
    const cached = this.cache.get(url);
    // const cached = this.cache;
    if (!cached) {
      return undefined;
    }
    // return cached;
    const isExpired = cached.lastRead < (Date.now() - maxAge);
    // console.log('Returning from cache ' + req.url);
    return isExpired ? undefined : cached.response;
  }

  put(req: HttpRequest<any>, response: HttpResponse<any>): void {
    const url = req.urlWithParams.split('=')[1];
    // const entry = { url, response, lastRead: Date.now() };
    this.cache.set(url, response);
    console.log(this.cache, 'JUST NOW');
    const expired = Date.now() - maxAge;
    this.cache.forEach(expiredEntry => {
      if (expiredEntry.lastRead < expired) {
        this.cache.delete(expiredEntry.urlWithParams);
      }
    });
  }

  reset() {
    this.cache = new Map();
  }

  resetByURL(url) {
    this.cache.delete(url);
  }
}
