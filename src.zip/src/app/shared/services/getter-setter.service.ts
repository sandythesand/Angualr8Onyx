import { Injectable } from '@angular/core';
import { UserRoleMap } from '../constant';
import { Subject, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GetterSetterService {

  userRole = UserRoleMap;
  // checkEntityType = new BehaviorSubject<any>(JSON.parse(sessionStorage.getItem('navContext')));
  checkEntityType = new BehaviorSubject<any>(null);

  constructor() { }

  setGet_UserRole(roleId?: any) {
    if (roleId) {
      let role = this.userRole[roleId];
      sessionStorage.setItem('role', role.role);
    } else {
      return sessionStorage.getItem('role');
    }
  }

  getSetCompany(company?) {
    if (company) {
      sessionStorage.setItem('company', company);
    } else {
      company = sessionStorage.getItem('company');
    }
    return company;
  }


  getSetCompanyId(companyid?) {
    if (companyid) {
      sessionStorage.setItem('companyId', companyid);
    } else {
      companyid = sessionStorage.getItem('companyId');
    }
    return companyid;
  }

  getSetUser(user) {
    if (user) {
      sessionStorage.setItem('user', user);
    } else {
      user = sessionStorage.getItem('user');
    }
    return user;
  }

  getSetUserId(UserId?) {
    if (UserId) {
      sessionStorage.setItem('UserId', UserId);
    } else {
      UserId = sessionStorage.getItem('UserId');
    }
    return UserId;
  }

  getNavContextData() {
    return sessionStorage.getItem('navContext');
  }

  setProduct(product) {
    return sessionStorage.setItem('products', product);
  }

  getSetFilingGstin(gstinData: any) {
    if (gstinData) {
      sessionStorage.setItem('filingGstn', gstinData);
    } else {
      gstinData = sessionStorage.getItem('filingGstn');
    }
    return gstinData;
  }

  getSetfilingEntityName(data?: any) {
    if (data) {
      sessionStorage.setItem('filingEntityName', data);
    } else {
      data = sessionStorage.getItem('filingEntityName');
    }
    return data;
  }

  setViewHierarchyData(data: any) {
    sessionStorage.setItem('viewHierarchy_id', data.companyId);
    sessionStorage.setItem('viewHierarchy_entityType', data.entityType);
    sessionStorage.setItem('viewHierarchy_name', data.companyName);
  }
  getviewHierarchy_id() {
    return sessionStorage.getItem('viewHierarchy_id');
  }
  getviewHierarchy_name() {
    return sessionStorage.getItem('viewHierarchy_name');
  }
  setBusinessData(data) {
    this.checkEntityType.next(data);
  }
  getBusinessData() {
    return this.checkEntityType.asObservable();
  }
}
