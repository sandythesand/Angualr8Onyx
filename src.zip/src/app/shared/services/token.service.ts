import { Injectable } from '@angular/core';
import * as jwt_decode from 'jwt-decode';
import { GetterSetterService } from './getter-setter.service';
import { environment } from '../../../environments/environment';

@Injectable()

export class TokenService {

  constructor(
    private GetSet: GetterSetterService
  ) {

  }


  getter() {
    return sessionStorage.getItem('jwtToken');
  }

  setter(data) {
    sessionStorage.setItem('jwtToken', data.token);
    sessionStorage.setItem('logintoken', data.token);
    // sessionStorage.setItem('userId', data.email);
    this.GetSet.getSetUserId(data.email)
    this.GetSet.getSetCompanyId(data.companyid)
    return 1;
  }

  getTokenExpirationDate(token: string): Date {
    const decoded = jwt_decode(token);
    if (decoded['exp'] === undefined) { return null; }
    const date = new Date(0);
    date.setUTCSeconds(decoded['exp']);
    return date;
  }

  isTokenExpired(token?: string): boolean {
    if (!token) { token = this.getter(); }
    if (!token) { return true; }

    const date = this.getTokenExpirationDate(token);
    if (date === undefined) { return false; }
    return !(date.valueOf() > new Date().valueOf());
  }

  destroy() {
    sessionStorage.clear();
    return true;
  }

  getUumUrl() {
    return environment.uumUrl;
  }
} 