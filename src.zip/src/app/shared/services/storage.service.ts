import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  SatusData$ = new BehaviorSubject<any>({ irnFlag: false, downloadFlag: false });
  notificationFlag$ = new BehaviorSubject<any>(null);
  btnFlag$ = new BehaviorSubject<any>(null);

  constructor() { }

  setIRNSatusFlag(data) {
    this.SatusData$.next(data);
  }
  getIRNSatusFlag() {
    return this.SatusData$.asObservable();
  }

  setNotifyFlag(data) {
    this.notificationFlag$.next(data);
  }
  getNotifyFlag() {
    return this.notificationFlag$.asObservable();
  }
  setBtnFlag(data) {
    this.btnFlag$.next(data);
  }
  getBtnFlag() {
    return this.btnFlag$.asObservable();
  }
}
