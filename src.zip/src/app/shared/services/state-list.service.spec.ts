import { TestBed } from '@angular/core/testing';

import { StateListService } from './state-list.service';

describe('StateListService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StateListService = TestBed.get(StateListService);
    expect(service).toBeTruthy();
  });
});
