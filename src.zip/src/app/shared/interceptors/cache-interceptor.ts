import { Injectable } from '@angular/core';
import { HttpEvent, HttpRequest, HttpResponse, HttpInterceptor, HttpHandler } from '@angular/common/http';


import { startWith, tap } from 'rxjs/operators';

import { Observable, of } from 'rxjs';
import { RequestCache } from '../services/cache.service';


const urlsToCache = ['onyx/download/structErrors'];

@Injectable()
export class CachingInterceptor implements HttpInterceptor {
    constructor(private cache: RequestCache) { }

    intercept(req: HttpRequest<any>, next: HttpHandler) {
        const cachedResponse = this.cache.get(req);
        console.log(cachedResponse, 'CACHEDRESPONSE');
        return cachedResponse ? of(cachedResponse) : this.sendRequest(req, next, this.cache);
    }

    sendRequest(
        req: HttpRequest<any>,
        next: HttpHandler,
        cache: RequestCache): Observable<HttpEvent<any>> {
        return next.handle(req).pipe(
            tap(event => {
                if (event instanceof HttpResponse) {
                    if (this.contains(req.urlWithParams, urlsToCache)) {
                        cache.put(req, event);
                    }
                }
            })
        );
    }

    contains(target, pattern) {
        let value = 0;
        pattern.forEach((word) => {
            value = value + target.includes(word);
        });
        return (value === 1);
    }
}
