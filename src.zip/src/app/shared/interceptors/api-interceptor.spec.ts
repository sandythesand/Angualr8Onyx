// import { ApiInterceptor } from './api-interceptor';

// describe('ApiInterceptor', () => {
//   it('should create an instance', () => {
//     expect(new ApiInterceptor()).toBeTruthy();
//   });
// });
