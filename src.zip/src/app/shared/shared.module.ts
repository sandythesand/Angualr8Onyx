import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import { FileUploadModule } from 'ng2-file-upload';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { NgxPaginationModule } from 'ngx-pagination';
import { PaginatorModule } from 'primeng/paginator';
import { MultiSelectModule } from 'primeng/multiselect';
import { CalendarModule } from 'primeng/calendar';
import { RadioButtonModule } from 'primeng/radiobutton';
import { NoDataFoundComponent } from '../base/components/no-data-found/no-data-found.component';
import { SelectButtonModule } from 'primeng/selectbutton';
import { ChartsModule } from 'ng2-charts';
import { NgSelectModule } from '@ng-select/ng-select';
import { ClickOutsideModule } from 'ng-click-outside';
@NgModule({
  declarations: [
    NoDataFoundComponent,
  ],
  imports: [
    CommonModule,
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
    }),
    FormsModule,
    ReactiveFormsModule,
    FileUploadModule,
    TableModule,
    DropdownModule,
    ButtonModule,
    NgxPaginationModule,
    PaginatorModule,
    MultiSelectModule,
    CalendarModule,
    RadioButtonModule,
    SelectButtonModule,
    ChartsModule,
    NgSelectModule,
    ClickOutsideModule
  ],
  exports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ToastrModule,
    DataTablesModule,
    FileUploadModule,
    TableModule,
    DropdownModule,
    ButtonModule,
    NgxPaginationModule,
    PaginatorModule,
    MultiSelectModule,
    CalendarModule,
    RadioButtonModule,
    NoDataFoundComponent,
    SelectButtonModule,
    ChartsModule,
    NgSelectModule
  ]
})
export class SharedModule { }
