import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UploadComponent } from './onyx/upload/upload.component';
import { BulkUploadComponent } from './onyx/bulk-upload/bulk-upload.component';
import {
  LoginComponent,
  SignupComponent,
  SetPasswordComponent,
  ForgotPasswordComponent
} from "./auth"
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { AuthService } from './auth/services/auth.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ApiInterceptor } from './shared/interceptors/api-interceptor';
import { TokenService } from './shared/services/token.service';
import { ToasterService } from './shared/services/toaster.service';
import { ThankyouComponent } from './auth/components/thankyou/thankyou.component';
import { CompleteRegistrationComponent } from './auth/components/complete-registration/complete-registration.component';
import { ResetPasswordComponent } from './auth/components/reset-password/reset-password.component';
import { AddBusinessComponent } from './businessManagement/components/add-business/add-business.component';
import { SharedModule } from './shared/shared.module';
import { OnyxComponent } from './onyx/onyx.component';
import { ReactiveFormsModule } from '@angular/forms';
import {
  BusinessHeaderComponent,
  NavBarComponent,
  FooterComponent
} from './base';
import { DatePipe } from '@angular/common';
import { LoaderComponent } from './base/components/loader/loader.component';
import { CachingInterceptor } from './shared/interceptors/cache-interceptor';
import { ChartsModule } from 'ng2-charts';
import { NotificationsComponent } from './base/components/notifications/notifications.component';
import { ClickOutsideModule } from 'ng-click-outside';
import { ChangePasswordComponent } from './auth/components/change-password/change-password.component';
import { TokenVerifyComponent } from './auth/components/token-verify/token-verify.component';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
@NgModule({
  declarations: [
    AppComponent,
    BulkUploadComponent,
    // DashboardComponent,
    LoginComponent,
    SignupComponent,
    SetPasswordComponent,
    ForgotPasswordComponent,
    BusinessHeaderComponent,
    ThankyouComponent,
    CompleteRegistrationComponent,
    ResetPasswordComponent,
    AddBusinessComponent,
    FooterComponent,
    NavBarComponent,
    OnyxComponent,
    LoaderComponent,
    NotificationsComponent,
    ChangePasswordComponent,
    TokenVerifyComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    SharedModule,
    ReactiveFormsModule,
    ChartsModule,
    ClickOutsideModule,
    AutocompleteLibModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ApiInterceptor,
      multi: true
    },
    // {
    //   provide: HTTP_INTERCEPTORS,
    //   useClass: CachingInterceptor,
    //   multi: true
    // },
    TokenService,
    AuthService,
    ToasterService,
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
