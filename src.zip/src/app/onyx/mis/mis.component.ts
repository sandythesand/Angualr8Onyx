import { DatePipe } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { BaseResponse } from "src/app/models/response";
import { MIS_REPORT_3_TYPE } from "src/app/shared/constant";
import { BusinessEntityService } from "src/app/shared/services/business-entity.service";
import { CommonService } from "src/app/shared/services/common.service";
import { ToasterService } from "src/app/shared/services/toaster.service";
import { GenerateService } from "../services/generate.service";

@Component({
  selector: "app-mis",
  templateUrl: "./mis.component.html",
  styleUrls: ["./mis.component.scss"],
})
export class MisComponent implements OnInit {
  getNavContext: any;
  allCount: any;
  report1IsData: boolean = false;
  report1noData: boolean = false;;
  bsEntitySubscribe: any;
  gstinData: any;
  dropdownList: any = [];
  gstinReport2: any;
  filingData: any;
  docMonthReport2: any;
  allReport2: any = [];
  noDataFound: boolean = false;
  userGstin: any;
  report2Link: any;
  statusFlag: boolean = false;
  noDataFoundReport3History: boolean = false;
  selectedTab: any;
  report3History: any = [];
  noDataFoundReport3View: boolean = false;
  report3View: any = [];
  report3Type: { name: string; val: string }[];
  report3Link: any;
  reserveReport3Data: any = null;
  dropdownSettings = {};
  selectedItems = [];
  dropdownListReport3 = [];
  maxDate = new Date();
  currentYear: number;
  docToDate: Date;
  fromUpDt: Date;
  toUpDt: Date;
  isDisable: boolean = false;
  req: any;
  readOnly: boolean = false;

  constructor(
    private generateServices: GenerateService,
    private bsEntity: BusinessEntityService,
    private getCommonService: CommonService,
    private toaster: ToasterService,
    private datePipe: DatePipe
  ) {}

  ngOnInit() {
    this.getNavContext = JSON.parse(sessionStorage.getItem("navContext"));
    this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
    this.currentYear = (new Date()).getFullYear();
    if (this.getNavContext.entityType == "Business" || this.getNavContext.entityType == "FILING") {
    this.bsEntitySubscribe = this.bsEntity
      .fetchFillingBusiness()
      .subscribe((value: any) => {
        if (value) {
          this.gstinData = value.response;
          if (this.gstinData.length > 0) {
            this.gstinData.forEach((e) => {
              this.dropdownList.push({
                value: e.companyname,
                key: e.gstinno,
              });
              this.dropdownListReport3.push({
                item_text: e.companyname,
                item_id: e.gstinno,
              });
            });
          }
          if (this.getNavContext.entityType == "FILING") {
            this.readOnly = true;
            this.gstinReport2 = this.req.gstinno;
          } else {
            this.readOnly = false;
            this.gstinReport2 = this.dropdownList[0].key;
          }
        }
      });
    }
      if (this.getNavContext.entityType == "LEGAL") {
        this.dropdownListReport3 = [];
        this.gstinData = [];
        this.bsEntity.getLegalVal().subscribe((value) => {
          if(value) {
            this.gstinData = value.data;
              if(this.gstinData.length > 0) {
                this.gstinData.forEach(e=> {
                  if(e.entityType == 'FILING') {
                    this.dropdownList.push({
                      value: e.companyName,
                      key: e.gstin,
                    });
                    this.dropdownListReport3.push({
                      item_text: e.companyName,
                      item_id: e.gstin,
                    });
                  }
                })
              }
              this.readOnly = false;
              this.gstinReport2 = this.dropdownList[0].key;
          }
        })
      }

    this.dropdownSettings = {
      singleSelection: false,
      idField: "item_id",
      textField: "item_text",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 4,
      allowSearchFilter: true,
    };

    this.maxDate.setDate(this.maxDate.getDate() - 1);
    this.report3Type = MIS_REPORT_3_TYPE;
    this.getReport1();
    this.filingData = this.getCommonService.getFilingPeriodForReport();
    this.getReport3History();
  }

  getReport1() {
    let model = {};
    if (this.getNavContext.entityType == "FILING") {
      model["companyUniqueCode"] = this.getNavContext.gstin;
    } else {
      model["companyUniqueCode"] = this.getNavContext.pan;
    }
    this.generateServices
      .getAllReport1Count(model)
      .subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          //this.allCount = response.response;
          this.getReport1Status();
        }
      });
  }

  getReport1Status(){
    let model = {};
    if (this.getNavContext.entityType == "FILING") {
      model["companyUniqueCode"] = this.getNavContext.gstin;
    } else {
      model["companyUniqueCode"] = this.getNavContext.pan;
    }
    this.generateServices.getAllReport1Status(model).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.allCount = response.response;
            if(response.message == "Data Found"){
              this.report1IsData = true;
            }else{
              this.report1noData = true
            }
          }
      });
  }
  dateSelection(type) {
    if (type == "docDt") {
      this.docToDate = new Date(this.fromUpDt);
      this.toUpDt = null;
    }
  }

  getReport3History() {
    let model = {};
    model["email"] = sessionStorage.getItem("UserId");
    if (this.getNavContext.entityType == "FILING") {
      model["companyUniqueCode"] = this.getNavContext.gstin;
    } else {
      model["companyUniqueCode"] = this.getNavContext.pan;
    }
    this.generateServices
      .report3History(model)
      .subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.report3History = response.response;
          this.noDataFoundReport3History = false;
          this.viewReport3(this.report3History[0]);
        } else {
          this.noDataFoundReport3History = true;
        }
      });
  }

  getReport3HistoryRefresh() {
    let model = {};
    model["email"] = sessionStorage.getItem("UserId");
    if (this.getNavContext.entityType == "FILING") {
      model["companyUniqueCode"] = this.getNavContext.gstin;
    } else {
      model["companyUniqueCode"] = this.getNavContext.pan;
    }
    this.generateServices
      .report3History(model)
      .subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.report3History = response.response;
          this.noDataFoundReport3History = false;
        } else {
          this.noDataFoundReport3History = true;
        }
      });
  }

  viewReport3(historyData) {
    this.reserveReport3Data = historyData;
    this.selectedTab = "tab1";
    let model = {};
    model["id"] = historyData.id;
    this.generateServices
      .report3SingleView(model)
      .subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.report3View = response.response;
          // this.report3View.forEach((element) => {
          //   element.catVal = this.report3Type.find(
          //     (x: { val: any }) => x.val === element.section
          //   ).name;
          // });
          this.noDataFoundReport3View = false;
        } else {
          this.noDataFoundReport3View = true;
        }
      });
  }

  checkReport2Val() {
    let model = {};
    if (this.gstinReport2 && this.docMonthReport2) {
      model["companyUniqueCode"] = this.gstinReport2;
      model["docMonth"] = this.docMonthReport2;
      this.generateServices
        .getAllReport2(model)
        .subscribe((response: BaseResponse) => {
          if (response.status == "SUCCESS") {
            this.allReport2 = response.response;
            this.noDataFound = false;
          } else {
            this.allReport2 = [];
            this.noDataFound = true;
          }
        });
    }
  }

  report2Download() {
    let model = {};
    if (this.gstinReport2 && this.docMonthReport2) {
      model["userGstin"] = this.gstinReport2;
      model["docMonth"] = this.docMonthReport2;
      this.generateServices
        .downloadReport2(model)
        .subscribe((response: BaseResponse) => {
          if (response.status == "SUCCESS") {
            this.report2Link = response.response;
            this.openLink(this.report2Link);
          } else {
            this.noDataFound = true;
          }
        });
    }
  }
  report3Download(item?) {
    if (item == undefined) {
      item = this.reserveReport3Data;
    }
    let model = {};
    model["id"] = item.id;
    if(item) {
      this.generateServices
      .downloadReport3(model)
      .subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.report3Link = response.response;
          this.openLink(this.report3Link);
        }
      });
    }

  }

  generateReport2() {
    let model = {};
    if (this.gstinReport2 && this.docMonthReport2) {
      model["companyUniqueCode"] = this.gstinReport2;
      model["docMonth"] = this.docMonthReport2;
      this.generateServices
        .generatetAllReport2(model)
        .subscribe((response: BaseResponse) => {
          if (response.status == "SUCCESS") {
            this.toaster.showSuccess(response.message);
            setTimeout(() => {
              this.checkReport2Val();
            }, 2000);
          }
        });
    }
  }

  generateReport3() {
    let model = {};
    let req = {};
    let finalGstin: any = [];
    if (this.selectedItems.length > 0) {
      this.selectedItems.forEach((element) => {
        finalGstin.push(element.item_id);
      });
    } else {
      this.toaster.showWarning("Select at least single GSTIN");
      return;
    }
    if (this.fromUpDt && this.toUpDt) {
      model["gstinArr"] = finalGstin;
      let dateDiff = this.differenceValGet(this.toUpDt, this.fromUpDt);
      if (dateDiff > 31) {
        this.toaster.showWarning("Date range should not be more than 31 days");
        return;
      }
      this.isDisable = true;
      model["irnGenToDate"] = this.datePipe.transform(
        this.toUpDt,
        "dd/MM/yyyy"
      );
      model["irnGenFromDate"] = this.datePipe.transform(
        this.fromUpDt,
        "dd/MM/yyyy"
      );
      if (this.getNavContext.entityType == "FILING") {
        req["companyUniqueCode"] = this.getNavContext.gstin;
      } else {
        req["companyUniqueCode"] = this.getNavContext.pan;
      }
      this.generateServices
        .genReport3(model, req)
        .subscribe((response: BaseResponse) => {
          this.isDisable = false;
          if (response.status == "SUCCESS") {
            this.toaster.showSuccess(response.message);
          } else {
            this.toaster.showError(response.message);
          }
        });
    }
  }

  differenceValGet(tDt, fDt) {
    if (tDt && fDt) {
      var Difference_In_Time = tDt.getTime() - fDt.getTime();
      return Difference_In_Time / (1000 * 3600 * 24);
    }
  }

  openLink(url) {
    window.open(url, "_blank");
  }

  tabChanged(tab, check?) {
    this.selectedTab = tab;
    if(tab === 'tab2') {
      this.getReport3HistoryRefresh();
    }
    if(tab === 'tab1') {
      this.toUpDt = null;
      this.fromUpDt = null;
      this.selectedItems = [];
    }
  }
}
