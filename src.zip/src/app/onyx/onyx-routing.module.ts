import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { APP_NAME } from '../shared/constant';
import { AuthGuard } from '../auth/guards/auth.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UploadComponent } from './upload/upload.component';
import { ViewInvoiceComponent } from './generate/view-invoice/view-invoice.component';
import { ViewSummaryComponent } from './generate/view-summary/view-summary.component';
import { GenerateHistoryComponent } from './generate/generate-history/generate-history.component';
import { ViewAllSummaryComponent } from './generate/view-all-summary/view-all-summary.component';
import { PrintSummaryComponent } from './generate/print-summary/print-summary.component';
import { UtilitiesComponent } from './utilities/utilities.component';
import { PreferenceComponent } from '../businessManagement/components/preference/preference.component';
import { InvoiceRepositoryComponent } from './invoice-repository/invoice-repository.component';
import { BulkPrintComponent } from './generate/bulk-print/bulk-print.component';
import { ArchiveDataComponent } from './archive-data/archive-data.component';
import { MisComponent } from './mis/mis.component';
import { MasterComponent } from './master/master.component';

const routes: Routes = [
    {
        path: 'dashboard',
        canActivate: [AuthGuard],
        component: DashboardComponent
    },
    {
        path: 'upload',
        canActivate: [AuthGuard],
        component: UploadComponent
    },
    {
        path: 'generate',
        canActivate: [AuthGuard],
        component: ViewInvoiceComponent
    },
    {
        path: 'view-invoice-summary/:invoiceId',
        canActivate: [AuthGuard],
        component: ViewSummaryComponent
    },
    {
        path: 'generate-history',
        canActivate: [AuthGuard],
        component: GenerateHistoryComponent
    },
    {
        path: 'archive-data',
        canActivate: [AuthGuard],
        component: ArchiveDataComponent
    },
    {
        path: 'mis',
        canActivate: [AuthGuard],
        component: MisComponent
    },
    {
        path: 'master',
        canActivate: [AuthGuard],
        component: MasterComponent
    },
    {
        path: 'bulk-print-history',
        canActivate: [AuthGuard],
        component: BulkPrintComponent
    },
    {
        path: 'view-invoice-all-summary/:invoiceId',
        canActivate: [AuthGuard],
        component: ViewAllSummaryComponent
    },
    {
        path: 'print-summary/:invoiceId',
        canActivate: [AuthGuard],
        component: PrintSummaryComponent
    },
    {
        path: 'preference',
        canActivate: [AuthGuard],
        loadChildren: () => import('../businessManagement/components/preference/preference.module').then(m => m.PreferenceModule)
    },
    {
        path: 'utilities',
        canActivate: [AuthGuard],
        component: UtilitiesComponent
    },
    {
        path: 'invoice-repository',
        canActivate: [AuthGuard],
        component: InvoiceRepositoryComponent
    },
    {
        path: '',
        redirectTo: `dashboard`,
        pathMatch: 'full',
    },
    {
        path: '',
        redirectTo: `${APP_NAME.ONYX}/upload`,
        pathMatch: 'full',
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)]
})
export class OnyxRoutingModule { }
