import { TestBed } from '@angular/core/testing';

import { IrnServiceService } from './irn-service.service';

describe('IrnServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IrnServiceService = TestBed.get(IrnServiceService);
    expect(service).toBeTruthy();
  });
});
