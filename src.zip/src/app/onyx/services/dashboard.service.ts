import { Injectable } from '@angular/core';
import { APP_NAME } from 'src/app/shared/constant';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})

export class DashboardService {

  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };

  constructor(
    private http: HttpClient,
  ) {
    this.APP_NAME = APP_NAME;
   }
   
  getInvCount(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/invCounts?`, {
      params: {
        cmpId: data
      }
    }).pipe(map((resp) => {
      return resp;
    }));
  }
  getGCCount(compID, endDate) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/irnGenCount?cmpId=${compID}&days=7&endDate=${endDate}`).pipe(map((resp) => {
      return resp;
    }));
  }
}
