import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class IrnServiceService {

  constructor(
    private http: HttpClient
  ) { }

  getIrnData(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/irn/getInvByIrn?userGstin=${data.userGstin}&irn=${data.irn}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getGstinData(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/utilities/getGstinDetails?userGstin=${data.userGstin}&searchGstin=${data.searchGstin}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getGstinCpData(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/utilities/getCpGstinDetails?userGstin=${data.userGstin}&searchGstin=${data.searchGstin}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getIrnDocData(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/irn/getIrnByDocDetails?userGstin=${data.userGstin}&docType=${data.docType}&docNum=${data.docNum}&docDate=${data.docDate}`).pipe(map((resp) => {
      return resp;
    }));
  }

  getIrnEwbData(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/irn/getEwbByIrn?userGstin=${data.userGstin}&irn=${data.irn}&updateFlag=${data.updateFlag}`).pipe(map((resp) => {
      return resp;
    }));
  }


  getqrData(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/einvoice/verifySignature`, data).pipe(map((response) => {
      return response;
    }));
  }
}
