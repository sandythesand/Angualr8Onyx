import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class InvoiceRepoServiceService {

  constructor(
    private http: HttpClient
  ) { }

  downloadGstr1Initiate(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/download/gstr1`, data).pipe(map((response) => {
      return response;
    }));
  }
  downloadEwbInitiate(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/download/ewb`, data).pipe(map((response) => {
      return response;
    }));
  }
  downloadEwbInitiateBulk(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/download/pan/einvoices`, data).pipe(map((response) => {
      return response;
    }));
  }
  downloadStatus(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/download/status?companyCode=${data.gstin}&downloadType=${data.type}`).pipe(map((response) => {
      return response;
    }));
  }
  getBulkDownloadHis(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/download/pan/view?companyCode=${data.companyCode}&page=${data.page}&size=${data.size}`).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadStatusBulk(data: any){
    return this.http.get(`${environment.apiUrl}/onyx/download/pan/status?downloadId=${data.downloadId}&companyCode=${data.companyCode}`).pipe(map((resp) => {
      return resp;
    }));
  }
}
