import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { APP_NAME } from 'src/app/shared/constant';

@Injectable({
  providedIn: 'root'
})
export class UploadService {
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };

  constructor(
    private http: HttpClient
  ) {
    this.APP_NAME = APP_NAME;
  }

  getUploadHistory(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/upload/history?companyUniqueCode=${data.code}&page=${data.page}&size=${data.size}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getUploadHistoryMaster(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/upload/vendorMaster/history?companyUniqueCode=${data.code}&page=${data.page}&size=${data.size}`).pipe(map((resp) => {
      return resp;
    }));
  }

  getBusinessDetails(data: any) {
    return this.http.get(`${environment.apiUrl}/mgmt/company/business?companyid=${data}`).pipe(map((resp) => {
      return resp;
    }));
  }

  getErrorDetails(uploadId, page, size) {
    return this.http.get(`${environment.apiUrl}/onyx/upload/errors?uploadId=${uploadId}&page=${page}&size=${size}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getErrorDetailsMaster(uploadId, page, size) {
    return this.http.get(`${environment.apiUrl}/onyx/upload/vendorMaster/errors?uploadId=${uploadId}&page=${page}&size=${size}`).pipe(map((resp) => {
      return resp;
    }));
  }
  uploadFile(formdata: FormData, gstn): Observable<any> {
    return this.http.post(`${environment.apiUrl}/onyx/upload/invoices?companyUniqueCode=${gstn}`, formdata).pipe(
      map((response) => {
        return response;
      }));
  }
  uploadFileMaster(formdata: FormData, gstn): Observable<any> {
    return this.http.post(`${environment.apiUrl}/onyx/upload/vendorMaster?companyUniqueCode=${gstn}`, formdata).pipe(
      map((response) => {
        return response;
      }));
  }
  downloadFile(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/download/genUploadResponse`, data).pipe(map((resp) => {
      return resp;
    }));
  }
  fetchMasterView(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/vendor/upload/view`, data).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadStatus(uploadId){
    return this.http.get(`${environment.apiUrl}/onyx/download/structErrors/status?uploadId=${uploadId}&downloadType=STRUCT_ERROR`).pipe(map((resp) => {
      return resp;
    }));
  }
  fetchDetails(data: any){
    return this.http.get(`${environment.apiUrl}/mgmt/user/company/assignedEntities?userMailId=${data.email}&companyId=${data.companyId}`).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadMaster(data: any){
    return this.http.post(`${environment.apiUrl}/onyx/vendor/download`, data, {responseType: 'blob'}).pipe(map((resp) => {
      return resp;
    }));
  }
  fetchDetailsVendorMaster(data: any){
    return this.http.post(`${environment.apiUrl}/onyx/vendor/fetchData`, data).pipe(map((resp) => {
      return resp;
    }));
  }

  deleteInvoices(data) {
    const options = {
      headers : new HttpHeaders({
        'Content-Type' : 'application/json'
      }),
      body:  data,
    };
    return this.http.delete(`${environment.apiUrl}/onyx/vendor/delete`, options).pipe(map((response) => {
      return response;
    }));
  }
}
