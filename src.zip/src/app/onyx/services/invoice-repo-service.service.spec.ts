import { TestBed } from '@angular/core/testing';

import { InvoiceRepoServiceService } from './invoice-repo-service.service';

describe('InvoiceRepoServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InvoiceRepoServiceService = TestBed.get(InvoiceRepoServiceService);
    expect(service).toBeTruthy();
  });
});
