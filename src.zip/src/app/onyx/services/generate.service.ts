import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GenerateService {

  pageData = new BehaviorSubject<any>({ page: 0, size: 50, tab: 'tab1' });
  defaultFilterData$ = new BehaviorSubject<any>({});
  checkMailSuccess$ = new Subject<any>();

  constructor(
    private http: HttpClient
  ) { }

  getGenView(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/einvoice/view`, data).pipe(map((response) => {
      return response;
    }));
  }
  getArchView(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/einvoice/history/view`, data).pipe(map((response) => {
      return response;
    }));
  }
  genReport3(data: any, req: any) {
    return this.http.post(`${environment.apiUrl}/onyx/mis/countIrnStatusWise?companyUniqueCode=${req.companyUniqueCode}`, data).pipe(map((response) => {
      return response;
    }));
  }
  getInvoiceSummary(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/sumDetails?einvId=${data}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getInvoiceArchSummary(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/history/sumDetails?einvId=${data}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getAllReport1Count(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/mis/countGenCnlIrns?companyUniqueCode=${data.companyUniqueCode}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getAllReport1Status(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/mis/report1/status?companyUniqueCode=${data.companyUniqueCode}`).pipe(map((resp) => {
      return resp;
    }));
  }
  report3History(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/mis/history/view?email=${data.email}&companyUniqueCode=${data.companyUniqueCode}`).pipe(map((resp) => {
      return resp;
    }));
  }
  report3SingleView(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/mis/countIrnStatusWise/view?id=${data.id}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getAllReport2(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/mis/countGstinWiseInv/view?companyUniqueCode=${data.companyUniqueCode}&docMonth=${data.docMonth}`).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadReport2(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/mis/report2/download?userGstin=${data.userGstin}&docMonth=${data.docMonth}`).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadReport3(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/mis/report3/download?id=${data.id}`).pipe(map((resp) => {
      return resp;
    }));
  }
  generatetAllReport2(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/mis/countGstinWiseInv?companyUniqueCode=${data.companyUniqueCode}&docMonth=${data.docMonth}`).pipe(map((resp) => {
      return resp;
    }));
  }

  getAllInvoiceName() {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/template/activeTemplates`).pipe(map((resp) => {
      return resp;
    }));
  }

  generateIRN(data) {
    return this.http.post(`${environment.apiUrl}/onyx/irn/generate`, data).pipe(map((response) => {
      return response;
    }));
  }

  bulkPrint(data, tmpName, tmpEsignVal) {
    return this.http.post(`${environment.apiUrl}/onyx/einvoice/bulkprint/generatePDF?template=${tmpName}&esignReq=${tmpEsignVal}&companyUniqueId=${data.companyUniqueCode}`, data.invId).pipe(map((response) => {
      return response;
    }));
  }
  getEsignLink(id) {
    return this.http.post(`${environment.apiUrl}/onyx/einvoice/esign/grouping?id=${id}`,null).pipe(map((response) => {
      return response;
    }));
  }
  bulkArchPrint(data, tmpName, gstin) {
    return this.http.post(`${environment.apiUrl}/onyx/einvoice/history/bulkprint/generatePDF?template=${tmpName}&companyUniqueId=${gstin}`, data).pipe(map((response) => {
      return response;
    }));
  }

  generatedIRNstatus(gstn) {
    return this.http.get(`${environment.apiUrl}/onyx/irn/generate/status?userGstin=${gstn}`).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadFileStatus(req) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/bulkprint/status?id=${req.id}&esignFlag=${req.esignFlag}`).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadBulkPrintFile(id) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/bulkprint/download?id=${id.id}&esignFlag=0`,{ responseType: 'blob' }).pipe(map((resp) => {
      return resp;
    }));
  }
  getBulkPrintHistory(data) {
    // let headers = new HttpHeaders({'companyUniqueId': data.companyUniqueCode});
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/bulkprint/history?page=${data.page}&size=${data.size}&companyUniqueId=${data.companyUniqueCode}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getBulkPrintHistoryEinvoice(data) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/esign/history?page=${data.page}&size=${data.size}&companyUniqueId=${data.companyUniqueCode}`).pipe(map((resp) => {
      return resp;
    }));
  }
  cancelIrnData(data: any) {
    return this.http.put(`${environment.apiUrl}/onyx/irn/cancel`, data).pipe(map((resp) => {
      return resp;
    }));
  }
  cancelEwbData(data: any) {
    return this.http.put(`${environment.apiUrl}/onyx/irn/cancelEwb`, data).pipe(map((resp) => {
      return resp;
    }));
  }
  getGenHistory(data) {
    return this.http.get(`${environment.apiUrl}/onyx/irn/generate/history?userGstin=${data.gstin}&page=${data.page}&size=${data.size}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getInvoiceAllSummary(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/details?einvId=${data}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getInvoiceAllSummaryArch(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/history/details?einvId=${data}`).pipe(map((resp) => {
      return resp;
    }));
  }
  setPageData(data) {
    this.pageData.next(data);
  }
  getPageData() {
    return this.pageData.asObservable();
  }

  setDefaultData(data) {
    this.defaultFilterData$.next(data);
  }

  getDefaultData() {
    return this.defaultFilterData$.asObservable();
  }

  downloadEnv(data) {
    return this.http.post(`${environment.apiUrl}/onyx/download/einvoices`, data).pipe(map((response) => {
      return response;
    }));
  }
  downloadRes(data) {
    return this.http.post(`${environment.apiUrl}/onyx/download/downloadEinvInRes`, data).pipe(map((response) => {
      return response;
    }));
  }
  downloadResArchive(data) {
    return this.http.post(`${environment.apiUrl}/onyx/download/history/downloadEinvInRes`, data).pipe(map((response) => {
      return response;
    }));
  }
  downloadEsign(data,gstin) {
    return this.http.post(`${environment.apiUrl}/onyx/einvoice/print/download?companyCode=${gstin}`, data).pipe(map((response) => {
      return response;
    }));
  }
  downloadEsignArchive(data,gstin) {
    return this.http.post(`${environment.apiUrl}/onyx/einvoice/print/download?companyCode=${gstin}&archive=1`, data).pipe(map((response) => {
      return response;
    }));
  }
  downloadArchEnv(data) {
    return this.http.post(`${environment.apiUrl}/onyx/download/history/einvoices`, data).pipe(map((response) => {
      return response;
    }));
  }
  downloadStatus(companyCode) {
    return this.http.get(`${environment.apiUrl}/onyx/download/status?companyCode=${companyCode}&downloadType=EINV_DATA`).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadStatusRes(companyCode) {
    return this.http.get(`${environment.apiUrl}/onyx/download/status?companyCode=${companyCode}&downloadType=EINV_RES_FORMAT`).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadStatusResArchive(companyCode) {
    return this.http.get(`${environment.apiUrl}/onyx/download/status?companyCode=${companyCode}&downloadType=EINV_HIS_RES_FORMAT`).pipe(map((resp) => {
      return resp;
    }));
  }
  downloadStatusEsign(companyCode) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/print/status?companyCode=${companyCode}&downloadType=PRINT_EINV`).pipe(map((resp) => {
      return resp;
    }));
  }

  checkSendMail(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/mail/buildAttachment`, data).pipe(map((response) => {
      return response;
    }));
  }
  checkSendMailArch(data: any) {
    return this.http.post(`${environment.apiUrl}/onyx/mail/history/buildAttachment`, data).pipe(map((response) => {
      return response;
    }));
  }

  sendMailStatus(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/mail/attachment/status?gstin=${data.gstin}&type=${data.type}`).pipe(map((resp) => {
      return resp;
    }));
  }
  getMailIds(data: any) {
    return this.http.get(`${environment.apiUrl}/onyx/vendor/gstinMailIds?gstin=${data.gstin}&ctin=${data.ctin}&category=${data.category}`).pipe(map((resp) => {
      return resp;
    }));
  }

  sendReadyMail(data: any) {
    return this.http.post(`${environment.apiUrl}/mgmt/mail/sendMailWithoutAttach`, data).pipe(map((resp) => {
      return resp;
    }));
  }

  getPrintPDF(id, name) {
    // print invoice with id in pdf format
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/print?id=${id}&template=${name}`,
    { responseType: 'blob' }).pipe(map((resp) => {
      return resp;
    }));
  }
  getPrintArchPDF(id, name) {
    // print invoice with id in pdf format
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/history/print?id=${id}&template=${name}`,
    { responseType: 'blob' }).pipe(map((resp) => {
      return resp;
    }));
  }
  deleteIRN(data) {
    const options = {
      headers : new HttpHeaders({
        'Content-Type' : 'application/json'
      }),
      body:  data,
    };
    return this.http.delete(`${environment.apiUrl}/onyx/einvoice/delete`, options).pipe(map((response) => {
      return response;
    }));
  }
}



