import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdvanceFilterService {

  constructor(
    private http: HttpClient,
  ) { }

  fetchData(userid) {
    return this.http.get(`${environment.apiUrl}/onyx/einvoice/pref?userEmail=${userid}`).pipe(map((resp) => {
      return resp;
    }));
  }
}
