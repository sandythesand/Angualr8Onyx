import { NgModule } from '@angular/core';
import { OnyxRoutingModule } from './onyx-routing.module';
import { OnyxComponent } from './onyx.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SharedModule } from '../shared/shared.module';
import { UploadComponent } from './upload/upload.component';
import { ViewInvoiceComponent } from './generate/view-invoice/view-invoice.component';
import { FilterComponent } from './generate/filter/filter.component';
import { ViewSummaryComponent } from './generate/view-summary/view-summary.component';
import { GenerateHistoryComponent } from './generate/generate-history/generate-history.component';
import { ViewAllSummaryComponent } from './generate/view-all-summary/view-all-summary.component';
import { PrintSummaryComponent } from './generate/print-summary/print-summary.component';
import { ActionListComponent } from './generate/action-list/action-list.component';
import { Ng2PageScrollModule } from 'ng2-page-scroll';
import { UtilitiesComponent } from './utilities/utilities.component';
import { SendMailComponent } from './generate/send-mail/send-mail.component';
import { EditorModule } from '@tinymce/tinymce-angular';
import { PreferenceComponent } from '../businessManagement/components/preference/preference.component';
import { PreferenceModule } from '../businessManagement/components/preference/preference.module';
import { AdvanceFilterComponent } from './generate/advance-filter/advance-filter.component';
import { ClickOutsideModule } from 'ng-click-outside';
import { InvoiceRepositoryComponent } from './invoice-repository/invoice-repository.component';
import { BulkPrintComponent } from './generate/bulk-print/bulk-print.component';
import { ArchiveDataComponent } from './archive-data/archive-data.component';
import { ArchiveFilterComponent } from './generate/filter/archive-filter/archive-filter.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { MisComponent } from './mis/mis.component';
import { MasterComponent } from './master/master.component';
import { VendorMasterFilterComponent } from './generate/filter/vendor-master-filter/vendor-master-filter.component';

@NgModule({
    declarations: [
        DashboardComponent,
        UploadComponent,
        ViewInvoiceComponent,
        FilterComponent,
        ViewSummaryComponent,
        GenerateHistoryComponent,
        ViewAllSummaryComponent,
        PrintSummaryComponent,
        ActionListComponent,
        UtilitiesComponent,
        SendMailComponent,
        AdvanceFilterComponent,
        InvoiceRepositoryComponent,
        BulkPrintComponent,
        ArchiveDataComponent,
        ArchiveFilterComponent,
        MisComponent,
        MasterComponent,
        VendorMasterFilterComponent
    ],
    imports: [
        // OnyxComponent,
        OnyxRoutingModule,
        SharedModule,
        Ng2PageScrollModule,
        EditorModule,
        PreferenceModule,
        ClickOutsideModule,
        NgMultiSelectDropDownModule.forRoot()

    ]
})
export class OnyxModule { }
