import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label, Color } from 'ng2-charts';
import { BaseResponse } from '../../models/response';
import { DatePipe } from '@angular/common';
import { DashboardService } from '../services/dashboard.service';
import { ToasterService } from '../../shared/services/toaster.service';
import { GetterSetterService } from '../../shared/services/getter-setter.service';
import _ from 'lodash';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  @Output() setInvCounttoCompany = new EventEmitter<string>();

  navContData: any = { entityName: "", isTaxPayer: false, entityType: "Business" };
  invCount: any = [];
  compID: any;
  endDt: any;
  GCData: any;
  toDate: any;
  endDate: any;
  count = 1;



  barChartOptions: ChartOptions = {
    responsive: true,

    // We use these empty structures as placeholders for dynamic theming.
    scales: {
      xAxes: [{}], yAxes: [{
        ticks: {
          beginAtZero: true,

        }
      }]
    },
    plugins: {
      datalabels: {
        anchor: 'end',
        align: 'end',
      }
    }

  };


  barChartLabels: Label[] = [];
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];


  barChartData: ChartDataSets[] = [];

  barChartColors: Color[] = [
    // { backgroundColor: '#ff5d55' },
    // { backgroundColor: '#3d8af7' },
  ]


  generatedBar: any = [];
  cancelBar: any = [];
  isVisible: boolean = false;
  subscription;

  constructor(
    private dashboardService: DashboardService,
    private toaster: ToasterService,
    private getterSetter: GetterSetterService,
    private datePipe: DatePipe,
  ) {
  }

  ngOnInit() {
    this.subscription = this.getterSetter.getBusinessData().subscribe((value) => {
      this.navContData = value;
      // this.initiateInvCount();
      // this.initiateGCCount();
    })

  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

  chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

  initiateInvCount() {
    if (this.navContData.entityType == 'Business') {
      this.compID = this.getterSetter.getSetCompanyId();
    } else {
      this.compID = this.navContData.companyId;
    }
    this.invCount = [];
    this.dashboardService.getInvCount(this.compID).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.invCount = response.response;
      } else {
        this.toaster.showError('No Data Found');
      }
    });

  }

  initiateGCCount() {
    if (this.navContData.entityType == 'Business') {
      this.compID = this.getterSetter.getSetCompanyId();
    } else {
      this.compID = this.navContData.companyId;
    }
    this.toDate = new Date();
    this.endDate = this.datePipe.transform(this.toDate, 'dd-MM-yyyy');
    this.barChartLabels = [];
    this.generatedBar = [];
    this.cancelBar = [];
    this.barChartData = [];
    this.dashboardService.getGCCount(this.compID, this.endDate).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.isVisible = true;
        this.GCData = response.response;
        if (this.GCData.length > 0) {
          this.GCData.forEach((ele) => {
            this.barChartLabels.push(ele.genDate);
            this.generatedBar.push(ele.activeIrnCount);
            this.cancelBar.push(ele.cancelIrnCount);
          });
          this.barChartData.push(
            { data: this.cancelBar, label: 'Cancel' },
            { data: this.generatedBar, label: 'Active' }
          );
          this.barChartColors.push(
            { backgroundColor: '#ff5d55' },
            { backgroundColor: '#78bd5a' }
          );
        }
      } else {
        this.toaster.showError(response.message);
      }
    });

  }

}
