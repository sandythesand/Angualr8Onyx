import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { paginationPrams } from '../../shared/constant';
import { BaseResponse } from '../../models/response';
import { UploadService } from '../services/upload.service';
import { Component, OnInit, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { ToasterService } from '../../shared/services/toaster.service';
import { GetterSetterService } from '../../shared/services/getter-setter.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent implements OnInit {
  uploader: FileUploader;
  @ViewChild(DataTableDirective, { static: false })

  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  uploadHistoryList: any = [];
  req: any;
  isBulkUpload: boolean = false;
  errorList: any = [];
  collection: any = [];
  code: any;
  p: any
  page: number = 0;
  size: number = paginationPrams.pageLen;
  size1: number = paginationPrams.pageLen;
  rows: number;
  pageOption: any;
  errorId: any;
  totalElementsVal: any;
  noDataFound: Boolean = false;
  navContData: any;
  compID: any;
  isClickable: boolean = false;
  page1: number = 0;

  formData: FormData = new FormData();
  @ViewChild('file', { static: false }) file: ElementRef;
  totalElementsValUploadHistory: any;
  isDisable: boolean = false;

  constructor(
    private uploadService: UploadService,
    private toaster: ToasterService,
    private getSet: GetterSetterService
  ) {
    for (let i = 1; i <= 100; i++) {
      this.collection.push(`item ${i}`);
    }
    this.rows = paginationPrams.pageLen;
    this.pageOption = paginationPrams.pageOption;
  }
  response: string;
  selectedFile = null;


  ngOnInit() {
    this.navContData = JSON.parse(this.getSet.getNavContextData());
    if (this.navContData.entityType == 'Business') {
      this.compID = this.getSet.getSetCompanyId();
    } else {
      this.compID = this.navContData.companyId;
    }
    if (this.navContData.entityType == 'Business' || this.navContData.entityType == 'LEGAL') {
      // this.getBusinessDetails();
      this.code = this.navContData.pan;
      this.initializeUploadHistory();
    } else {
      this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
      this.code = this.req.gstin;
      this.initializeUploadHistory();
    }
  }

  getBusinessDetails() {
    this.uploadService.getBusinessDetails(this.compID).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.code = response.response.panNo;
        this.initializeUploadHistory();
      } else {
        this.toaster.showError(response.message);
      }
    });
  }

  initializeUploadHistory() {
    if (this.code != null) {
      let req = {
        code: this.code,
        page: this.page1,
        size: this.size1
      }
      this.uploadService.getUploadHistory(req).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.uploadHistoryList = response.response.data;
          this.totalElementsValUploadHistory = response.response.totalElements;
          this.dtTrigger.next();
          if (this.uploadHistoryList.length === 0) {
            this.noDataFound = true;
          }
        } else {
          this.toaster.showError(response.message);
          this.noDataFound = true;
        }
      });
    } else {
      this.toaster.showError('GSTIN number not found.');
    }
  }

  errorDetail(uploadId, page?, size?) {
    this.page = 0;
    this.errorId = uploadId;
    if (uploadId != null) {
      this.uploadService.getErrorDetails(uploadId, page, size).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.errorList = response.response.data;
          this.totalElementsVal = response.response.totalElements;
          this.dtTrigger.next();
        } else {
          this.toaster.showError(response.message);
        }
      });
    } else {
      this.toaster.showError('Upload Id is not valid.');
    }
  }

  onFileSelect(event) {
    if (event.target.files[0] !== undefined) {
      if (this.checkExtensionFunction(event.target.files[0], ['csv', 'zip'])) {
        this.selectedFile = event.target.files[0];
        this.formData.append('file', this.selectedFile);
      } else {
        this.selectedFile = null;
        this.toaster.showError('This file type is not supported')
      }
    } else {
      this.toaster.showError('File is not selected');
    }
  }
  upload() {
    this.isClickable = true;
    this.uploadService.uploadFile(this.formData, this.code).subscribe((response) => {
      this.isClickable = false;
      if (response.status === 'SUCCESS') {
        this.file.nativeElement.value = null;
        this.selectedFile = null;
        this.formData = new FormData();
        this.toaster.showSuccess(response.message);
        this.initializeUploadHistory();
      } else {
        this.toaster.showError(response.message);
      }
    })
  }

  checkExtensionFunction(selectedFile, extensionAllowedArray) { // extensionAllowedArray --- ['csv','pdf']
    let checkExtensions = false;
    const extensionArray = selectedFile.name.split('.');
    const extension = extensionArray[extensionArray.length - 1].toLowerCase();
    extensionAllowedArray.forEach(element => {
      if (element == extension) {
        checkExtensions = true;
      }
    });
    return checkExtensions;
  }

  bulkUpload() {
    this.isBulkUpload = true;
  }

  download(obj: any) {
    this.isDisable = true;
    let req = {
      "uploadId": obj.uploadId,
      "gstin": this.code,
      "action": obj.action
    }
    this.uploadService.downloadFile(req).subscribe((response: BaseResponse) => {
      this.isDisable = false;
      if (response.status === 'SUCCESS') {
        this.uploadHistoryList.forEach((item) => {
          if (item.uploadId === obj.uploadId) {
            if (response.response.status === undefined || response.response.status === 'INPROGRESS') {
              item['checkStatus'] = true;
              item['downloadFlag'] = false;
              item['isDownload'] = false;
            } else if (response.response.status === 'COMPLETED') {
              if (response.response.filePath != null) {
                item['checkStatus'] = false;
                item['downloadFlag'] = true;
                item['isDownload'] = false;
                this.downloadFile(response.response.filePath)
                this.toaster.showSuccess(response.message);
              } else {
                this.toaster.showError(response.response.error);
                item['checkStatus'] = true;
              }
            }
          }
        })
      }
    })
  }

  checkDownloadStatus(uploadId) {
    this.uploadService.downloadStatus(uploadId).subscribe((response: BaseResponse) => {
      if (response.status === 'SUCCESS') {
        this.toaster.showSuccess(response.message);
        this.uploadHistoryList.forEach((item) => {
          if (item.uploadId === uploadId) {
            item['downloadFlag'] = true;
            item['downloadPath'] = response.response.filePath;
          }
        })
        // this.downloadFile(response.response.filePath)
      } else {
        this.toaster.showError(response.message);
      }
    })
  }

  downloadFile(data) {
    window.location.href = data;
  }

  paginate(event) {
    this.page = event.page;
    this.size = event.rows;
    this.errorDetail(this.errorId, this.page, this.size);
  }
  paginateUploadHistory(event) {
    this.page1 = event.page;
    this.size1 = event.rows;
    this.initializeUploadHistory();
  }

}
