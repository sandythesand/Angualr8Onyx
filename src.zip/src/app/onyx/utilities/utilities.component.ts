import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToasterService } from '../../shared/services/toaster.service';
import { BaseResponse } from '../../models/response';
import { IrnServiceService } from '../services/irn-service.service';
import { DomSanitizer } from '@angular/platform-browser';
import { DOCUMENT_TYPE, DOCUMENT_TYPE_UTILITIES, STATE_LIST } from '../../shared/constant';
//import { JwtSignatureVerifyService } from '../../shared/services/jwt-signature-verify.service';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-utilities',
  templateUrl: './utilities.component.html',
  styleUrls: ['./utilities.component.scss']
})
export class UtilitiesComponent implements OnInit {

  utilitiesForm: FormGroup;
  qrForm: FormGroup;
  ewbForm: FormGroup;
  gstinForm: FormGroup;
  isSubmitted: boolean = false;
  isSubmitted1: boolean = false;
  isVisible: boolean = false;
  req: any;
  irnData: any;
  qrData: any;
  imagePath: any;
  verification: any;
  publickKey: any = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArxd93uLDs8HTPqcSPpxZrf0Dc29r3iPp0a8filjAyeX4RAH6lWm9qFt26CcE8ESYtmo1sVtswvs7VH4Bjg/FDlRpd+MnAlXuxChij8/vjyAwE71ucMrmZhxM8rOSfPML8fniZ8trr3I4R2o4xWh6no/xTUtZ02/yUEXbphw3DEuefzHEQnEF+quGji9pvGnPO6Krmnri9H4WPY0ysPQQQd82bUZCk9XdhSZcW/am8wBulYokITRMVHlbRXqu1pOFmQMO5oSpyZU3pXbsx+OxIOc4EDX0WMa9aH4+snt18WAXVGwF2B4fmBk7AtmkFzrTmbpmyVqA3KO2IjzMZPw0hQIDAQAB";
  docTypeVal: any;
  irnEwbData: any;
  docTypeValUtilities: { label: string; value: string; }[];
  maxDate: Date = new Date();
  currentYear = (new Date()).getFullYear();
  signedInvoiceJson: string;
  isSubmittedGstin: boolean = false;
  gstinData: any;
  stateList: any = [];

  constructor(
    private toaster: ToasterService,
    private fBuild: FormBuilder,
    private irnService: IrnServiceService,
    private sanitizer: DomSanitizer,
    private datePipe: DatePipe,
    // private jwtSignVerify: JwtSignatureVerifyService
  ) {
    this.docTypeVal = DOCUMENT_TYPE;
    this.docTypeValUtilities = DOCUMENT_TYPE_UTILITIES;
    this.stateList = STATE_LIST;
  }

  ngOnInit() {
    this.formInitialize();
    this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
  }

  formInitialize() {
    this.utilitiesForm = this.fBuild.group({
      irnNumber: [null, [Validators.required]],
      docType: [null, [Validators.required]],
      docNum: [null, [Validators.required]],
      docDate: [null, [Validators.required]],

    })
    this.qrForm = this.fBuild.group({
      qrCode: [null, [Validators.required]]
    })
    this.ewbForm = this.fBuild.group({
      irnNumber1: [null, [Validators.required]],
      updateflag: [null, []],
    })
    this.gstinForm = this.fBuild.group({
      searchGstin: [null, [Validators.required]],
    })
  }
  get f() { return this.utilitiesForm.controls; }
  get qf() { return this.qrForm.controls; }
  get ef() { return this.ewbForm.controls; }
  get gf() { return this.gstinForm.controls; }

  searchIrn() {
    this.isSubmitted = true;
    if (this.utilitiesForm.valid) {
      let model = {
        userGstin: this.req.gstin
      }
      if (this.utilitiesForm.value.irnNumber && this.utilitiesForm.value.irnNumber != '') {
        model['irn'] = this.utilitiesForm.value.irnNumber;
        this.irnData = null;
        this.irnService.getIrnData(model).subscribe((response: BaseResponse) => {
          this.isSubmitted = false;
          if (response.status == "SUCCESS") {
            this.irnData = response.response;
            if (this.irnData.qrCode) {
              this.imagePath = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
                + this.irnData.qrCode);
            }
            if (this.irnData.signedInvoice != undefined)
              this.searchQR(true);
          } else {
            this.toaster.showError(response.errors[0].msg);
          }
        });
      } else if (this.utilitiesForm.value.docNum && this.utilitiesForm.value.docNum != ''
        && this.utilitiesForm.value.docType && this.utilitiesForm.value.docDate) {
        model['docNum'] = this.utilitiesForm.value.docNum;
        model['docType'] = this.utilitiesForm.value.docType;
        model['docDate'] = this.datePipe.transform(this.utilitiesForm.value.docDate, 'dd/MM/yyyy');
        this.irnData = null;
        this.irnService.getIrnDocData(model).subscribe((response: BaseResponse) => {
          if (response.status == "SUCCESS") {
            this.irnData = response.response;
            if (this.irnData.qrCode) {
              this.imagePath = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
                + this.irnData.qrCode);
            }
            if (this.irnData.signedInvoice != undefined)
              this.searchQR(true);
          } else {
            this.toaster.showError(response.errors[0].msg);
          }
        });
      } else {
        return;
      }
    }
  }
  searchEwbIrn() {
    this.isSubmitted = true;
    if (this.ewbForm.valid) {
      let model = {
        irn: this.ewbForm.value.irnNumber1,
        userGstin: this.req.gstin,
        updateFlag: this.ewbForm.value.updateflag ? true : false,


      }
      this.irnEwbData = null;
      this.irnService.getIrnEwbData(model).subscribe((response: BaseResponse) => {
        this.isSubmitted = false;
        if (response.status == "SUCCESS") {
          this.irnEwbData = response.response;
          if (this.irnEwbData.qrCode) {
            this.imagePath = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
              + this.irnEwbData.qrCode);
          }
          if (this.irnEwbData.signedInvoice != undefined)
            this.searchQR(true);
        } else {
          this.toaster.showError(response.errors[0].msg);
        }
      });
    }
  }
  searchQR(isIrn?: boolean) {

    this.isSubmitted1 = true;
    if (this.qrForm.valid || isIrn == true) {
      let model = {};
      if (isIrn) {
        model = {
          jwt: this.irnData.signedInvoice
        }
      } else {
        model = {
          jwt: this.qrForm.value.qrCode
        }
      }
      this.irnService.getqrData(model).subscribe((response: BaseResponse) => {
        this.isSubmitted1 = false;
        if (!isIrn)
          this.isVisible = true;
        this.qrData = null;
        if (response.status == "SUCCESS") {
          this.qrData = response.response;
          this.signedInvoiceJson = JSON.stringify(this.qrData);
          //this.qrData.docTypeName = this.docTypeVal.find((x: { value: any }) => x.value === this.qrData.docType).label;

        } else {
          this.toaster.showError(response.message);
        }
      });
    }
  }

  searchGstin(type?) {
    this.isSubmittedGstin = true;
    if (this.gstinForm.valid) {
      let model = {
        userGstin: this.req.gstin
      }
      if (this.gstinForm.value.searchGstin && this.gstinForm.value.searchGstin != '') {
        model['searchGstin'] = this.gstinForm.value.searchGstin;
        this.gstinData = null;
        if(type === 'cp') {
          this.irnService.getGstinCpData(model).subscribe((response: BaseResponse) => {
            this.isSubmittedGstin = false;
            if (response.status == "SUCCESS") {
              this.gstinData = response.response;
            } else {
              this.toaster.showError(response.errors[0].msg);
            }
          });
        } else {
          this.irnService.getGstinData(model).subscribe((response: BaseResponse) => {
            this.isSubmittedGstin = false;
            if (response.status == "SUCCESS") {
              this.gstinData = response.response;
            } else {
              this.toaster.showError(response.errors[0].msg);
            }
          });
        }

      }
    }
  }

  clear(data) {
    if (data == 'irn') {
      this.utilitiesForm.reset();
      this.irnData = null;
    }

    if (data == 'ewb') {
      this.ewbForm.reset();
      this.irnEwbData = null;
    }
    if (data == 'gstin') {
      this.gstinForm.reset();
      this.gstinData = null;
    }
  }
  clearQr() {
    this.qrForm.reset();
    this.isVisible = false;
  }

  clearVal(val:any) {
    const tempDocNum = this.utilitiesForm.get('docNum');
    const tempDocType = this.utilitiesForm.get('docType');
    const tempDocDate = this.utilitiesForm.get('docDate');
    const tempIrnNum = this.utilitiesForm.get('irnNumber');
    if(val == 'irn') {
      tempDocNum.setValue(null);
      tempDocType.setValue(null);
      tempDocDate.setValue(null);
      tempDocNum.setValidators([]);
      tempDocType.setValidators([]);
      tempDocDate.setValidators([]);
      tempIrnNum.setValidators([Validators.required]);

    }
    if(val == 'ewb') {
      tempIrnNum.setValue(null);
      tempIrnNum.setValidators([]);
      tempDocNum.setValidators([Validators.required]);
      tempDocType.setValidators([Validators.required]);
      tempDocDate.setValidators([Validators.required]);
    }
    tempIrnNum.updateValueAndValidity();
    tempDocNum.updateValueAndValidity();
    tempDocType.updateValueAndValidity();
    tempDocDate.updateValueAndValidity();

  }

  verifyKey(data: any) {
    // let abc = jws.verify(data.signedInvoice, this.publickKey);
    // return abc;
    //    this.verification = this.jwtSignVerify.verifySignature(data);
    console.log(this.verification);
  }

  clearData() {
    this.utilitiesForm.reset();
    this.qrForm.reset();
    this.irnData = null;
    this.isVisible = false;
  }

  getStateName(code) {
    return this.stateList.find((x: { stateCode: any; }) => x.stateCode == code).stateName;
  }

}
