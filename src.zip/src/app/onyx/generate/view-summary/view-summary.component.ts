import { Component, OnInit, Pipe, ɵConsole, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GenerateService } from '../../services/generate.service';
import { BaseResponse } from '../../../models/response';
import { ToasterService } from '../../../shared/services/toaster.service';
import { SUPPLY_TYPE, DOCUMENT_TYPE, REVERSE_CHARGE, TRANSACTION_TYPE, STATE_LIST } from '../../../shared/constant';
import { Router } from '@angular/router';
import { APP_NAME } from 'src/app/shared/constant';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-view-summary',
  templateUrl: './view-summary.component.html',
  styleUrls: ['./view-summary.component.scss'],
})

@Pipe({ name: 'safeUrl' })
export class ViewSummaryComponent implements OnInit {
  @Input() currentInvoice: any; modalHeader: string;
  @Input() checkArch: any;
  invoiceId: any;
  invoiceSummaryData: any;
  docTypeVal: any;
  supplyTypeVal: any;
  reverseChargeVal: any;
  trnTypeVal: any;
  summaryData: boolean = false;
  imagePath: any;
  lineItemError: any = [];
  stateList: any = [];
  isLineItemError: boolean = false;
  isOnyxError: boolean = false;
  isIRNError: boolean = false;
  isEWBrror: boolean = false;
  isOnyxWarning: boolean = false;
  isIRNWarning: boolean = false;
  countInvoiceLevel: number = 0;
  countOnyxWarningLevel: number = 0;
  countIrnWarningLevel: number = 0;
  countIrnErrorLevel: number = 0;
  countEwbErrorLevel: number = 0;
  countOnyxErrorLevel: number = 0;

  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  errorLineItem: boolean = false;
  warningLineItem: boolean = false;
  errorShow: boolean = false;
  warningShow: boolean = false;
  hideIRP: boolean = false;
  hideEWBRes: boolean = false;
  showIrisData: boolean;
  redirectionType: any;
  


  constructor(
    private activeSnapShot: ActivatedRoute,
    private generateServices: GenerateService,
    private toaster: ToasterService,
    private router: Router,
    private sanitizer: DomSanitizer,
  ) {
    this.invoiceId = this.activeSnapShot.snapshot.params.invoiceId;
    this.redirectionType = this.activeSnapShot.snapshot.params.qryPram;
    this.docTypeVal = DOCUMENT_TYPE;
    this.supplyTypeVal = SUPPLY_TYPE;
    this.reverseChargeVal = REVERSE_CHARGE;
    this.trnTypeVal = TRANSACTION_TYPE;
    this.APP_NAME = APP_NAME;
    this.stateList = STATE_LIST;
  }

  ngOnInit() {
    this.initializeSummaryData();
  }
  addDocClass() {
    const el = document.getElementById('docData');
    el.classList.add('col-xl-4');
  }
  removeDocClass() {
    const el = document.getElementById('docData');
    el.classList.remove('col-xl-6');
  }
  addPartyClass() {
    const el = document.getElementById('partyData');
    el.classList.add('col-xl-4');
  }
  removePartyClass() {
    const el = document.getElementById('partyData');
    el.classList.remove('col-xl-6');
  }
  addirpClass() {
    const el = document.getElementById('irpData');
    el.classList.add('col-xl-4');
  }
  removeirpClass() {
    const el = document.getElementById('irpData');
    el.classList.remove('col-xl-6');
  }
  addirisClass() {
    const el = document.getElementById('irisData');
    el.classList.add('col-xl-4');
  }
  removeirisClass() {
    const el = document.getElementById('irisData');
    el.classList.remove('col-xl-6');
  }
  
  initializeSummaryData() {
    if (this.invoiceId != null) {
      let urlCall:any;
      if(this.redirectionType)
        urlCall = this.generateServices.getInvoiceArchSummary(this.invoiceId);
      else
        urlCall = this.generateServices.getInvoiceSummary(this.invoiceId);
      urlCall.subscribe((response: BaseResponse) => {
        this.summaryData = true;
        if (response.status === 'SUCCESS') {
          this.invoiceSummaryData = response.response;
          this.invoiceSummaryData.docTypeName = this.docTypeVal.find((x: { value: any; }) => x.value === this.invoiceSummaryData.docType).label;
          this.invoiceSummaryData.reverseChargeName = this.reverseChargeVal.find((x: { value: any; }) => x.value === this.invoiceSummaryData.rchrg).label;
          this.invoiceSummaryData.supplyTypeName = this.supplyTypeVal.find((x: { key: any; }) => x.key === this.invoiceSummaryData.supplyType).value;
          this.invoiceSummaryData.trnTypeName = this.trnTypeVal.find((x: { value: any; }) => x.value === this.invoiceSummaryData.trnTyp).label;
         
          if (this.invoiceSummaryData.pos != 0) {
            if(this.invoiceSummaryData.pos.length == 1){
              this.invoiceSummaryData.pos = 0+this.invoiceSummaryData.pos;
            }
            this.invoiceSummaryData.stateVal = this.stateList.find((x: { stateCode: any; }) => x.stateCode == this.invoiceSummaryData.pos).stateName;
          }
          if(this.invoiceSummaryData.sstcd.length == 1){
              this.invoiceSummaryData.sstcd = 0+this.invoiceSummaryData.sstcd;
            }
          this.invoiceSummaryData.supstateVal = this.stateList.find((x: { stateCode: any; }) => x.stateCode == this.invoiceSummaryData.sstcd).stateName;
          
          if(this.invoiceSummaryData.bstcd.length == 1){
              this.invoiceSummaryData.bstcd = 0+this.invoiceSummaryData.bstcd;
            }
          this.invoiceSummaryData.buystateVal = this.stateList.find((x: { stateCode: any; }) => x.stateCode == this.invoiceSummaryData.bstcd).stateName;

          if (this.invoiceSummaryData.qrcode) {
            this.imagePath = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
              + this.invoiceSummaryData.qrcode);
          }
          if (this.invoiceSummaryData.itemList.length > 0) {
            this.invoiceSummaryData.itemList.forEach(element => {
              if (element.errors.length > 0) {
                element.errors.forEach(e => {
                  if(e.type == 'ERROR') {
                    element.errorLineItem = true;
                  }
                  if(e.type == 'WARNING') {
                    element.warningLineItem = true;
                  }
                  
                });
                this.countInvoiceLevel++;
              }
            });
            if (this.countInvoiceLevel > 0) {
              this.isLineItemError = true;
            }
          }
          if (this.invoiceSummaryData.errors.length > 0) {
            this.invoiceSummaryData.errors.forEach(element => {
              if (element.type == 'ERROR') {
                this.countOnyxErrorLevel++
              } else if (element.type == 'IRN_ERROR') {
                this.countIrnErrorLevel++;
              }else if (element.type == 'EWB_ERROR') {
                this.countEwbErrorLevel++;
              }
               else if (element.type == 'WARNING') {
                this.countOnyxWarningLevel++;
              } else if (element.type == 'IRN_WARNING') {
                this.countIrnWarningLevel++;
              }
            });
            if (this.countOnyxErrorLevel > 0)
              this.isOnyxError = true;
            if (this.countIrnErrorLevel > 0)
              this.isIRNError = true;
            if (this.countEwbErrorLevel > 0)
              this.isEWBrror = true;           
            if (this.countOnyxWarningLevel > 0)
              this.isOnyxWarning = true;
            if (this.countIrnWarningLevel > 0)
              this.isIRNWarning = true;
          }
            if (this.invoiceSummaryData.invStatus === 'UPLOADED' || this.invoiceSummaryData.irnStatus === 'CNL') {
              this.hideIRP = true;                  
              this.hideEWBRes = true;                  
            }
            if (this.invoiceSummaryData.invStatus === 'EWB_GENERATED' ) {
              this.hideIRP = true;                  
            }
            if (this.invoiceSummaryData.catg === 'B2C' ) {      
              this.showIrisData = true;
              this.addDocClass();
              this.removeDocClass();
              this.addPartyClass();
              this.removePartyClass();
              this.addirpClass(); 
              this.removeirpClass(); 
              this.addirisClass();
              this.removeirisClass();  
            }
            if (this.invoiceSummaryData.irnStatus === 'ACT' ) {     
                    
              this.addDocClass();
              this.removeDocClass();
              this.addPartyClass();
              this.removePartyClass();
              this.addirpClass(); 
              this.removeirpClass(); 
              this.addirisClass();
              this.removeirisClass();   
             }
            
          
        } else {
          this.toaster.showError(response.message);
        }
      });
    } else {
      this.toaster.showError('Summary details not found.');
    }
  }

  viewErrorLineItem(data: any, type: string) {
    if(type == 'ERROR'){
      this.errorShow = true;
    }
    if(type == 'WARNING'){
      this.warningShow = true;
    }
    this.lineItemError = data;
  }

  getViewAllProvided(invoiceId: number) {
    if(this.redirectionType)
      this.router.navigate([`${this.APP_NAME.ONYX}/view-invoice-all-summary`, invoiceId,{ qryPram: true}]);
    else
      this.router.navigate([`${this.APP_NAME.ONYX}/view-invoice-all-summary`, invoiceId]);
  }


  goToBack() {
    if(this.redirectionType)
      this.router.navigate([`${this.APP_NAME.ONYX}/archive-data`,{ defaultQry: true}]);
    else
      this.router.navigate([`${this.APP_NAME.ONYX}/generate`]);
  }

  closeErrorModel() {
    this.errorShow = false;
    this.warningShow = false;
  }

  checkNullValue(value: any) {
    if (value !== undefined) {
      if(value == 'CNL'){
        return 'Cancelled';
      } else if(value == 'ACT') {
        return 'Active';
      } else {
        return value;
      }
      
    } else {
      return '';
    }
  }

  roundVal(val: any){
    return Math.round(val);
  }

}
