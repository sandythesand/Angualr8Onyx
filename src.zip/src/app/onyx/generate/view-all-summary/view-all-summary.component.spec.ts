import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllSummaryComponent } from './view-all-summary.component';

describe('ViewAllSummaryComponent', () => {
  let component: ViewAllSummaryComponent;
  let fixture: ComponentFixture<ViewAllSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAllSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
