import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { GenerateService } from '../../services/generate.service';
import { ToasterService } from '../../../shared/services/toaster.service';
import { BaseResponse } from '../../../models/response';
import { APP_NAME } from 'src/app/shared/constant';
import { DOCUMENT_STATUS, DOCUMENT_TYPE, SUPPLY_TYPE, REVERSE_CHARGE, STATE_LIST, TRANSACTION_TYPE, COUNTRY_LIST } from '../../../shared/constant';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-view-all-summary',
  templateUrl: './view-all-summary.component.html',
  styleUrls: ['./view-all-summary.component.scss']
})
export class ViewAllSummaryComponent implements OnInit {
  itemListData: any;
  invoiceId: any;
  isVisible: boolean = false;
  isFullView: boolean = false;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  invoiceAllSummaryData: any;
  docStatusVal: any;
  docTypeVal: any;
  supplyTypeVal: any;
  revChargVal: any;
  transModeVal: any;
  countryVal: any;
  stateList: any = [];
  imagePath: any;
  isOnyxError: boolean = false;
  isIRNError: boolean = false;
  isOnyxWarning: boolean = false;
  isIRNWarning: boolean = false;
  countInvoiceLevel: number = 0;
  countOnyxWarningLevel: number = 0;
  countIrnWarningLevel: number = 0;
  countIrnErrorLevel: number = 0;
  countOnyxErrorLevel: number = 0;
  countEwbErrorLevel: number = 0;
  isLineItemError: boolean = false;
  hideIRP: boolean = false;
  hideEWBRes: boolean = false;
  showIrisData: boolean;
  isEWBrror: boolean = false;
  redirectionType: any;


  constructor(

    private activeSnapShot: ActivatedRoute,
    private router: Router,
    private toaster: ToasterService,
    private generateServices: GenerateService,
    private sanitizer: DomSanitizer,
  ) {
    this.invoiceId = this.activeSnapShot.snapshot.params.invoiceId;
    this.redirectionType = this.activeSnapShot.snapshot.params.qryPram;
    this.APP_NAME = APP_NAME;
    this.docStatusVal = DOCUMENT_STATUS;
    this.docTypeVal = DOCUMENT_TYPE;
    this.supplyTypeVal = SUPPLY_TYPE;
    this.revChargVal = REVERSE_CHARGE;
    this.stateList = STATE_LIST;
    this.transModeVal = TRANSACTION_TYPE;
    this.countryVal = COUNTRY_LIST;

  }

  ngOnInit() {
    this.initializeAllSummaryData();
  }

  initializeAllSummaryData() {
    if (this.invoiceId != null) {
      let urlCall:any;
      if(this.redirectionType)
        urlCall = this.generateServices.getInvoiceAllSummaryArch(this.invoiceId);
      else
        urlCall = this.generateServices.getInvoiceAllSummary(this.invoiceId);
      urlCall.subscribe((response: BaseResponse) => {
        this.isVisible = true;
        if (response.status === 'SUCCESS') {
          this.invoiceAllSummaryData = response.response;
          this.invoiceAllSummaryData.docStatusName = this.docStatusVal.find((x: { value: any }) => x.value === this.invoiceAllSummaryData.dst).label;
          this.invoiceAllSummaryData.docTypeName = this.docTypeVal.find((x: { value: any }) => x.value === this.invoiceAllSummaryData.docType).label;
          this.invoiceAllSummaryData.supplyTypeName = this.supplyTypeVal.find((x: { key: any }) => x.key === this.invoiceAllSummaryData.supplyType).value;
          this.invoiceAllSummaryData.revChargName = this.revChargVal.find((x: { value: any }) => x.value === this.invoiceAllSummaryData.rchrg).label;
          this.invoiceAllSummaryData.transModeName = this.transModeVal.find((x: { value: any }) => x.value === this.invoiceAllSummaryData.trnTyp).label;
          // this.invoiceAllSummaryData.countryName = this.countryVal.find((x: { countryCode: any }) => x.countryCode === this.invoiceAllSummaryData.cntcd).countryName;

          if (this.invoiceAllSummaryData.qrcode) {
            this.imagePath = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
              + this.invoiceAllSummaryData.qrcode);
          }
          if (this.invoiceAllSummaryData.itemList.length > 0) {
            this.invoiceAllSummaryData.itemList.forEach(element => {
              if (element.errors.length > 0) {
                this.countInvoiceLevel++;
              }
            });
            if (this.countInvoiceLevel > 0) {
              this.isLineItemError = true;
            }
          }
          if (this.invoiceAllSummaryData.errors.length > 0) {
            this.invoiceAllSummaryData.errors.forEach(element => {
              if (element.type == 'ERROR') {
                this.countOnyxErrorLevel++
              } else if (element.type == 'IRN_ERROR') {
                this.countIrnErrorLevel++;
              } else if (element.type == 'EWB_ERROR') {
                this.countEwbErrorLevel++;
              }else if (element.type == 'WARNING') {
                this.countOnyxWarningLevel++;
              } else if (element.type == 'IRN_WARNING') {
                this.countIrnWarningLevel++;
              }
            });
            if (this.countOnyxErrorLevel > 0)
              this.isOnyxError = true;
            if (this.countIrnErrorLevel > 0)
              this.isIRNError = true;
            if (this.countEwbErrorLevel > 0)
              this.isEWBrror = true;
            if (this.countOnyxWarningLevel > 0)
              this.isOnyxWarning = true;
            if (this.countIrnWarningLevel > 0)
              this.isIRNWarning = true;
          }
          if (this.invoiceAllSummaryData.invStatus === 'UPLOADED' || this.invoiceAllSummaryData.irnStatus === 'CNL') {
            this.hideIRP = true; 
            this.hideEWBRes = true;

          }
          if (this.invoiceAllSummaryData.catg === 'B2C' ) {      
            this.showIrisData = true;
          }
        } else {
          this.toaster.showError(response.message);
        }
      });
    } else {
      this.toaster.showError('Summary details not found.');
    }
  }

  checkNullValue(value: any) {
    if (value !== undefined) {
      if(value == 'CNL'){
        return 'Cancelled';
      } else if(value == 'ACT') {
        return 'Active';
      } else {
        return value;
      }
    } else {
      return '';
    }
  }

  getStateName(stateVal: any) {
    if (stateVal !== undefined && stateVal !== 0) {
      if (stateVal.length == 1) {
        stateVal = 0 + stateVal;
      }
      return this.stateList.find((x: { stateCode: any; }) => x.stateCode == stateVal).stateName;
    } else {
      return '';
    }
  }
  getcountryName(countryVal: any) {
    if (countryVal !== undefined && countryVal !== 0) {
      return this.countryVal.find((x: { countryCode: any; }) => x.countryCode == countryVal).countryName;

    } else {
      return '';
    }
  }
  isFullViewClicked() {
    this.isFullView = true;

  }
  isprovidedClicked() {
    this.isFullView = false;
  }
  isDataExist(field: any, isFullView) {
    if (field !== undefined || isFullView) {
      return true;
    } else {
      return false;
    }

  }
  backToSummary(invoiceId: number) {
    if(this.redirectionType)
      this.router.navigate([`${this.APP_NAME.ONYX}/view-invoice-summary`, invoiceId,{ qryPram: true}]);
    else
      this.router.navigate([`${this.APP_NAME.ONYX}/view-invoice-summary`, invoiceId]);
  }
  openDetail(data) {
    this.itemListData = data;
  }
}
