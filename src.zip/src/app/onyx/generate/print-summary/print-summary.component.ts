import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { GenerateService } from '../../services/generate.service';
import { ToasterService } from '../../../shared/services/toaster.service';
import { BaseResponse } from '../../../models/response';
import { APP_NAME } from 'src/app/shared/constant';
import { DOCUMENT_STATUS, DOCUMENT_TYPE, SUPPLY_TYPE, REVERSE_CHARGE, STATE_LIST, INVOICE_TYPE, TRANSACTION_TYPE } from '../../../shared/constant';
import { DomSanitizer } from '@angular/platform-browser';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-print-summary',
  templateUrl: './print-summary.component.html',
  styleUrls: ['./print-summary.component.scss']
})
export class PrintSummaryComponent implements OnInit {

  invoiceId: any;
  templateForm: FormGroup;
  isVisible: boolean = false;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  printData: any;
  docStatusVal: any;
  docTypeVal: any;
  supplyTypeVal: any;
  revChargVal: any;
  invTypeVal: any;
  transTypeVal: any;
  imagePath: any;
  stateList: any = [];
  invoiceTemplatesNameList: any = [];
  templateName;
  flag: boolean;
  imagePathBarCode: any;

  constructor(
    private fBuild: FormBuilder,
    private activeSnapShot: ActivatedRoute,
    private router: Router,
    private toaster: ToasterService,
    private generateServices: GenerateService,
    private sanitizer: DomSanitizer
  ) {
    this.invoiceId = this.activeSnapShot.snapshot.params.invoiceId;
    this.APP_NAME = APP_NAME;
    this.docStatusVal = DOCUMENT_STATUS;
    this.docTypeVal = DOCUMENT_TYPE;
    this.supplyTypeVal = SUPPLY_TYPE;
    this.revChargVal = REVERSE_CHARGE;
    this.stateList = STATE_LIST;
    this.invTypeVal = INVOICE_TYPE;
    this.transTypeVal = TRANSACTION_TYPE;
     }

  ngOnInit() {
    this.getPrintData();
    this.getInvoiceNameList();
  }
  getPrintData() {
    if (this.invoiceId != null) {
      this.generateServices.getInvoiceAllSummary(this.invoiceId).subscribe((response: BaseResponse) => {
        this.isVisible = true;
        if (response.status === 'SUCCESS') {
          this.printData = response.response;
          this.printData.docStatusName = this.docStatusVal.find((x: {value: any} ) => x.value === this.printData.dst).label;
          this.printData.docTypeName = this.docTypeVal.find((x: {value: any} ) => x.value === this.printData.docType).label;
          this.printData.supplyTypeName = this.supplyTypeVal.find((x: {key: any} ) => x.key === this.printData.supplyType).value;
          this.printData.revChargName = this.revChargVal.find((x: {value: any} ) => x.value === this.printData.rchrg).label;
          // this.printData.invTypeName = this.invTypeVal.find((x: {value: any} ) => x.value === this.printData.catg).label;
          this.printData.transTypeName = this.transTypeVal.find((x: {value: any} ) => x.value === this.printData.trnTyp).label;
          if(this.printData.qrcode){
            this.imagePath = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
                 + this.printData.qrcode);
          }
          if(this.printData.barcode){
            this.imagePathBarCode = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
                 + this.printData.barcode);
          }
        } else {
          this.toaster.showError(response.message);
        }
      });
    } else {
      this.toaster.showError('Summary details not found.');
    }
  }

  nicFormInitialize() {
    this.flag = true;
    this.templateForm = this.fBuild.group({
      templateName: ['', [Validators.required]],
    });
  }

  getInvoiceNameList() {
      this.generateServices.getAllInvoiceName().subscribe((response: BaseResponse) => {
        this.isVisible = true;
        if (response.status === 'SUCCESS') {
          this.invoiceTemplatesNameList = response.response;
        } 
      });
  }

  printInv(){
    window.print();
  }

  printPDF(id): void {
    this.generateServices.getPrintPDF(id, this.templateForm.value.templateName)
        .subscribe(x => {
            // It is necessary to create a new blob object with mime-type explicitly set
            // otherwise only Chrome works like it should
            const newBlob = new Blob([x], { type: 'application/pdf' });

            // IE doesn't allow using a blob object directly as link href
            // instead it is necessary to use msSaveOrOpenBlob
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(newBlob);
                return;
            }

            // For other browsers:
            // Create a link pointing to the ObjectURL containing the blob.
            const data = window.URL.createObjectURL(newBlob);

            const link = document.createElement('a');
            link.href = data;
            link.download = 'Invoice.pdf';
            // this is necessary as link.click() does not work on the latest firefox
            link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

            setTimeout(() => {
                // For Firefox it is necessary to delay revoking the ObjectURL
                window.URL.revokeObjectURL(data);
                link.remove();
            }, 100);
        });
  }

  getStateName(stateVal: any) {
    if (stateVal !== undefined && stateVal !== 0) {
      return this.stateList.find((x: { stateCode: any; }) => x.stateCode == stateVal).stateName;
    } else {
      return '';
    }
  }
  
  roundVal(val: any){
    return Math.round(val);
  }
}
