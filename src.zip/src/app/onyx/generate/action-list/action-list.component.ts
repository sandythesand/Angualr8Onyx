import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { ToasterService } from '../../../shared/services/toaster.service';
import { BaseResponse } from '../../../models/response';
import { GenerateService } from '../../services/generate.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { CANCEL_REASON_IRN, CANCEL_REASON_EWB, APP_NAME } from '../../../shared/constant';
import { Router } from '@angular/router';

@Component({
  selector: 'app-action-list',
  templateUrl: './action-list.component.html',
  styleUrls: ['./action-list.component.scss']
})
export class ActionListComponent implements OnInit {

  @ViewChild('closeModal', { static: false }) closeModal: ElementRef;
  @ViewChild('closeModal1', { static: false }) closeModal1: ElementRef;
  @ViewChild('closeModal2', { static: false }) closeModal2: ElementRef;
  @ViewChild('openMode2', { static: false }) openMode2: ElementRef;
  @ViewChild('openModePrint', { static: false }) openModePrint: ElementRef;
  @ViewChild('closeModalBulk', { static: false }) closeModalBulk: ElementRef;
  @Input() currentInvoice: any; 
  modalHeader: string;
  @Input() checkArch: any;
  modalBody: string;
  selectedId: any;
  req: any;
  statusFlag: boolean;
  status: boolean;
  genDisabled: boolean;
  rmDelete: boolean;
  invConsideredCnt: any;
  invSuccessCnt: any;
  invFailCnt: any;
  cnlDisabled: boolean = false;
  cancelIrnForm: FormGroup;
  cancelEwbForm: FormGroup;
  isVisible: boolean;
  isVisibleEwb: boolean = false;
  isSubmitted: boolean;
  isDisabled: boolean;
  cancelReasonListIrn: { name: string; val: number; }[];
  cancelReasonListEwb: { name: string; val: number; }[];
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  getNavContext: any;
  ewbSuccessData: any = [];
  irnSuccessData: any = [];
  ewbCnlDisabled: boolean = false;
  cnlEwb: string = null;
  isrequired: boolean = false;
  allSelId: any = [];
  flagVal: boolean;
  invoiceTemplatesNameList: any;
  templateForm: FormGroup;

  constructor(
    private toaster: ToasterService,
    private generateServices: GenerateService,
    private fBuild: FormBuilder,
    private router: Router
  ) {
    this.APP_NAME = APP_NAME;
    this.cancelReasonListIrn = CANCEL_REASON_IRN;
    this.cancelReasonListEwb = CANCEL_REASON_EWB;
  }

  ngOnInit() {
    this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
    this.getNavContext = JSON.parse(sessionStorage.getItem('navContext'));
    if (this.currentInvoice) {
      this.selectedId = [this.currentInvoice.einvId];
    }
    this.actionEnableCheck();
    this.templateFormInitialize();
    this.getInvoiceNameList();
    // console.log(this.currentInvoice, this.currentInvoice.irn, 'DATA');
  }

  templateFormInitialize() {
    this.templateForm = this.fBuild.group({
      templateName: ['', []],
    });
  }

  commonModalInitialize(obj) {
    if (obj == 'Generate IRN') {
      this.modalHeader = 'Generate IRN';
      this.modalBody = `Invoices with errors, Invoices already having IRN and invoices cancelled will not be sent for IRN generation. Do you want to continue?`
    }
    if (obj == 'Delete') {
      this.modalHeader = 'Delete';
      if (this.selectedId.length) {
        this.modalBody = `This invoice will be deleted. Are you sure you want to delete?`
      }
    }
  }

  confirm(action) {
    this.closeModal.nativeElement.click();
    if (action === 'Generate IRN') {
      this.generateIRN();
    } else if (action === 'Delete') {
      this.deleteIRN();
    }
  }

  deleteIRN() {
    // if (!this.genDisabled) {
    let data = {};
    if (this.getNavContext.entityType == 'FILING') {
      data['companyUniqueCode'] = this.getNavContext.gstin;
    }
    if (this.getNavContext.entityType == 'POB') {
      data['companyUniqueCode'] = this.getNavContext.pobCode;
    }

    data['gstin'] = this.req.gstin;
    if (this.selectedId.length !== 0) {
      data['ids'] = this.selectedId;
    }
    // console.log(data, 'DATA');
    this.generateServices.deleteIRN(data).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.toaster.showSuccess(response.response);
        this.router.navigate([`${this.APP_NAME.ONYX}/generate`]);
      } else {
        if (response.status == "FAILURE") {
          if (response.errors) {
            if (response.errors.length > 0) {
              this.toaster.showError(response.errors[0].msg);
            }
          }
          else {
            this.toaster.showError(response.response);
          }
        } else {
          this.toaster.showError(response.message);
        }
      }
    });
    // } else {
    //   this.toaster.showError('IRN cannot be generated for the records selected. IRN Generation is allowed for records which do not have any validation errors.');
    // }
  }
  actionEnableCheck() {
    if (this.currentInvoice.hasError || this.currentInvoice.invStatus === 'IRN_GENERATED' || this.currentInvoice.irnStatus === 'CNL' || this.currentInvoice.catg === 'B2C' || this.currentInvoice.eligibleForIrn === false) {
      this.genDisabled = true;
    }
    if (this.currentInvoice.invStatus === 'UPLOADED' || this.currentInvoice.irnStatus === 'CNL') {
      this.cnlDisabled = true;
    }
    if (this.currentInvoice.invStatus === 'BOTH' || this.currentInvoice.invStatus === 'EWB_GENERATED') {
      this.ewbCnlDisabled = true;
    }
    if (this.currentInvoice.invStatus === 'IRN_GENERATED') {
      this.rmDelete = true;
    }
    if (this.currentInvoice.eligibleForIrn === false) {
      this.rmDelete = false;
    }
  }


  generateIRN() {
    // if (!this.genDisabled) {
    let data = {};
    data['gstin'] = this.req.gstin;
    if (this.selectedId.length !== 0) {
      data['ids'] = this.selectedId;
    }
    // console.log(data, 'DATA');
    this.generateServices.generateIRN(data).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.statusFlag = true;
        this.status = false;
        this.genDisabled = true;
        this.checkIRNstatus();
        this.toaster.showSuccess(response.message);
      } else {
        this.toaster.showError(response.message);
      }
    });
    // } else {
    //   this.toaster.showError('IRN cannot be generated for the records selected. IRN Generation is allowed for records which do not have any validation errors.');
    // }
  }

  checkIRNstatus() {
    let gstin = this.req.gstin;
    this.generateServices.generatedIRNstatus(gstin).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        if (response.response.status === 'COMPLETE') {
          this.invConsideredCnt = response.response.invConsideredCnt;
          this.invSuccessCnt = response.response.invSuccessCnt;
          this.invFailCnt = response.response.invFailCnt;
          this.status = true;
          // this.genDisabled = false;
        } else if (response.response.status === 'INPROGRESS') {
          this.status = false;
        } else {
          this.status = false;
        }
      } else {
        this.toaster.showError(response.message);
      }
    });
  }


  openCancelIrn() {
    if (this.currentInvoice) {
      // let stringDocNum = this.currentInvoice.docNo;
      this.cancelIrnForm = this.fBuild.group({
        // docNumber: [stringDocNum],
        irnNumber: [this.currentInvoice.irn],
        cnlRsn: [null, [Validators.required]],
        cnlRem: [null, [Validators.required]]
      });
    }
    this.isVisible = true;
  }

  openCancelEwb() {
      if(this.currentInvoice) {
        this.cancelEwbForm = this.fBuild.group({
          ewbNo: [this.currentInvoice.ewbNo],
          cnlRsn: [null, [Validators.required]],
          cnlRem: [null]
        });
        this.isVisibleEwb = true;
        this.cnlEwb = 'cancelModalEwb';
      } 
  }

  cancelIRN() {
    // if (!this.cnlDisabled) {
    this.isSubmitted = true;
    if (this.cancelIrnForm.valid) {
      if (this.currentInvoice) {
        let model = {
          'irn': this.cancelIrnForm.value.irnNumber,
          'cnlRsn': this.cancelIrnForm.value.cnlRsn,
          'cnlRem': this.cancelIrnForm.value.cnlRem,
          'userGstin': this.req.gstin
        };
        this.generateServices.cancelIrnData(model).subscribe((response: BaseResponse) => {
          this.closeModal1.nativeElement.click();
          if (response.status == "SUCCESS") {
            this.irnSuccessData.push(response.response);
            this.toaster.showSuccess(response.message);
            this.cnlDisabled = true;
          } else {
            if (response.status == "FAILURE") {
              this.irnSuccessData.push({'irn':this.cancelIrnForm.value.irnNumber,'description':response.errors[0].msg});
              // this.toaster.showError(response.errors[0].msg);
            } else {
              this.toaster.showError(response.message);
            }
          }
          this.cancelIrnForm.reset();
        });
        setTimeout(() => {
          this.openModelEwb();
        }, 2000);
        this.isDisabled = false;
        this.isSubmitted = false;
        this.irnSuccessData = [];
        this.ewbSuccessData = [];
        this.isrequired = false;
      }
    }
    // } else {
    //   this.toaster.showError('IRN cannot be cancelled for the records selected. Cancellation is allowed for records on which IRN is generated in last 24 hours or are not already cancelled.');
    // }
  }

  cancelEwb() {
    this.isSubmitted = true;
    if (this.cancelEwbForm.valid) {
      if (this.currentInvoice) {
        let model = {
          'ewbNo': this.cancelEwbForm.value.ewbNo,
          'cnlRsn': this.cancelEwbForm.value.cnlRsn,
          'cnlRem': this.cancelEwbForm.value.cnlRem,
          'userGstin': this.req.gstin
        };
        this.generateServices.cancelEwbData(model).subscribe((response: BaseResponse) => {
          this.closeModal2.nativeElement.click();
          if (response.status == "SUCCESS") {
            this.ewbSuccessData.push(response.response);
            this.toaster.showSuccess(response.message);
          } else {
            if (response.status == "FAILURE") {
              this.ewbSuccessData.push({'ewbNo':this.cancelEwbForm.value.ewbNo,'description':response.errors[0].msg});
              // this.toaster.showError(response.errors[0].msg);
            } else {
              this.toaster.showError(response.message);
            }
          }
          this.cancelEwbForm.reset();
        });
        setTimeout(() => {
          this.openModelEwb();
        }, 2000);
        this.ewbSuccessData = [];
        this.irnSuccessData = [];
        this.isDisabled = false;
        this.isSubmitted = false;
        this.isrequired = false;
      }
    }
  }

  openModelEwb() {
    if (this.ewbSuccessData.length > 0) {
      this.openMode2.nativeElement.click();
    }
    if (this.irnSuccessData.length > 0) {
      this.openMode2.nativeElement.click();
    }
  }

  // printSummary() {
  //   this.router.navigate([`${this.APP_NAME.ONYX}/print-summary`, this.selectedId[0]]);
  // }

  printSummary() {
    if (this.selectedId[0]) {
      this.allSelId = this.selectedId;
      this.openModePrint.nativeElement.click();
    }
  }

  getInvoiceNameList() {
    this.generateServices.getAllInvoiceName().subscribe((response: BaseResponse) => {
      this.flagVal = true;
      if (response.status === 'SUCCESS') {
        this.invoiceTemplatesNameList = response.response;
      } 
    });
}

  closeFlag() {
    this.status = false;
  }

  printPDF(invoiceId) {
    this.generateServices.getPrintPDF(invoiceId, this.templateForm.value.templateName)
        .subscribe(x => {
            // It is necessary to create a new blob object with mime-type explicitly set
            // otherwise only Chrome works like it should
            const newBlob = new Blob([x], { type: 'application/pdf' });

            // IE doesn't allow using a blob object directly as link href
            // instead it is necessary to use msSaveOrOpenBlob
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(newBlob);
                return;
            }

            // For other browsers:
            // Create a link pointing to the ObjectURL containing the blob.
            const data = window.URL.createObjectURL(newBlob);

            const link = document.createElement('a');
            link.href = data;
            if(this.templateForm.value.templateName){
              link.download = this.templateForm.value.templateName;
            } else {
              link.download = 'Invoice.pdf';
            }
            // this is necessary as link.click() does not work on the latest firefox
            link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

            setTimeout(() => {
                // For Firefox it is necessary to delay revoking the ObjectURL
                window.URL.revokeObjectURL(data);
                link.remove();
            }, 100);
        });
  }

  getRequired(type) {
    if (type == 'ewb') {
      if (this.cancelEwbForm.value.cnlRsn == '4') {
        this.isrequired = true;
      } else {
        this.isrequired = false;
      }
    }

    this.setValidateRemark(type);
  }

  setValidateRemark(type) {
    if (type == 'ewb') {
      let tempRemark = this.cancelEwbForm.get('cnlRem');
      if (this.isrequired) {
        tempRemark.setValidators([Validators.required]);
      } else {
        tempRemark.clearValidators();
      }
      tempRemark.updateValueAndValidity();
    } 
  }

}
