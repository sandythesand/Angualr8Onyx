import { Component, OnInit } from '@angular/core';
import { GenerateService } from '../../services/generate.service';
import { ToasterService } from '../../../shared/services/toaster.service';
import { Router } from '@angular/router';
import { BaseResponse } from '../../../models/response';
import { paginationPrams, APP_NAME } from '../../../shared/constant';


@Component({
  selector: 'app-generate-history',
  templateUrl: './generate-history.component.html',
  styleUrls: ['./generate-history.component.scss']
})
export class GenerateHistoryComponent implements OnInit {
  selectedFilling: any;
  page: number = 0;
  size: number = 10;
  genHistoryList = [];
  rows: any;
  pageOption: any;
  APP_NAME: any;
  option: any = 'Option 3';
  totalElements: any;
  noDataFound: boolean = false;

  constructor(
    private generateServices: GenerateService,
    private toaster: ToasterService,
    private router: Router,
  ) {
    this.rows = paginationPrams.pageLen;
    this.pageOption = paginationPrams.pageOption;
    this.APP_NAME = APP_NAME;
  }

  ngOnInit() {
    this.selectedFilling = JSON.parse(sessionStorage.getItem('selectedFilling'));
    this.initializeData(this.page, this.size);
  }

  initializeData(page?, size?) {
    let data = {};
    data['gstin'] = this.selectedFilling.gstin;
    data['page'] = page;
    data['size'] = size;
    this.generateServices.getGenHistory(data).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.genHistoryList = response.response.data;
        this.totalElements = response.response.totalElements;
        this.noDataFound = false;
      } else {
        this.toaster.showError(response.message);
        this.noDataFound = true;
      }
    });
  }

  paginate(event) {
    this.page = event.page;
    this.size = event.rows;
    this.initializeData(this.page, this.size);
  }

  gotoView() {
    this.router.navigate([`${this.APP_NAME.ONYX}/generate`])
  }

}
