import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateHistoryComponent } from './generate-history.component';

describe('GenerateHistoryComponent', () => {
  let component: GenerateHistoryComponent;
  let fixture: ComponentFixture<GenerateHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
