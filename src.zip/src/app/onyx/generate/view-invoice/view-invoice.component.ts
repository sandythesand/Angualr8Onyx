import { Component, OnInit, ElementRef, ViewChild, Output, HostListener, Input } from '@angular/core';
import { GenerateService } from '../../services/generate.service';
import { BaseResponse } from '../../../models/response';
import { ToasterService } from '../../../shared/services/toaster.service';
import { DOCUMENT_TYPE, IRN_STATUS, paginationPrams, CANCEL_REASON_IRN, CANCEL_REASON_EWB } from '../../../shared/constant';
import { Router } from '@angular/router';
import { APP_NAME } from 'src/app/shared/constant';
import { DatePipe } from '@angular/common';
import { GenerateIRN } from '../genrate.modal'
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Paginator } from 'primeng/paginator/paginator';
import * as cloneDeep from 'lodash/cloneDeep';
import { AdvanceFilterService } from '../../services/advance-filter.service';
import { SendMailComponent } from '../send-mail/send-mail.component';
import { StorageService } from '../../../shared/services/storage.service';
import { BusinessEntityService } from '../../../shared/services/business-entity.service';


@Component({
  selector: 'app-view-invoice',
  templateUrl: './view-invoice.component.html',
  styleUrls: ['./view-invoice.component.scss'],
})
export class ViewInvoiceComponent implements OnInit {
  @ViewChild('p', { static: false }) paginator: Paginator;
  @ViewChild('closeModal', { static: false }) closeModal: ElementRef;
  @ViewChild('closeModal1', { static: false }) closeModal1: ElementRef;
  @ViewChild('closeModal2', { static: false }) closeModal2: ElementRef;
  @ViewChild('openMode1', { static: false }) openMode1: ElementRef;
  @ViewChild('openModePrint', { static: false }) openModePrint: ElementRef;
  @ViewChild('openMode1DelB2cOth', { static: false }) openMode1DelB2cOth: ElementRef;
  @ViewChild('closeModalEsign', { static: false }) closeModalEsign: ElementRef;
  @ViewChild('openModelEsign', { static: false }) openModelEsign: ElementRef;
  @ViewChild('closeModalBulk', { static: false }) closeModalBulk: ElementRef;
  @ViewChild('closeModalEmail', { static: false }) closeModalEmail: ElementRef;
  @ViewChild('closeModalDel', { static: false }) closeModalDel: ElementRef;
  @ViewChild('stickyMenu', { static: false }) menuElement: ElementRef;
  @ViewChild(SendMailComponent, { static: false }) childSendMail: SendMailComponent;
  isSticky: boolean = false;
  isDwdCheckStsInprog: boolean = false;
  isDwdCheckStsInprogRes: boolean = false;
  isDwdCheckStsInprogEsign: boolean = false;
  elementPosition: any;
  activeStep1: boolean = true;
  activeStep2: boolean = false;
  req: any;
  viewInvoiceList: any = [];
  page: number = 0;
  size: number = paginationPrams.pageLen50;
  totalElementsVal: number;
  docTypeVal: any;
  filterObj = new GenerateIRN();
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  invoiceSummaryResp: any;
  irnStatus: any;
  rows: number;
  pageOption: any;
  selectedId = [];
  selectedIrn = [];
  selectedEwbNo = [];
  selectedIdEsign = [];
  selectedItem: any = [];
  selectedDocNo = [];
  modalHeader: string;
  modalBody: string;
  invSuccessCnt: number = 0;
  invFailCnt: number = 0;
  invConsideredCnt: number = 0;
  status: boolean = false;
  statusFlag: boolean = false;
  noDataFound: boolean = false;
  cancelReasonListIrn: { name: string; val: number; }[];
  cancelReasonListEwb: { name: string; val: number; }[];
  isSubmitted: boolean = false;
  isVisible: boolean = false;
  isVisibleEwb: boolean = false;
  isDisabled: boolean = true;
  showIrnField: boolean = false;
  disableEsign: boolean = false;
  imagePath: any;
  cancelIrnForm: FormGroup;
  cancelEwbForm: FormGroup;
  genDisabled: boolean = false;
  toDate: Date;
  fromDate: Date;
  allChecked: boolean = false;
  cnlDisabled: boolean = false;
  isEmailVisible: boolean = false;
  isIRNResponse: boolean = false;
  checkStatusFlag: boolean = false;
  checkDwdFlag: boolean = false;
  checkDwdFlagRes: boolean = false;
  checkDwdFlagEsign: boolean = false;
  checkBulkPrintFlag: boolean = false;
  compCode: any;
  isDownloadClick: boolean = false;
  isDownloadClickRes: boolean = false;
  isDownloadClickEsign: boolean = false;
  isBulkPrintClick: boolean = false;
  dwdDisabled: boolean = false;
  downloadPath: any;
  isCheckMailSent: boolean = false;
  checkMailStatusFlag: boolean = false;
  mailDisabled: boolean = false;
  checkMailFlag: boolean = false;
  mailData: any;
  ctinVal: any;
  sameCtin: boolean;
  subscription: any;
  previousUrl: any;
  flag: boolean;
  checkMailSent: any;
  selectedTab: string;
  firstParam = 2;
  btnSubscription;
  getNavContext: any;
  allFilterData: any = {};
  cnlEwb: string;
  ewbSuccessData: any = [];
  irnSuccessData: any = [];
  isrequired: boolean = false;
  templateForm: FormGroup;
  invoiceTemplatesNameList: any = [];
  flagVal: boolean;
  allSelId: any;
  singlePrint: boolean = false;
  isMultiple: boolean = false;
  deleId: any[];
  dwdDisabledRes: boolean = false;
  dwdDisabledEsign: boolean = false;
  getMailIds: any;
  constructor(
    private generateServices: GenerateService,
    private toaster: ToasterService,
    private router: Router,
    private datePipe: DatePipe,
    private fBuild: FormBuilder,
    private sanitizer: DomSanitizer,
    private AFS: AdvanceFilterService,
    private storageService: StorageService
  ) {
    this.loadScripts();
    this.docTypeVal = DOCUMENT_TYPE;
    this.irnStatus = IRN_STATUS;
    this.APP_NAME = APP_NAME;
    this.rows = paginationPrams.pageLen50;
    this.pageOption = paginationPrams.pageOption;
    this.cancelReasonListIrn = CANCEL_REASON_IRN;
    this.cancelReasonListEwb = CANCEL_REASON_EWB;
  }

  loadScripts() {
    const externalScriptArray = [
      '../assets/js/settings.js'
    ];
    for (let i = 0; i < externalScriptArray.length; i++) {
      const scriptTag = document.createElement('script');
      scriptTag.src = externalScriptArray[i];
      scriptTag.type = 'text/javascript';
      scriptTag.async = false;
      scriptTag.charset = 'utf-8';
      document.getElementsByTagName('head')[0].appendChild(scriptTag);
    }
  }

  ngOnInit() {

    this.subscription = this.generateServices.getPageData().subscribe((value) => {
      this.page = value.page;
      this.size = value.size;
      this.selectedTab = value.tab;
    })
    this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
    this.getNavContext = JSON.parse(sessionStorage.getItem('navContext'));
    this.tabChanged(this.selectedTab);
    this.templateFormInitialize();
    this.checkIRNstatus();
    this.checkDwdStatus();
    this.getInvoiceNameList();
    // this.btnSubscription = this.storageService.btnFlag$.subscribe((value) => {
    //   if (value) {
    //     if (value.type === 'generate') {
    //       this.genDisabled = value.disable;
    //     } else if (value.type === 'download') {
    //       this.dwdDisabled = value.disable;
    //     }
    //   }
    // })
  }

  onClickedOutside(e: Event) {
    // console.log('Clicked outside:', e);
    this.removeClass();
  }

  butonClicked() {
    this.addClass();
  }

  addClass() {
    const el = document.getElementById('navigation-bar');
    el.classList.add('show');
  }

  removeClass() {
    const el = document.getElementById('navigation-bar');
    el.classList.remove('show');
  }

  addSwingClass() {
    const el = document.getElementById('notificationDropdown');
    el.classList.add('swing');
  }
  removeSwingClass() {
    const el = document.getElementById('notificationDropdown');
    el.classList.remove('swing');
  }

  ngOnDestroy(): void {
    if (!this.flag) {
      this.generateServices.setPageData({ page: 0, size: 50, tab: 'tab1' });
    } else {
      this.flag = false;
    }
    this.storageService.setNotifyFlag(null);
    // this.storageService.setIRNSatusFlag({ irnFlag: false, downloadFlag: false });
    this.subscription.unsubscribe();
  }

  ngAfterViewInit() {
    this.elementPosition = this.menuElement.nativeElement.offsetTop;
  }

  setDate() {
    this.toDate = new Date();
    this.fromDate = new Date();
    this.fromDate.setDate(this.toDate.getDate() - 15);
  }


  tabChanged(tab, check?) {
    this.filterObj = {};
    this.selectedTab = tab;
    this.setDate();
    if (this.selectedTab === 'tab1') {
      this.filterObj.invStatus = ['UPLOADED'];
      this.filterObj.catg = this.catgForTab1();
      this.filterObj.eligibleForIrn = true;
    } else if (this.selectedTab === 'tab2') {
      this.filterObj.invStatus = ['IRN_GENERATED', 'EWB_GENERATED', 'BOTH'];
      this.filterObj.catg = this.catgForTab2();
      this.filterObj.fromUpDt = this.fromDate;
      this.filterObj.toUpDt = this.toDate;
      this.filterObj.eligibleForIrn = true;
    } else if (this.selectedTab === 'tab3') {
      this.filterObj.catg = this.catgForTab3();
      this.filterObj.fromUpDt = this.fromDate;
      this.filterObj.toUpDt = this.toDate;
    } else if (this.selectedTab === 'tab4') {
      this.filterObj.catg = this.catgForTab4();
      this.filterObj.fromUpDt = this.fromDate;
      this.filterObj.toUpDt = this.toDate;
      this.filterObj.eligibleForIrn = false;
    }
    if (check) {
      this.generateServices.setPageData({ page: 0, size: 50, tab: this.selectedTab });
    } else {
      this.generateServices.setPageData({ page: 0, size: this.size, tab: this.selectedTab });
    }
    this.fetchViewData(this.page, this.size, this.filterObj);
  }

  fetchViewData(page?, size?, filterObj?) {
    this.selectedId = [];
    this.selectedIrn = [];
    this.selectedDocNo = [];
    let model = cloneDeep(filterObj);
    if (this.req != null) {
      if (this.getNavContext.entityType == 'FILING') {
        model['companyUniqueCode'] = this.getNavContext.gstin;
      }
      if (this.getNavContext.entityType == 'POB') {
        model['companyUniqueCode'] = this.getNavContext.pobCode;
      }
      if(model.pobCodes) {
        model['pobCodes'] = model.pobCodes.toString();
      }
      model['gstin'] = this.req.gstin;
      model['page'] = page;
      model['size'] = size;
      if (this.selectedTab === 'tab2') {
        model['toUpDt'] = this.datePipe.transform(this.toDate, 'dd/MM/yyyy');
        model['fromUpDt'] = this.datePipe.transform(this.fromDate, 'dd/MM/yyyy');
      } else if (this.selectedTab === 'tab3') {
        model['toUpDt'] = this.datePipe.transform(this.toDate, 'dd/MM/yyyy');
        model['fromUpDt'] = this.datePipe.transform(this.fromDate, 'dd/MM/yyyy');
      }
      else if (this.selectedTab === 'tab4') {
        model['toUpDt'] = this.datePipe.transform(this.toDate, 'dd/MM/yyyy');
        model['fromUpDt'] = this.datePipe.transform(this.fromDate, 'dd/MM/yyyy');
        model['eligibleForIrn'] = false;
      }
      // model['toDt'] = this.datePipe.transform(this.toDate, 'dd/MM/yyyy');
      // model['fromDt'] = this.datePipe.transform(this.fromDate, 'dd/MM/yyyy');
      this.generateServices.getGenView(model).subscribe((response: BaseResponse) => {
        this.allChecked = false;

        if (response.status == "SUCCESS") {
          this.viewInvoiceList = response.response.data;
          this.viewInvoiceList.forEach(element => {
            element.docTypeName = this.docTypeVal.find((x: { value: any; }) => x.value === element.docType).label;
          });
          this.totalElementsVal = response.response.totalElements;
          if (this.viewInvoiceList.length === 0) {
            this.noDataFound = true;
          }
          this.isDisabled = true;
        } else {
          this.toaster.showError(response.message);
          this.noDataFound = true;
        }
      });
    } else {
      this.toaster.showError('GSTIN number not found.');
    }
  }

  paginate(event) {
    this.page = event.page;
    this.size = event.rows;
    this.generateServices.setPageData({ page: this.page, size: this.size, tab: this.selectedTab });
    this.filterData();
  }

  receiveFilter(event) {
    this.filterObj = cloneDeep(event);
    console.log(this.filterObj, 'POPOP');
    this.filterData();
  }

  filterData() {
    if (Object.keys(this.filterObj).length) {
      let body = cloneDeep(this.filterObj);
      body['gstin'] = this.req.gstin;
      body['page'] = this.page;
      body['size'] = this.size;
      if (this.getNavContext.entityType == 'FILING') {
        body['companyUniqueCode'] = this.getNavContext.gstin;
      }
      if (this.getNavContext.entityType == 'POB') {
        body['companyUniqueCode'] = this.getNavContext.pobCode;
      }
      if(body.pobCodes) {
        body['pobCodes'] = body.pobCodes.toString();
      }
      if (body.fromDt && body.toDt) {
        body.fromDt = this.datePipe.transform(body.fromDt, 'dd/MM/yyyy');
        body.toDt = this.datePipe.transform(body.toDt, 'dd/MM/yyyy');
      }
      if (body.fromEWBDate && body.toEWBDate) {
        body.fromEWBDate = this.datePipe.transform(body.fromEWBDate, 'dd/MM/yyyy');
        body.toEWBDate = this.datePipe.transform(body.toEWBDate, 'dd/MM/yyyy');
      }
      if (body.fromIRNCancelledDate && body.toIRNCancelledDate) {
        body.fromIRNCancelledDate = this.datePipe.transform(body.fromIRNCancelledDate, 'dd/MM/yyyy');
        body.toIRNCancelledDate = this.datePipe.transform(body.toIRNCancelledDate, 'dd/MM/yyyy');
      }
      if (body.fromEWBCancelledDate && body.toEWBCancelledDate) {
        body.fromEWBCancelledDate = this.datePipe.transform(body.fromEWBCancelledDate, 'dd/MM/yyyy');
        body.toEWBCancelledDate = this.datePipe.transform(body.toEWBCancelledDate, 'dd/MM/yyyy');
      }
      if (body.fromUpDt && body.toUpDt) {
        body.fromUpDt = this.datePipe.transform(body.fromUpDt, 'dd/MM/yyyy');
        body.toUpDt = this.datePipe.transform(body.toUpDt, 'dd/MM/yyyy');
      }
      if (body.fromAckDt && body.toAckDt) {
        body.fromAckDt = this.datePipe.transform(body.fromAckDt, 'dd/MM/yyyy');
        body.toAckDt = this.datePipe.transform(body.toAckDt, 'dd/MM/yyyy');
      }
      if (body.fromCnlDt && body.toCnlDt) {
        body.fromCnlDt = this.datePipe.transform(body.fromCnlDt, 'dd/MM/yyyy');
        body.toCnlDt = this.datePipe.transform(body.toCnlDt, 'dd/MM/yyyy');
      }
      if (body.no) {
        body.no = body.no.split(',');
      }
      if (body.ewbNo) {
        body.ewbNo = body.ewbNo.split(',');
      }
      if (body.bgstin) {
        body.bgstin = body.bgstin.split(',');
      }
      if (body.supplyType) {
        body.supplyType = [body.supplyType];
      }
      if (body.hasError === null) {
        delete body['hasError'];
      }
      if (body.hasWarning === null) {
        delete body['hasWarning'];
      }
      if (body.hasIrnError === null) {
        delete body['hasIrnError'];
      }
      if (body.hasEwbError === null) {
        delete body['hasEwbError'];
      }
      if (body.catg === null) {
        if (this.selectedTab === 'tab1') {
          body.catg = this.catgForTab1();
        } else if (this.selectedTab === 'tab2') {
          body.catg = this.catgForTab2();
        } else if (this.selectedTab === 'tab3') {
          body.catg = this.catgForTab3();
        } else if (this.selectedTab === 'tab4') {
          body.catg = this.catgForTab4();
        }
      }
      if (body.invStatus === null) {
        if (this.selectedTab === 'tab1') {
          body.invStatus = ['UPLOADED'];
        } else if (this.selectedTab === 'tab2') {
          body.invStatus = ['IRN_GENERATED', 'EWB_GENERATED', 'BOTH'];
        } else if (this.selectedTab === 'tab3') {
          body.invStatus = null;
        } else if (this.selectedTab === 'tab4') {
          body.invStatus = null;
        }
      }
      if (this.selectedTab === 'tab1' || this.selectedTab === 'tab2') {
        body.eligibleForIrn = true;
      } else if (this.selectedTab === 'tab4') {
        body.eligibleForIrn = false;
      }
      this.allFilterData = cloneDeep(body);
      this.generateServices.getGenView(body).subscribe((response: BaseResponse) => {
        this.selectedId = [];
        if (response.status == "SUCCESS") {
          this.viewInvoiceList = response.response.data;
          if (!this.viewInvoiceList.length) {
            this.noDataFound = true;
          }
          this.viewInvoiceList.forEach(element => {
            element.docTypeName = this.docTypeVal.find((x: { value: any; }) => x.value === element.docType).label;
          });
          this.totalElementsVal = response.response.totalElements;
        } else {
          this.toaster.showError(response.message);
          this.noDataFound = true;
        }
      });
    } else {
      this.fetchViewData(this.page, this.size);
    }
  }

  catgForTab1() {
    return ['B2B', 'SEWOP', 'SEWP', 'EXWP', 'EXWOP', 'DE'];
  }
  catgForTab2() {
    return ['B2B', 'SEWOP', 'SEWP', 'EXWP', 'EXWOP', 'DE'];
  }
  catgForTab3() {
    return ['B2C','B2CS', 'B2CL'];
  }
  catgForTab4() {
    return ['B2B', 'DE', 'EXWP', 'EXWOP', 'SEWP', 'SEWOP', 'IMG', 'OTH'];
  }

  getViewData(invoiceId: number) {
    this.flag = true;
    this.router.navigate([`${this.APP_NAME.ONYX}/view-invoice-summary`, invoiceId]);
  }

  showGeneratedStatus(dataId: any) {
    if (dataId != null) {
      this.invoiceSummaryResp = null;
      this.generateServices.getInvoiceSummary(dataId).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.invoiceSummaryResp = response.response;
          this.invoiceSummaryResp.irnStatusVal = this.irnStatus.find((x: { value: any; }) => x.value === this.invoiceSummaryResp.irnStatus).label;
          if (this.invoiceSummaryResp.qrcode) {
            this.imagePath = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
              + this.invoiceSummaryResp.qrcode);
          }
        } else {
          this.toaster.showError(response.message);
        }
      });
    } else {
      this.toaster.showError('Summary details not found.');
      this.closeModal.nativeElement.click();
    }
  }
  showEWBResData(dataId: any) {
    if (dataId != null) {
      this.invoiceSummaryResp = null;
      this.generateServices.getInvoiceSummary(dataId).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.invoiceSummaryResp = response.response;
          if (this.invoiceSummaryResp.invStatus == "EWB_GENERATED") {
            this.invoiceSummaryResp.irnStatusVal = this.irnStatus.find((x: { value: any; }) => x.value === this.invoiceSummaryResp.irnStatus).label;
          }
          if (this.invoiceSummaryResp.qrcode) {
            this.imagePath = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
              + this.invoiceSummaryResp.qrcode);
          }
        } else {
          this.toaster.showError(response.message);
        }
      });
    } else {
      this.toaster.showError('Summary details not found.');
      this.closeModal.nativeElement.click();
    }
  }
  showQrCd(dataId: any) {
    if (dataId != null) {
      this.invoiceSummaryResp = null;
      this.generateServices.getInvoiceSummary(dataId).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.invoiceSummaryResp = response.response;
          if (this.invoiceSummaryResp.qrcode) {
            this.imagePath = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
              + this.invoiceSummaryResp.qrcode);
          }
        } else {
          this.toaster.showError(response.message);
        }
      });
    } else {
      this.toaster.showError('Summary details not found.');
      this.closeModal.nativeElement.click();
    }
  }

  selectAll(event) {
    this.selectedId = [];
    this.selectedIrn = [];
    this.selectedDocNo = [];
    this.selectedItem = [];
    this.selectedIdEsign = [];
    this.viewInvoiceList.forEach(element => {
      if (event.target.checked) {
        if(element.signedPdfLocation) {
          this.selectedIdEsign.push(element.einvId);
        }
        this.selectedId.push(element.einvId);
        this.selectedIrn.push(element.irn);
        this.selectedDocNo.push(element.no);
        this.selectedItem.push(element);
      }
      element['isCheck'] = event.target.checked;
    });
    if (this.selectedId.length == 0) {
      this.isDisabled = true;
    } else {
      this.isDisabled = false;
      if (this.selectedId.length == 1) {
        this.showIrnField = true;
      } else {
        this.showIrnField = false;
      }
    }
  }


  checkIRNhasError() {
    let proceedRequest: boolean = true;
    this.selectedId.forEach((item) => {
      this.viewInvoiceList.forEach((ele) => {
        if (ele.einvId == item) {
          if (ele.hasError || ele.invStatus == 'IRN_GENERATED') {
            proceedRequest = false;
          }
          if (ele.irnStatus == 'CNL') {
            proceedRequest = true;
          }
        }
      })
    })
    return proceedRequest;
  }
  checkIRNhasCancelled() {
    let proceedRequest: boolean = true;
    this.selectedId.forEach((item) => {
      this.viewInvoiceList.forEach((ele) => {
        if (ele.einvId == item) {
          if (ele.irnStatus == 'CNL' || ele.invStatus == 'UPLOADED') {
            // proceedRequest = false;
            this.cnlDisabled = true;
          }
        }
      })
    })
    return proceedRequest;
  }
  checkSingleCtin() {
    let ctin = [];
    this.sameCtin = true;
    this.selectedId.forEach((item) => {
      this.viewInvoiceList.forEach((ele) => {
        if (ele.einvId == item) {
          this.ctinVal = ele.bgstin;
          if (ctin.length != 0) {
            if (ctin.indexOf(ele.bgstin) < 0) {
              this.sameCtin = false;
            }
          } else {
            ctin.push(ele.bgstin);
          }
        }
      })
    })
    return this.ctinVal;
  }

  checkMultipleSelected(item) {
    const ind = this.selectedId.indexOf(item.einvId);
    if (ind === -1) {
      if(item.signedPdfLocation) {
        this.selectedIdEsign.push(item.einvId);
      }
      this.selectedId.push(item.einvId);
      this.selectedIrn.push(item.irn);
      this.selectedDocNo.push(item.no);
      this.selectedItem.push(item);
    } else {
      if(!item.signedPdfLocation) {
        this.selectedIdEsign.splice(ind, 1);
      }
      this.selectedItem.splice(ind, 1);
      this.selectedId.splice(ind, 1);
      this.selectedIrn.splice(ind, 1);
      this.selectedDocNo.splice(ind, 1);
    }
    if (this.selectedId.length == 0) {
      this.isDisabled = true;
    } else {
      this.isDisabled = false;
      if (this.selectedId.length == 1) {
        this.showIrnField = true;
      } else {
        this.showIrnField = false;
      }
    }
    this.actionCheck();
  }

  actionCheck() {
    this.cnlDisabled = false;
    if (!this.selectedId) {
      this.cnlDisabled = true;
    }
  }

  openCancelIrn() {
    if (this.selectedIrn.length > 0) {
      let stringDocNum = this.selectedDocNo.toString();

      this.cancelIrnForm = this.fBuild.group({
        docNumber: [stringDocNum],
        irnNumber: [this.selectedIrn.toString()],
        cnlRsn: [null, [Validators.required]],
        cnlRem: [null, [Validators.required]]
      });
    }
    this.isVisible = true;
  }

  templateFormInitialize() {
    this.templateForm = this.fBuild.group({
      templateName: ['', [Validators.required]],
    });
  }

  getInvoiceNameList() {
    this.generateServices.getAllInvoiceName().subscribe((response: BaseResponse) => {
      this.flagVal = true;
      if (response.status === 'SUCCESS') {
        this.invoiceTemplatesNameList = response.response;
      }
    });
}

  openCancelEwb() {
    this.selectedEwbNo = [];
    if (this.selectedItem.length > 0) {
      this.selectedItem.forEach(element => {
        if (element.invStatus == 'BOTH' || element.invStatus == 'EWB_GENERATED') {
          this.selectedEwbNo.push(element.ewbNo);
        }
      });
      if (this.selectedEwbNo.length > 0) {
        this.cancelEwbForm = this.fBuild.group({
          ewbNo: [this.selectedEwbNo.toString()],
          cnlRsn: [null, [Validators.required]],
          cnlRem: [null]
        });
        this.isVisibleEwb = true;
        this.cnlEwb = 'cancelModalEwb';
      } else {
        this.cnlEwb = null;
        this.toaster.showWarning('Only EWB generated invoices can be cancelled');
        return;
      }
    }
  }

  cancelIRN() {
    // let checkIRNCancel = this.checkIRNhasCancelled();
    // if (checkIRNCancel) {
    this.isSubmitted = true;
    let countValIrn = 0;
    if (this.cancelIrnForm.valid) {
      if (this.selectedIrn.length > 0) {
        this.selectedIrn.forEach((item, index, array) => {
          countValIrn++;
          let model = {
            'irn': item,
            'cnlRsn': this.cancelIrnForm.value.cnlRsn,
            'cnlRem': this.cancelIrnForm.value.cnlRem,
            'userGstin': this.req.gstin
          };
          this.generateServices.cancelIrnData(model).subscribe((response: BaseResponse) => {
            this.closeModal1.nativeElement.click();
            if (response.status == "SUCCESS") {
              this.irnSuccessData.push(response.response);
              this.toaster.showSuccess(response.message);
              // this.fetchViewData(0, this.rows);
              this.tabChanged(this.selectedTab);
            } else {
              if (response.status == "FAILURE") {
                this.irnSuccessData.push({ 'irn': item, 'description': response.errors[0].msg });
                this.tabChanged(this.selectedTab);
                // this.toaster.showError(response.errors[0].msg);
              } else {
                this.toaster.showError(response.message);
              }
            }
            this.cancelIrnForm.reset();
          });
          if (countValIrn === array.length) {
            setTimeout(() => {
              this.openModelEwb();
            }, 2000);
          }
        });
        this.selectedDocNo = [];
        this.irnSuccessData = [];
        this.ewbSuccessData = [];
        this.selectedItem = [];
        this.selectedIrn = [];
        this.isDisabled = false;
        this.isSubmitted = false;
        this.isrequired = false;
      }
    }
    // } else {
    //   this.toaster.showError('IRN cannot be cancelled for the records selected. Cancellation is allowed for records on which IRN is generated in last 24 hours or are not already cancelled.');
    // }
  }
  cancelEwb() {
    this.isSubmitted = true;
    let countVal = 0;
    if (this.cancelEwbForm.valid) {
      if (this.selectedEwbNo.length > 0) {
        this.selectedEwbNo.forEach((item, index, array) => {
          countVal++;
          let model = {
            'ewbNo': item,
            'cnlRsn': this.cancelEwbForm.value.cnlRsn,
            'cnlRem': this.cancelEwbForm.value.cnlRem,
            'userGstin': this.req.gstin
          };
          this.generateServices.cancelEwbData(model).subscribe((response: BaseResponse) => {
            this.closeModal2.nativeElement.click();
            if (response.status == "SUCCESS") {

              this.ewbSuccessData.push(response.response);
              this.toaster.showSuccess(response.message);
              this.tabChanged(this.selectedTab);
            } else {
              if (response.status == "FAILURE") {
                this.ewbSuccessData.push({ 'ewbNo': item, 'description': response.errors[0].msg });
                this.tabChanged(this.selectedTab);
                // this.toaster.showError(response.errors[0].msg);
              } else {
                this.toaster.showError(response.message);
              }
            }
            this.cancelEwbForm.reset();
          });
          if (countVal === array.length) {
            setTimeout(() => {
              this.openModelEwb();
            }, 2000);
          }
        });

        this.selectedEwbNo = [];
        this.ewbSuccessData = [];
        this.selectedItem = [];
        this.irnSuccessData = [];
        this.isDisabled = false;
        this.isSubmitted = false;
        this.isrequired = false;
      }
    }
    // } else {
    //   this.toaster.showError('IRN cannot be cancelled for the records selected. Cancellation is allowed for records on which IRN is generated in last 24 hours or are not already cancelled.');
    // }
  }
  openModelEwb() {
    if (this.ewbSuccessData.length > 0) {
      this.openMode1.nativeElement.click();
    }
    if (this.irnSuccessData.length > 0) {
      this.openMode1.nativeElement.click();
    }
  }
  checkUploadDelete(){
      if (this.selectedId.length) {
        this.deleId = [];
        let count = 0;
        this.selectedItem.forEach(element => {
          if (element.invStatus == 'EWB_GENERATED') {
            count ++
          } else {
            this.deleId.push(element.einvId);
          }
        });
        if(count > 0){
          // this.toaster.showWarning('Only Uploaded invoices will be deleted');
          this.openMode1DelB2cOth.nativeElement.click();
          this.modalHeader = 'Delete';
          if (this.selectedId.length) {
            this.modalBody = `Only Uploaded invoices will be deleted, Are you sure you want to delete?`
          } else {
            this.modalBody = `Only Uploaded invoices will be delete, Are you sure you want to delete?`
          }
        } else {
          this.openMode1DelB2cOth.nativeElement.click();
          this.modalHeader = 'Delete';
          if (this.selectedId.length) {
            this.modalBody = `Only Uploaded invoices will be deleted, Are you sure you want to delete?`
          } else {
            this.modalBody = `Only Uploaded invoices will be delete, Are you sure you want to delete?`
          }
        }

      }else{
        this.openMode1DelB2cOth.nativeElement.click();
        this.modalHeader = 'Delete';
        // if (this.selectedTab === 'tab3' || this.selectedTab === 'tab4') {
        //   this.toaster.showWarning('Only Uploaded invoices will be deleted');
        // }
        if (this.selectedId.length) {
          this.modalBody = `Only Uploaded invoices will be deleted, Are you sure you want to delete?`
        } else {
          this.modalBody = `Only Uploaded invoices will be delete, Are you sure you want to delete?`
        }
      }

  }
  confirmb2cOtherDelete(action) {
    this.closeModalDel.nativeElement.click();
    if (action === 'Delete') {
      this.deleteIRN();

  }
}

  commonModalInitialize(obj) {
    if (obj == 'Generate IRN') {
      this.modalHeader = 'Generate IRN';
      // if (this.selectedId.length) {
      // this.modalBody = `${this.selectedId.length} invoices will be sent for IRN generation. Do you want to continue?`
      this.modalBody = `Invoices with errors, Invoices already having IRN and invoices cancelled will not be sent for IRN generation. Do you want to continue?`
      // }
    }
    if (obj == 'Delete') {
      this.modalHeader = 'Delete';
      if (this.selectedId.length) {
        this.modalBody = `${this.selectedId.length} invoices will be deleted. Are you sure you want to delete?`
      } else {
        this.modalBody = `${this.totalElementsVal} invoices will be deleted. Are you sure you want to delete?`
      }
    }
  }

  confirm(action) {
    this.closeModal.nativeElement.click();
    if (action === 'Generate IRN') {
      this.generateIRN();
    } else if (action === 'Delete') {
      this.deleteIRN();
    }
  }
  deleteIRN() {
    let data = {}
    if (this.selectedId.length > 0 && !(this.selectedTab == 'tab3' || this.selectedTab == 'tab4')) {
      data['ids'] = this.selectedId;
    }
    else if (this.selectedId.length > 0 && (this.selectedTab == 'tab3' || this.selectedTab == 'tab4')) {
      data['ids'] = this.deleId;
    } else {
      data = cloneDeep(this.filterObj);
      if (this.filterObj.no) {
        data['no'] = data['no'].split(',');
      }
      if (data['supplyType']) {
        data['supplyType'] = [data['supplyType']];
      }

      if (this.filterObj.fromDt && this.filterObj.toDt) {
        data['fromDt'] = this.datePipe.transform(this.filterObj.fromDt, 'dd/MM/yyyy');
        data['toDt'] = this.datePipe.transform(this.filterObj.toDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromEWBDate && this.filterObj.toEWBDate) {
        data['fromEWBDate'] = this.datePipe.transform(this.filterObj.fromEWBDate, 'dd/MM/yyyy');
        data['toEWBDate'] = this.datePipe.transform(this.filterObj.toEWBDate, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromIRNCancelledDate && this.filterObj.toIRNCancelledDate) {
        data['fromIRNCancelledDate'] = this.datePipe.transform(this.filterObj.fromIRNCancelledDate, 'dd/MM/yyyy');
        data['toIRNCancelledDate'] = this.datePipe.transform(this.filterObj.toIRNCancelledDate, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromEWBCancelledDate && this.filterObj.toEWBCancelledDate) {
        data['fromEWBCancelledDate'] = this.datePipe.transform(this.filterObj.fromEWBCancelledDate, 'dd/MM/yyyy');
        data['toEWBCancelledDate'] = this.datePipe.transform(this.filterObj.toEWBCancelledDate, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromAckDt && this.filterObj.toAckDt) {
        data['fromAckDt'] = this.datePipe.transform(this.filterObj.fromAckDt, 'dd/MM/yyyy');
        data['toAckDt'] = this.datePipe.transform(this.filterObj.toAckDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromUpDt && this.filterObj.toUpDt) {
        data['fromUpDt'] = this.datePipe.transform(this.filterObj.fromUpDt, 'dd/MM/yyyy');
        data['toUpDt'] = this.datePipe.transform(this.filterObj.toUpDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromCnlDt && this.filterObj.toCnlDt) {
        data['fromCnlDt'] = this.datePipe.transform(this.filterObj.fromCnlDt, 'dd/MM/yyyy');
        data['toCnlDt'] = this.datePipe.transform(this.filterObj.toCnlDt, 'dd/MM/yyyy');
      }
      if(this.selectedTab == 'tab3' || this.selectedTab == 'tab4') {
        data['invStatus'] = ["UPLOADED"];
      }
      if(data['pobCodes']) {
        data['pobCodes'] = data['pobCodes'].toString();
      }
    }
    if (this.getNavContext.entityType == 'FILING') {
      data['companyUniqueCode'] = this.getNavContext.gstin;
    }
    if (this.getNavContext.entityType == 'POB') {
      data['companyUniqueCode'] = this.getNavContext.pobCode;
    }
    data['gstin'] = this.req.gstin;
    this.generateServices.deleteIRN(data).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.toaster.showSuccess(response.response);
        this.fetchViewData(this.page, this.size, this.filterObj);
      } else {
        if (response.status == "FAILURE") {
          if (response.errors) {
            if (response.errors.length > 0) {
              this.toaster.showError(response.errors[0].msg);
            }
          }
          else {
            this.toaster.showError(response.response);
          }
        } else {
          this.toaster.showError(response.message);
        }
      }
    });
    this.selectedItem = [];
    this.deleId = [];
  }

  generateIRN() {
    // let checkIRN = this.checkIRNhasError();
    // if (checkIRN) {
    // let data = this.filterObj;
    let data = {};
    if (this.selectedId.length !== 0) {
      data['ids'] = this.selectedId;
    } else {
      if (this.allFilterData != undefined)
        data = this.allFilterData;
      else
        data = {};
    }
    data['gstin'] = this.req.gstin;
    this.generateServices.generateIRN(data).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.statusFlag = true;
        this.status = false;
        this.genDisabled = true;
        this.addClass();
        // this.checkIRNstatus();
        // this.storageService.setNotifyFlag({ type: 'irn', value: true });
        this.toaster.showSuccess(response.message);
      } else {
        if (response.status == "FAILURE") {
          if (response.errors) {
            if (response.errors.length > 0) {
              this.toaster.showError(response.errors[0].msg);
            }
          }
          else {
            this.toaster.showError(response.response);
          }
        } else {
          this.toaster.showError(response.message);
        }
      }
    });
    // } else {
    //   this.toaster.showError('IRN cannot be generated for the records selected. IRN Generation is allowed for records which do not have any validation errors.');
    // }
  }

  checkIRNstatus() {
    this.addClass();
    this.addSwingClass();
    let gstin = this.req.gstin;
    this.generateServices.generatedIRNstatus(gstin).subscribe((response: BaseResponse) => {
      // this.fetchViewData(this.page, this.size);
      this.removeSwingClass();
      if (response.status == "SUCCESS") {
        if (response.response.status === 'COMPLETE') {
          this.invConsideredCnt = response.response.invConsideredCnt;
          this.invSuccessCnt = response.response.invSuccessCnt;
          this.invFailCnt = response.response.invFailCnt;
          // this.storageService.setIRNStatusData(response.response);
          this.status = true;
          this.genDisabled = false;
        } else if (response.response.status === 'INPROGRESS') {
          this.isDwdCheckStsInprog = true;
          this.status = false;
        } else if (response.response.status === 'NEW') {
          this.status = false;
        }
      } else {
        // this.toaster.showError(response.message);
      }
    });
  }

  generateHistory() {
    this.router.navigate([`${this.APP_NAME.ONYX}/generate-history`]);
  }
  bulkPrintHistory() {
    this.router.navigate([`${this.APP_NAME.ONYX}/bulk-print-history`]);
  }
  bulkPrintHistoryEsign(invoiceId) {
    let data = {
      invId: invoiceId,
      companyUniqueCode: this.req.gstin
    }
    this.disableEsign = true;
    this.generateServices.bulkPrint(data, this.templateForm.value.templateName, 1).subscribe((response: BaseResponse) => {
      this.disableEsign = false;
      if (response.status == "SUCCESS") {
        this.closeModalBulk.nativeElement.click();
        this.toaster.showSuccess(response.message);
        this.router.navigate([`${this.APP_NAME.ONYX}/bulk-print-history`,{ isEsign: true}]);
      } else {
        if (response.status == "FAILURE") {
          if (response.errors) {
            if (response.errors.length > 0) {
              this.toaster.showError(response.errors[0].msg);
            }
          }
          else {
            this.toaster.showError(response.response);
          }
        } else {
          this.toaster.showError(response.message);
        }
      }
      });
  }
  printSummary(invoiceId: any) {
    if (invoiceId.length > 1) {
      this.allSelId = invoiceId;
      this.isMultiple = true;
      this.openModePrint.nativeElement.click();
    } else {
      this.isMultiple = false;
      this.singlePrint = true;
      this.allSelId = invoiceId;
      this.openModePrint.nativeElement.click();
      // this.router.navigate([`${this.APP_NAME.ONYX}/print-summary`, invoiceId[0]]);
    }
  }

  printPDF(invoiceId) {
    if(this.isMultiple){
      this.bulkPrintProcess(invoiceId);
      return;
    }
    this.generateServices.getPrintPDF(invoiceId, this.templateForm.value.templateName)
        .subscribe(x => {
            this.closeModalBulk.nativeElement.click();
            // It is necessary to create a new blob object with mime-type explicitly set
            // otherwise only Chrome works like it should
            const newBlob = new Blob([x], { type: 'application/pdf' });
            this.isMultiple = false;

            // IE doesn't allow using a blob object directly as link href
            // instead it is necessary to use msSaveOrOpenBlob
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(newBlob);
                return;
            }

            // For other browsers:
            // Create a link pointing to the ObjectURL containing the blob.
            const data = window.URL.createObjectURL(newBlob);

            const link = document.createElement('a');
            link.href = data;
            if(this.templateForm.value.templateName){
              link.download = this.templateForm.value.templateName;
            } else {
              link.download = 'Invoice.pdf';
            }
            // this is necessary as link.click() does not work on the latest firefox
            link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

            setTimeout(() => {
                // For Firefox it is necessary to delay revoking the ObjectURL
                window.URL.revokeObjectURL(data);
                link.remove();
            }, 100);
        });
  }

  bulkPrintProcess(invoiceId) {
    this.isSubmitted = true;
    let data = {
      invId: invoiceId,
      companyUniqueCode: this.req.gstin
    }
    // if(this.templateForm.valid) {
      this.generateServices.bulkPrint(data, this.templateForm.value.templateName, 0).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.closeModalBulk.nativeElement.click();
        this.addClass();
        this.toaster.showSuccess(response.message);
      } else {
        if (response.status == "FAILURE") {
          if (response.errors) {
            if (response.errors.length > 0) {
              this.toaster.showError(response.errors[0].msg);
            }
          }
          else {
            this.toaster.showError(response.response);
          }
        } else {
          this.toaster.showError(response.message);
        }
      }
      });
    }

  closeFlag() {
    this.status = false;

  }
  closeDwdDiv() {
    this.checkDwdFlag = false;
  }
  closeMailDiv() {
    this.checkMailFlag = false;
  }

  @HostListener('window:scroll')
  handleScroll() {
    const windowScroll = window.pageYOffset;
    if (windowScroll >= this.elementPosition) {
      this.isSticky = true;
    } else {
      this.isSticky = false;
    }
  }

  download() {
    let data = {}

    if (this.selectedId.length > 0) {
      data['ids'] = this.selectedId;
    } else {
      data = cloneDeep(this.filterObj);
      if (this.selectedTab === 'tab1' || this.selectedTab === 'tab2') {
        data['eligibleForIrn'] = true;
      } else if (this.selectedTab === 'tab4') {
        data['eligibleForIrn'] = false;
      }
      if (this.filterObj.no) {
        data['no'] = data['no'].split(',');
      }
      if (this.filterObj.supplyType) {
        data['supplyType'] = [this.filterObj.supplyType];
      }
      if (this.filterObj.fromDt && this.filterObj.toDt) {
        data['fromDt'] = this.datePipe.transform(this.filterObj.fromDt, 'dd/MM/yyyy');
        data['toDt'] = this.datePipe.transform(this.filterObj.toDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromEWBDate && this.filterObj.toEWBDate) {
        data['fromEWBDate'] = this.datePipe.transform(this.filterObj.fromEWBDate, 'dd/MM/yyyy');
        data['toEWBDate'] = this.datePipe.transform(this.filterObj.toEWBDate, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromIRNCancelledDate && this.filterObj.toIRNCancelledDate) {
        data['fromIRNCancelledDate'] = this.datePipe.transform(this.filterObj.fromIRNCancelledDate, 'dd/MM/yyyy');
        data['toIRNCancelledDate'] = this.datePipe.transform(this.filterObj.toIRNCancelledDate, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromEWBCancelledDate && this.filterObj.toEWBCancelledDate) {
        data['fromEWBCancelledDate'] = this.datePipe.transform(this.filterObj.fromEWBCancelledDate, 'dd/MM/yyyy');
        data['toEWBCancelledDate'] = this.datePipe.transform(this.filterObj.toEWBCancelledDate, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromAckDt && this.filterObj.toAckDt) {
        data['fromAckDt'] = this.datePipe.transform(this.filterObj.fromAckDt, 'dd/MM/yyyy');
        data['toAckDt'] = this.datePipe.transform(this.filterObj.toAckDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromUpDt && this.filterObj.toUpDt) {
        data['fromUpDt'] = this.datePipe.transform(this.filterObj.fromUpDt, 'dd/MM/yyyy');
        data['toUpDt'] = this.datePipe.transform(this.filterObj.toUpDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromCnlDt && this.filterObj.toCnlDt) {
        data['fromCnlDt'] = this.datePipe.transform(this.filterObj.fromCnlDt, 'dd/MM/yyyy');
        data['toCnlDt'] = this.datePipe.transform(this.filterObj.toCnlDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.ewbNo) {
        data['ewbNo'] = this.filterObj.ewbNo.split(',');
      }
      if (this.filterObj.bgstin) {
        data['bgstin']  = this.filterObj.bgstin.split(',');
      }
      if (this.allFilterData.totinvval) {
        data['totinvval']  = this.allFilterData.totinvval;
      }
      if(data['pobCodes']) {
        data['pobCodes'] = data['pobCodes'].toString();
      }
    }
    data['gstin'] = this.req.gstin;
    if (this.getNavContext.entityType == 'FILING') {
      data['companyUniqueCode'] = this.getNavContext.gstin;
    }
    if (this.getNavContext.entityType == 'POB') {
      data['companyUniqueCode'] = this.getNavContext.pobCode;
    }
    this.generateServices.downloadEnv(data).subscribe((response: BaseResponse) => {
      if (response.status === 'SUCCESS') {
        //this.toaster.showSuccess(response.message);
        this.checkStatusFlag = true;
        this.isDownloadClick = true;
        this.dwdDisabled = true;
        this.checkDwdFlag = false;
        this.addClass();
        // this.storageService.setNotifyFlag({ type: 'download', value: true });
      } else {
        this.toaster.showError(response.message);
      }
    })
  }
  downloadRes() {
    let data = {}

    if (this.selectedId.length > 0) {
      data['ids'] = this.selectedId;
    } else {
      data = cloneDeep(this.filterObj);

      if (this.filterObj.no) {
        data['no'] = data['no'].split(',');
      }
      if (this.filterObj.supplyType) {
        data['supplyType'] = [this.filterObj.supplyType];
      }
      if (this.filterObj.fromDt && this.filterObj.toDt) {
        data['fromDt'] = this.datePipe.transform(this.filterObj.fromDt, 'dd/MM/yyyy');
        data['toDt'] = this.datePipe.transform(this.filterObj.toDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromEWBDate && this.filterObj.toEWBDate) {
        data['fromEWBDate'] = this.datePipe.transform(this.filterObj.fromEWBDate, 'dd/MM/yyyy');
        data['toEWBDate'] = this.datePipe.transform(this.filterObj.toEWBDate, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromIRNCancelledDate && this.filterObj.toIRNCancelledDate) {
        data['fromIRNCancelledDate'] = this.datePipe.transform(this.filterObj.fromIRNCancelledDate, 'dd/MM/yyyy');
        data['toIRNCancelledDate'] = this.datePipe.transform(this.filterObj.toIRNCancelledDate, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromEWBCancelledDate && this.filterObj.toEWBCancelledDate) {
        data['fromEWBCancelledDate'] = this.datePipe.transform(this.filterObj.fromEWBCancelledDate, 'dd/MM/yyyy');
        data['toEWBCancelledDate'] = this.datePipe.transform(this.filterObj.toEWBCancelledDate, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromAckDt && this.filterObj.toAckDt) {
        data['fromAckDt'] = this.datePipe.transform(this.filterObj.fromAckDt, 'dd/MM/yyyy');
        data['toAckDt'] = this.datePipe.transform(this.filterObj.toAckDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromUpDt && this.filterObj.toUpDt) {
        data['fromUpDt'] = this.datePipe.transform(this.filterObj.fromUpDt, 'dd/MM/yyyy');
        data['toUpDt'] = this.datePipe.transform(this.filterObj.toUpDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.fromCnlDt && this.filterObj.toCnlDt) {
        data['fromCnlDt'] = this.datePipe.transform(this.filterObj.fromCnlDt, 'dd/MM/yyyy');
        data['toCnlDt'] = this.datePipe.transform(this.filterObj.toCnlDt, 'dd/MM/yyyy');
      }
      if (this.filterObj.ewbNo) {
        data['ewbNo'] = this.filterObj.ewbNo.split(',');
      }
      if (this.filterObj.bgstin) {
        data['bgstin']  = this.filterObj.bgstin.split(',');
      }
      if (this.allFilterData.totinvval) {
        data['totinvval']  = this.allFilterData.totinvval;
      }
      if(this.filterObj.pobCodes) {
        data['pobCodes'] = this.filterObj.pobCodes.toString();
      }
    }
    data['gstin'] = this.req.gstin;
    if (this.getNavContext.entityType == 'FILING') {
      data['companyUniqueCode'] = this.getNavContext.gstin;
    }
    if (this.getNavContext.entityType == 'POB') {
      data['companyUniqueCode'] = this.getNavContext.pobCode;
    }
    this.generateServices.downloadRes(data).subscribe((response: BaseResponse) => {
      if (response.status === 'SUCCESS') {
        //this.toaster.showSuccess(response.message);
        this.checkStatusFlag = true;
        this.isDownloadClickRes = true;
        this.dwdDisabledRes = true;
        this.checkDwdFlagRes = false;
        this.addClass();
        // this.storageService.setNotifyFlag({ type: 'download', value: true });
      } else {
        this.toaster.showError(response.message);
      }
    })
  }
  showEsignNumbers() {
    this.modalBody = ` Please note only the ${this.selectedIdEsign.length} e-signed invoices will be downloaded.`
    this.openModelEsign.nativeElement.click();
  }
  downloadEsign() {
    let data = {}
    if (this.selectedIdEsign.length > 0) {
      data['ids'] = this.selectedIdEsign;
    }

    this.generateServices.downloadEsign(this.selectedIdEsign, this.req.gstin).subscribe((response: BaseResponse) => {
      this.closeModalEsign.nativeElement.click();
      if (response.status === 'SUCCESS') {
        //this.toaster.showSuccess(response.message);
        this.checkStatusFlag = true;
        this.isDownloadClickEsign = true;
        this.dwdDisabledEsign = true;
        this.checkDwdFlagEsign = false;
        this.addClass();
        // this.storageService.setNotifyFlag({ type: 'download', value: true });
      } else {
        this.toaster.showError(response.message);
      }
    })
  }
  checkDwdStatus() {
    this.isDwdCheckStsInprog = true;
    this.addClass();
    this.addSwingClass();
    let data = this.filterObj
    if (this.getNavContext.entityType == 'FILING') {
      data.gstin = this.req.gstin;
    }
    if (this.getNavContext.entityType == 'POB') {
      data.gstin = this.getNavContext.pobCode;
    }
    // data.gstin = this.req.gstin;
    this.generateServices.downloadStatus(data.gstin).subscribe((response: BaseResponse) => {
      this.removeSwingClass();
      this.isDwdCheckStsInprog = false;
      if (response.status == "SUCCESS") {
        if (response.response.status === 'COMPLETED') {
          this.downloadPath = response.response.filePath;
          this.checkStatusFlag = false;
          this.checkDwdFlag = true;
          this.isDownloadClick = false;
          this.dwdDisabled = false;
          // this.toaster.showSuccess(response.message);
        } else if (response.response.status === 'INPROGRESS') {
          this.isDownloadClick = true;
          this.checkDwdFlag = false;
          this.dwdDisabled = true;
        } else {
          // this.toaster.showError(response.message);
        }
      }
    })
  }
  checkDwdStatusRes() {
    this.isDwdCheckStsInprogRes = true;
    this.addClass();
    this.addSwingClass();
    let data = this.filterObj
    if (this.getNavContext.entityType == 'FILING') {
      data.gstin = this.req.gstin;
    }
    if (this.getNavContext.entityType == 'POB') {
      data.gstin = this.getNavContext.pobCode;
    }
    // data.gstin = this.req.gstin;
    this.generateServices.downloadStatusRes(data.gstin).subscribe((response: BaseResponse) => {
      this.removeSwingClass();
      this.isDwdCheckStsInprogRes = false;
      if (response.status == "SUCCESS") {
        if (response.response.status === 'COMPLETED') {
          this.downloadPath = response.response.filePath;
          this.checkStatusFlag = false;
          this.checkDwdFlagRes = true;
          this.isDownloadClickRes = false;
          this.dwdDisabledRes = false;
          // this.toaster.showSuccess(response.message);
        } else if (response.response.status === 'INPROGRESS') {
          this.isDownloadClickRes = true;
          this.checkDwdFlagRes = false;
          this.dwdDisabledRes = true;
        } else {
          // this.toaster.showError(response.message);
        }
      }
    })
  }
  checkDwdStatusEsign() {
    this.isDwdCheckStsInprogEsign = true;
    this.addClass();
    this.addSwingClass();
    let data = this.filterObj
    // if (this.getNavContext.entityType == 'FILING') {
      data.gstin = this.req.gstin;
    // }
    // if (this.getNavContext.entityType == 'POB') {
    //   data.gstin = this.getNavContext.pobCode;
    // }
    // data.gstin = this.req.gstin;
    this.generateServices.downloadStatusEsign(data.gstin).subscribe((response: BaseResponse) => {
      this.removeSwingClass();
      this.isDwdCheckStsInprogEsign = false;
      if (response.status == "SUCCESS") {
        if (response.response) {
          this.downloadPath = response.response;
          this.checkStatusFlag = false;
          this.checkDwdFlagEsign = true;
          this.isDownloadClickEsign = false;
          this.dwdDisabledEsign = false;
          // this.toaster.showSuccess(response.message);
        }
      }
    })
  }
  downloadFile(downloadPath, type) {
    this.removeClass();
    window.location.href = downloadPath;
    this.isDownloadClick = false;
    if(type == '1')
      this.checkDwdFlag = true;
    if(type == '2')
      this.checkDwdFlagRes = true;
    if(type == '3')
      this.checkDwdFlagEsign = true;
  }

  sendMail() {
    let data = {};
    this.checkSingleCtin();
    data['gstin'] = this.req.gstin;
    data['type'] = 'mail-attachment';
    data['userEmail'] = sessionStorage.getItem('UserId');
    if (this.sameCtin) {
      if (this.selectedId.length !== 0) {
        data['ids'] = this.selectedId;
        this.generateServices.checkSendMail(data).subscribe((response: BaseResponse) => {
          if (response.status == "SUCCESS") {
            this.checkMailStatusFlag = true;
            this.isCheckMailSent = true;
            this.mailDisabled = true;
            this.checkMailFlag = false;
            this.addClass();
            this.toaster.showSuccess(response.message);
          } else {
            if (response.status == "FAILURE") {
              this.toaster.showError(response.errors[0].msg);
            } else {
              this.toaster.showError(response.message);
            }
          }
        });
      }
    } else {
      this.toaster.showError('Select same counter party invoices');
    }

  }

  getEmailIds() {
    let model = {
      gstin: this.req.gstin,
      ctin: this.checkSingleCtin(),
      category: 'VENDOR',
    }
    this.generateServices.getMailIds(model).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.getMailIds = response.response;
      } else {
        this.getMailIds = {
          'ccList':[],
          'bccList':[],
          'toList':[]
        };
      }
      this.checkMailStatus();
    });
  }

  checkMailStatus() {
    this.addClass();
    this.addSwingClass();
    let data = {};
    this.ctinVal = this.checkSingleCtin();
    data['gstin'] = this.req.gstin;
    data['type'] = 'mail-attachment';
    this.generateServices.sendMailStatus(data).subscribe((response: BaseResponse) => {
      this.removeSwingClass();
      if (response.status === 'SUCCESS' && response.response != undefined) {
        if (response.response.status == 'COMPLETED') {
          this.mailData = response.response;
          this.mailData['ctin'] = this.ctinVal;
          this.mailData['mailIds'] = this.getMailIds;
          this.checkStatusFlag = false;
          this.checkMailFlag = true;
          this.isCheckMailSent = false;
          this.mailDisabled = false;
          this.toaster.showSuccess(response.message);
        } if (response.response.status == 'INPROGRESS') {
          this.checkStatusFlag = false;
          this.checkMailFlag = false;
          this.isCheckMailSent = true;
          this.mailDisabled = true;
        } else {
          this.toaster.showError(response.message);
        }
      } else {
        this.toaster.showError(response.message);
      }
    })
  }
  sendReadyMail() {
    this.isEmailVisible = true;
  }

  onMailSubmit() {
    this.checkMailSent = this.childSendMail.onSubmit();
    this.generateServices.checkMailSuccess$.subscribe(
      data => {
        if (data) {
          this.closeModalEmail.nativeElement.click();
          this.checkMailFlag = false;
        }
      }, err => {
        console.log('error in getting sucess mail', err);
      }
    )
  }

  getRequired(type) {
    if (type == 'ewb') {
      if (this.cancelEwbForm.value.cnlRsn == '4') {
        this.isrequired = true;
      } else {
        this.isrequired = false;
      }
    }

    this.setValidateRemark(type);
  }

  setValidateRemark(type) {
    if (type == 'ewb') {
      let tempRemark = this.cancelEwbForm.get('cnlRem');
      if (this.isrequired) {
        tempRemark.setValidators([Validators.required]);
      } else {
        tempRemark.clearValidators();
      }
      tempRemark.updateValueAndValidity();
    }
  }
}


// addClass() {
//   const el = document.getElementById('navigation-bar');
//   el.classList.add('show');
// }

// removeClass() {
//   const el = document.getElementById('navigation-bar');
//   el.classList.remove('show');
// }
