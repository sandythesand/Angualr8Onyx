import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GenerateService } from '../../services/generate.service';
import { BaseResponse } from '../../../models/response';
import { ToasterService } from '../../../shared/services/toaster.service';
import { GetterSetterService } from '../../../shared/services/getter-setter.service';

@Component({
  selector: 'app-send-mail',
  templateUrl: './send-mail.component.html',
  styleUrls: ['./send-mail.component.scss']
})
export class SendMailComponent implements OnInit {
  @ViewChild('closeModal1', { static: false }) closeModal1: ElementRef;
  @Input() getMailData: any;
  mailForm: FormGroup;
  init: any;
  body: any;
  subject: any;
  isSubmitted: boolean = false;
  loadCc: any = [];
  loadBcc: any = [];
  loadTo: any = [];
  req: any;
  listData: any = [];

  constructor(
    private fb: FormBuilder,
    private generateServices: GenerateService,
    private toaster: ToasterService,
    private getSet: GetterSetterService
  ) { }

  ngOnInit() {
    this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
    this.loadCc.push({ 'id': 1, 'label': this.getSet.getSetUserId()});
    if(this.getMailData.mailIds.ccList.length > 0) {
      this.getMailData.mailIds.ccList.forEach((element: any, index: any) => {
        this.loadCc.push({ 'id': index + 2, 'label': element})
      });
    }
    if(this.getMailData.mailIds.bccList.length > 0) {
      this.getMailData.mailIds.bccList.forEach((element: any, index1: any) => {
        this.loadBcc.push({ 'id': index1 + 1, 'label': element})
      });
    }
    if(this.getMailData.mailIds.toList.length > 0) {
      this.getMailData.mailIds.toList.forEach((element: any, index2: any) => {
        this.loadTo.push({ 'id': index2 + 1, 'label': element})
      });
    }
    this.init = {
      height: 500,
      menubar: true,
      plugins: [
        'advlist autolink lists link image charmap print',
        'preview anchor searchreplace visualblocks code',
        'fullscreen insertdatetime media table paste',
        'help wordcount'
      ],
      contextmenu: 'link image',
      formats: {
        mark: { selector: 'tr', classes: 'repeatable' }
      },
      external_plugins: {
        'build': 'https://docs-irisgst-com.s3.ap-south-1.amazonaws.com/plugs/plugin.js'
      },
      toolbar:
        'undo redo | formatselect | bold italic | \
        alignleft aligncenter alignright alignjustify | \
        bullist numlist outdent indent| build mark| help'
    };
    this.subject = `IRN Generated for our invoices (On behalf of - ${ this.req.companyname })`;
    this.body = `<p>Dear Customer,</p>
    <p>We have generated IRN for our invoices which have been issued to you.</p>
    <p>Our (Supplier) GSTIN : ${this.getMailData.gstin}</p>
    <p>Your (Recipient) GSTIN : ${this.getMailData.ctin}</p>
    <p>We are sending you IRN generated and other invoice details. The list of invoices can be downloaded from here.</p>
    <p><a href="${this.getMailData.s3Location}">Download Link</a></p>
    <p>Please note</p>
    <p>The link will expire in 7 Days.</p>
    <p>&nbsp;</p>
    <p>Thank you</p>
    <p>This email is generated and sent via IRIS Onyx. Please do not reply to this email. For any queries with respect to invoice and IRN, please contact the person marked in cc in this email</p>`
    this.mailForm = this.fb.group({
      to: [null, [Validators.required]],
      cc: [null],
      bcc: [null],
      subject: [this.subject, [Validators.required]],
      body: [this.body, [Validators.required]],
    });

    this.formInitialize();
  }

  formInitialize() {
    this.mailForm = this.fb.group({
      to: [null, [Validators.required]],
      cc: [null],
      bcc: [null],
      subject: [this.subject, [Validators.required]],
      body: [this.body, [Validators.required]],
    });
    if(this.loadCc.length > 0)
      this.mailForm.get('cc').setValue(this.loadCc.map(x=>x.label));
    if(this.loadTo.length > 0)
      this.mailForm.get('to').setValue(this.loadTo.map(x=>x.label));
    if(this.loadBcc.length > 0)
      this.mailForm.get('bcc').setValue(this.loadBcc.map(x=>x.label));
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.mailForm.valid) {
      let model = {
        'cc': (this.mailForm.value.cc != undefined) ? this.mailForm.value.cc.map((a: any) => a).toString() : null,
        'to': this.mailForm.value.to.map((a: any) => a).toString(),
        'bcc': (this.mailForm.value.bcc != undefined) ? this.mailForm.value.bcc.map((a: any) => a).toString() : null,
        'subject': this.mailForm.value.subject,
        'message': this.mailForm.value.body
      };
      this.generateServices.sendReadyMail(model).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.toaster.showSuccess(response.message);
          this.generateServices.checkMailSuccess$.next(true);
        } else {
          if (response.status == "FAILURE") {
            this.toaster.showError(response.errorList[0].msg);
          } else {
            this.toaster.showError(response.message);
          }
        }
        this.resetForm();
        return true;
      });
    }
  }

  resetForm() {
    this.mailForm.reset();
  }

}
