export class GenerateIRN {
    [x: string]: any;
    gstin?: string;
    totinvval?: TotinvVal;
    catg?: Array<string>;
    no?: any;
    fromDt?: any;
    toDt?: any;
    btrdNm?: string;
    docType?: Array<number>;
    docSt?: Array<number>
    page?: number;
    size?: number;
    ids?: Array<number>;
    fromUpDt?: any;
    toUpDt?: any;
    fromAckDt?: any;
    toAckDt?: any;
    invStatus?: any;
    fromCnlDt?: any;
    toCnlDt?: any;
    blglNm?:any;
    eligibleForIrn?: any;
}

export class BulkDownload {
    [x: string]: any;
    gstin?: string;
    totinvval?: TotinvVal;
    catg?: Array<string>;
    no?: any;
    fromDt?: any;
    toDt?: any;
    btrdNm?: string;
    docType?: Array<number>;
    docSt?: Array<number>
    page?: number;
    size?: number;
    ids?: Array<number>;
    fromUpDt?: any;
    toUpDt?: any;
    fromAckDt?: any;
    toAckDt?: any;
    invStatus?: any;
    fromCnlDt?: any;
    toCnlDt?: any;
    blglNm?:any;
    eligibleForIrn?: any;
    irnGenFromDate?: any;
    irnGenToDate?: any;
}

export class VendorMaster {
  // taxpayerType?: any;
  category?: any;
  status?: any;
  state?: string;
  page?: number;
  size?: number;
  hasError?: any;
  hasWarning?: any;
  ctin?: any;
  ctpy?: any;
  contactPersonName?: any;
  clientCode?: any;
  plantCode?: any;
}

export class TotinvVal {
    eq: number
}
