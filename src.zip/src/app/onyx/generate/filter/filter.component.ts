import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef, Input, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { DOCUMENT_TYPE, DOCUMENT_STATUS, INVOICE_TYPE, IRN_STATUS, ERROR_WARNING_LIST, OPERATOR_LIST, SUPPLY_TYPE, INVOICE_TYPE_B2C, INVOICE_STATUS_IRNEWB, INVOICE_STATUS_OTHER, ESIGN_VALUE } from '../../../shared/constant';
import * as moment from 'moment';
import { ToasterService } from '../../../shared/services/toaster.service';
import { ViewInvoiceComponent } from '../view-invoice/view-invoice.component';
import { GenerateService } from '../../services/generate.service';
import { BusinessEntityService } from 'src/app/shared/services/business-entity.service';
@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {
  @ViewChild('select', { static: false }) select: ElementRef;
  docTypeList: { label: string; value: string; }[];
  docStatusList: { label: string; value: string; }[];
  catgList: { value: string; label: string; }[];
  supplyTypeList: { value: string; key: string; }[];
  fromDate;
  toDate;
  maxDate = new Date();
  irnStatusList: any;
  errorWarnigList: { label: string; value: string; }[];
  operatorList: { value: string; key: string; }[];
  totinvOperator: any;
  itemCountOperator: any;
  filterForm: FormGroup;
  @Output() messageEvent = new EventEmitter<any>();
  @Input() tab: string;
  @Input() filterData: any;
  docToDate: Date;
  toUploadDate: Date;
  toAcknowledgementDate: Date;
  cancelToDate: Date;
  currentYear;
  selectedTab: string;
  subscription: any;
  docDateEwb: Date;
  docDateIrn: Date;
  docDateCnlEwb: Date;
  catgListB2c: any;
  ivStatusListIrnEwb: { label: string; value: string; }[];
  ivStatusListOther: { label: string; value: string; }[];
  pobVal: any;
  pobData: any = [];
  getNavContext: any;
  pobValSubscription: any;
  esignList: { label: string; value: boolean; }[];

  constructor(
    private formBuilder: FormBuilder,
    private toaster: ToasterService,
    private generateServices: GenerateService,
    private bs: BusinessEntityService
  ) {
    this.docTypeList = DOCUMENT_TYPE;
    this.docStatusList = DOCUMENT_STATUS;
    this.catgList = INVOICE_TYPE;
    this.catgListB2c = INVOICE_TYPE_B2C;
    this.supplyTypeList = SUPPLY_TYPE;
    this.ivStatusListIrnEwb = INVOICE_STATUS_IRNEWB;
    this.ivStatusListOther = INVOICE_STATUS_OTHER;
    this.irnStatusList = IRN_STATUS;
    this.errorWarnigList = ERROR_WARNING_LIST;
    this.operatorList = OPERATOR_LIST;
    this.esignList = ESIGN_VALUE;
  }


  ngOnInit() {
    this.getNavContext = JSON.parse(sessionStorage.getItem('navContext'));
    this.pobValSubscription = this.bs.getPobVal().subscribe((value) => {
      if(value) {
        this.pobVal = value.data;
        if (this.getNavContext.entityType == 'FILING') {
          if(this.pobVal.length > 0) {
            this.pobVal.forEach(e=> {
              this.pobData.push({
                'label':e.companyName,
                'value':e.pobCode
              })
            })
          }
        }
      }
    })
    this.setDate();
    this.subscription = this.generateServices.getPageData().subscribe((value) => {

      this.selectedTab = value.tab;
    })
    if (this.getNavContext.entityType == 'POB') {
      this.pobData.push({
        'label':this.getNavContext.entityName,
        'value':this.getNavContext.pobCode
      })
    }

  }

  setDate() {
    this.toDate = new Date();
    this.fromDate = new Date();
    this.fromDate.setDate(this.toDate.getDate() - 15);
    this.currentYear = (new Date()).getFullYear();
  }

  ngOnChanges(changes?: SimpleChanges) {
    if (this.tab === 'tab1' || this.tab === 'tab2') {
      this.catgList.forEach((item, index) => {
        if (item.value === 'B2C') {
          this.catgList.splice(index, 1);
        }
      })
    }
    // console.log(this.filterData,'FILTER DATA');
    this.formInitialize();
  }

  dataConvertion(){
    if (this.filterData.totinvval !== null) {
      for (var key in this.filterData.totinvval) {
        if (this.filterData.totinvval.hasOwnProperty(key)) {
          this.filterData.totinvval = this.filterData.totinvval[key];
        }
      }
    }
    if (this.filterData.itemCount !== null) {
      for (var key in this.filterData.itemCount) {
        if (this.filterData.itemCount.hasOwnProperty(key)) {
          this.filterData.itemCount = this.filterData.itemCount[key];
        }
      }
    }
  }

  formInitialize() {
    console.log(this.filterData, 'FILTER DATA');
    this.dataConvertion();
    this.filterForm = new FormGroup({
      fromDt: new FormControl(this.filterData.fromDt),
      fromEWBDate: new FormControl(this.filterData.fromEWBDate),
      toDt: new FormControl(this.filterData.toDt),
      toEWBDate: new FormControl(this.filterData.toEWBDate),
      no: new FormControl(this.filterData.no),
      ewbNo: new FormControl(this.filterData.ewbNo),
      ackNo: new FormControl(this.filterData.ackNo),
      bgstin: new FormControl(this.filterData.bgstin),
      btrdNm: new FormControl(this.filterData.btrdNm),
      blglNm: new FormControl(this.filterData.blglNm),
      catg: new FormControl(this.filterData.catg),
      supplyType: new FormControl(this.filterData.supplyType),
      docType: new FormControl(this.filterData.docType),
      pobCodes: new FormControl(this.filterData.pobCodes),
      invStatus: new FormControl(this.filterData.invStatus),
      ewbStatus: new FormControl(this.filterData.ewbStatus),
      irnStatus: new FormControl(this.filterData.irnStatus),
      noError: new FormControl(this.filterData.noError),
      hasError: new FormControl(this.filterData.hasError),
      hasWarning: new FormControl(this.filterData.hasWarning),
      hasIrnError: new FormControl(this.filterData.hasIrnError),
      hasEwbError: new FormControl(this.filterData.hasEwbError),
      totinvval: new FormControl(this.filterData.totinvval, (Validators.pattern('^[+-]?([0-9]*[.])?[0-9]+$'))),
      itemCount: new FormControl(this.filterData.itemCount, (Validators.pattern('^[+-]?([0-9]*[.])?[0-9]+$'))),
      fromUpDt: new FormControl(this.filterData.fromUpDt),
      toUpDt: new FormControl(this.filterData.toUpDt),
      fromAckDt: new FormControl(this.filterData.fromAckDt),
      toAckDt: new FormControl(this.filterData.toAckDt),
      fromCnlDt: new FormControl(this.filterData.fromCnlDt),
      fromIRNCancelledDate: new FormControl(this.filterData.fromIRNCancelledDate),
      fromEWBCancelledDate: new FormControl(this.filterData.fromEWBCancelledDate),
      toCnlDt: new FormControl(this.filterData.toCnlDt),
      toIRNCancelledDate: new FormControl(this.filterData.toIRNCancelledDate),
      toEWBCancelledDate: new FormControl(this.filterData.toEWBCancelledDate),
      signedDocuments: new FormControl(this.filterData.signedDocuments),
      dupIrn: new FormControl(this.filterData.dupIrn),
    })
  }



  sendFilter() {
    let data = this.dataTransform();
    // console.log(this.filterForm.value, 'FILTER VALUE');
    if (data) {
      this.generateServices.setPageData({ page: 0, size: 50, tab: this.selectedTab });
      this.messageEvent.emit(this.filterForm.value);
      this.closeFilterModal();
    }
  }

  dataTransform() {
    let fromDate;
    let toDate;
    if (this.filterForm.value.no) {
      this.filterForm.value.no = this.filterForm.value.no.trim();
    }
    if (this.filterForm.value.ewbNo) {
      this.filterForm.value.ewbNo = this.filterForm.value.ewbNo.trim();
    }
    if (this.filterForm.value.bgstin === '') {
      this.filterForm.value.bgstin = null;
    }
    if (this.filterForm.value.bgstin) {
      this.filterForm.value.bgstin = this.filterForm.value.bgstin.trim();
    }
    if (this.filterForm.value.fromDt) {
      fromDate = moment(this.filterForm.value.fromDt);
    }
    if (this.filterForm.value.toDt) {
      toDate = moment(this.filterForm.value.toDt);
    }
    if (this.filterForm.value.fromDt && this.filterForm.value.toDt) {
      fromDate = moment(this.filterForm.value.fromDt);
      toDate = moment(this.filterForm.value.toDt);
      if (!this.checkDateRange(fromDate, toDate, 'Document Date')) {
        return false;
      }
    }
    if (this.filterForm.value.fromAckDt && this.filterForm.value.toAckDt) {
      fromDate = moment(this.filterForm.value.fromAckDt);
      toDate = moment(this.filterForm.value.toAckDt);
      if (!this.checkDateRange(fromDate, toDate, 'Ack Date')) {
        return false;
      }
    }
    if (this.filterForm.value.fromUpDt && this.filterForm.value.toUpDt) {
      fromDate = moment(this.filterForm.value.fromUpDt);
      toDate = moment(this.filterForm.value.toUpDt);
      if (!this.checkDateRange(fromDate, toDate, 'Uploaded Date')) {
        return false;
      }
    }
    if (this.filterForm.value.fromCnlDt && this.filterForm.value.toCnlDt) {
      fromDate = moment(this.filterForm.value.fromCnlDt);
      toDate = moment(this.filterForm.value.toCnlDt);
      if (!this.checkDateRange(fromDate, toDate, 'Cancel Date')) {
        return false;
      }
    }
    if (this.filterForm.value.totinvval) {
      let temp = {};
      temp[`${this.totinvOperator}`] = this.filterForm.value.totinvval;
      this.filterForm.value.totinvval = temp;
    }
    if (this.filterForm.value.itemCount) {
      let temp = {};
      temp[`${this.itemCountOperator}`] = this.filterForm.value.itemCount;
      this.filterForm.value.itemCount = temp;
    }
    if (this.filterForm.value.signedDocuments == 'true') {
      this.filterForm.value.signedDocuments = true;
    }
    if (this.filterForm.value.signedDocuments == 'false') {
      this.filterForm.value.signedDocuments = false;
    }
    if (this.filterForm.value.dupIrn == 'true') {
      this.filterForm.value.dupIrn = true;
    }
    if (this.filterForm.value.dupIrn == 'false') {
      this.filterForm.value.dupIrn = false;
    }
    return this.filterForm.value;
  }

  reset() {
    this.filterForm.reset();
    this.filterData = this.filterForm.value;
    this.setDate();
    if (this.tab === 'tab1') {
      this.filterData.invStatus = ['UPLOADED'];
      this.filterData.catg = this.catgForTab1();
    } else if (this.tab === 'tab2') {
      this.filterData.invStatus = ['IRN_GENERATED', 'EWB_GENERATED'];
      this.filterData.catg = this.catgForTab2();
      this.filterData.fromUpDt = this.fromDate;
      this.filterData.toUpDt = this.toDate;
    } else if (this.tab === 'tab3') {
      this.filterData.catg = this.catgForTab3();
      this.filterData.fromUpDt = this.fromDate;
      this.filterData.toUpDt = this.toDate;
    }else if (this.tab === 'tab4') {
      this.filterData.catg = this.catgForTab4();
      this.filterData.eligibleForIrn = false;
    }
    this.formInitialize();
  }

  catgForTab1() {
    return ['B2B', 'SEWOP', 'SEWP', 'EXWP', 'EXWOP', 'DE'];
  }
  catgForTab2() {
    return ['B2B', 'SEWOP', 'SEWP', 'EXWP', 'EXWOP', 'DE'];
  }
  catgForTab3() {
    return ['B2C', 'B2CS', 'B2CL'];
  }
  catgForTab4() {
    return ['B2B', 'DE', 'EXWP', 'EXWOP', 'SEWP', 'SEWOP'];
  }

  checkDateRange(fromDate, toDate, dateType) {
    if (toDate.diff(fromDate, 'days') > 30) {
      this.toaster.showError(`${dateType} : Max date range allowed: 30 days`)
      return false;
    } else {
      return true;
    }
  }

  resetControl(param) {
    // this.filterForm.get(`${param}`).reset();
    if (param === 'hasError' || param === 'hasWarning' || param === 'hasIrnError' || param === 'hasEwbError' || param === 'noError') {
      this.filterForm.get(`${param}`).patchValue(null);
      this.select['value'].splice(this.select['value'].findIndex((element) => element == param), 1);
    } else if (param === 'docDt') {
      this.filterForm.get(`fromDt`).patchValue(null);
      this.filterForm.get(`toDt`).patchValue(null);
    } else if (param === 'ackDt') {
      this.filterForm.get(`fromAckDt`).patchValue(null);
      this.filterForm.get(`toAckDt`).patchValue(null);
    } else if (param === 'upDt') {
      this.filterForm.get(`fromUpDt`).patchValue(null);
      this.filterForm.get(`toUpDt`).patchValue(null);
    } else if (param === 'cnlDt') {
      this.filterForm.get(`fromCnlDt`).patchValue(null);
      this.filterForm.get(`toCnlDt`).patchValue(null);
    } else if (param === 'cnlDtEwb') {
      this.filterForm.get(`fromEWBCancelledDate`).patchValue(null);
      this.filterForm.get(`toEWBCancelledDate`).patchValue(null);
    } else if (param === 'cnlDtIrn') {
      this.filterForm.get(`fromIRNCancelledDate`).patchValue(null);
      this.filterForm.get(`toIRNCancelledDate`).patchValue(null);
    } else if (param === 'docDtEwb') {
      this.filterForm.get(`fromEWBDate`).patchValue(null);
      this.filterForm.get(`toEWBDate`).patchValue(null);
    } else {
      this.filterForm.get(`${param}`).patchValue(null)
    }
  }

  checkEmptyObj(param) {
    if (this.filterForm.get(`${param}`).value.length === 0)
      this.filterForm.get(`${param}`).patchValue(null);
  }

  totinvvalOperatorSelection(event) {
    this.totinvOperator = event.target.value;
  }
  itemCountOperatorSelection(event) {
    this.itemCountOperator = event.target.value;
  }
  setErrWarnValue(e) {
    let valueList = e.value;

    if (valueList.includes('noError')) {
      this.filterForm.get('noError').patchValue(true);
      this.filterForm.get('hasError').patchValue(false);
      this.filterForm.get('hasIrnError').patchValue(false);
      this.filterForm.get('hasEwbError').patchValue(false);
      this.filterForm.get('hasWarning').patchValue(false);

      if (valueList.includes('hasError')) {
        this.select['value'].splice(this.select['value'].findIndex((element) => element === 'hasError'), 1);
      }
      if (valueList.includes('hasIrnError')) {
        this.select['value'].splice(this.select['value'].findIndex((element) => element === 'hasIrnError'), 1);
      }
      if (valueList.includes('hasEwbError')) {
        this.select['value'].splice(this.select['value'].findIndex((element) => element === 'hasEwbError'), 1);
      }
      if (!valueList.includes('hasWarning')) {
        this.filterForm.get('hasWarning').patchValue(null);
      } else {
        this.filterForm.get('hasWarning').patchValue(true);
      }
      if (!valueList.includes('noError')) {
        this.filterForm.get('noError').patchValue(null);
      } else {
        this.filterForm.get('noError').patchValue(true);
      }
    } else {
      if (valueList.length > 0) {
        if (valueList.length !== 4) {
          this.filterForm.get('hasError').patchValue(null);
          this.filterForm.get('hasIrnError').patchValue(null);
          this.filterForm.get('hasEwbError').patchValue(null);
          this.filterForm.get('hasWarning').patchValue(null);
          this.filterForm.get('noError').patchValue(null);
        }
        valueList.forEach(element => {
          this.filterForm.get(`${element}`).patchValue(true);
        });
      } else {
        this.filterForm.get('hasError').patchValue(null);
        this.filterForm.get('hasIrnError').patchValue(null);
        this.filterForm.get('hasEwbError').patchValue(null);
        this.filterForm.get('hasWarning').patchValue(null);
        this.filterForm.get('noError').patchValue(null);
      }
    }
  }

  closeFilterModal() {
    const el = document.querySelector('.settings-panel');
    el.classList.remove('open');
  }

  dateSelection(type) {
    if(type == 'docDt'){
      this.docToDate = new Date(this.filterForm.value.fromDt);
      this.filterForm.get('toDt').setValue(null);
    }
    if(type == 'upDt'){
      this.toUploadDate = new Date(this.filterForm.value.fromUpDt);
      this.filterForm.get('toUpDt').setValue(null);
    }
    if(type == 'ackDt'){
      this.toAcknowledgementDate = new Date(this.filterForm.value.fromAckDt);
      this.filterForm.get('toAckDt').setValue(null);
    }
    if(type == 'cnlDt'){
      this.cancelToDate = new Date(this.filterForm.value.fromCnlDt);
      this.filterForm.get('toCnlDt').setValue(null);
    }
    if(type == 'docDtEwb'){
      this.docDateEwb = new Date(this.filterForm.value.fromEWBDate);
      this.filterForm.get('toEWBDate').setValue(null);
    }
    if(type == 'cnlDtIrn'){
      this.docDateIrn = new Date(this.filterForm.value.fromIRNCancelledDate);
      this.filterForm.get('toIRNCancelledDate').setValue(null);
    }
    if(type == 'cnlDtEwb'){
      this.docDateCnlEwb = new Date(this.filterForm.value.fromEWBCancelledDate);
      this.filterForm.get('toEWBCancelledDate').setValue(null);
    }
  }

  ngOnDestroy(): void {
    this.pobValSubscription.unsubscribe();
  }

}
