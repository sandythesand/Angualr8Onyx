import { Component, OnInit , Output, EventEmitter, ViewChild, ElementRef, Input, SimpleChanges} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { GenerateService } from 'src/app/onyx/services/generate.service';
import { CATEGORY_LIST, ERROR_WARNING_LIST_VENDOR_MASTER, STATE_LIST, STATUS_LIST, TAXPAYER_TYPE } from 'src/app/shared/constant';

@Component({
  selector: 'app-vendor-master-filter',
  templateUrl: './vendor-master-filter.component.html',
  styleUrls: ['./vendor-master-filter.component.scss']
})
export class VendorMasterFilterComponent implements OnInit {

  @Output() messageEvent = new EventEmitter<any>();
  @Input() tab: string;
  @Input() filterData: any;
  filterForm: FormGroup;
  @ViewChild('select', { static: false }) select: ElementRef;
  categoryList: { key: string; value: string; }[];
  statusList: { key: string; value: string; }[];
  stateList: { stateName: string; stateCode: string; id: number; }[];
  selectedTab: any;
  subscription: any;
  errorWarnigList: { label: string; value: string; }[];
  taxpayerTypeList: { key: string; value: string; }[];

  constructor(
    private generateServices: GenerateService,
  ) { }

  ngOnInit() {
    this.subscription = this.generateServices.getPageData().subscribe((value) => {
      this.selectedTab = value.tab;
    })
  }

  ngOnChanges(changes?: SimpleChanges) {
    this.categoryList = CATEGORY_LIST;
    this.statusList = STATUS_LIST;
    this.stateList = STATE_LIST;
    this.taxpayerTypeList = TAXPAYER_TYPE;
    this.errorWarnigList = ERROR_WARNING_LIST_VENDOR_MASTER;
    this.formInitialize();
  }

  formInitialize() {
    this.filterForm = new FormGroup({
      ctpy: new FormControl(this.filterData.ctpy),
      category: new FormControl(this.filterData.category),
      status: new FormControl(this.filterData.status),
      state: new FormControl(this.filterData.state),
      hasError: new FormControl(this.filterData.hasError),
      hasWarning: new FormControl(this.filterData.hasWarning),
      ctin: new FormControl(this.filterData.ctin),
      contactPersonName: new FormControl(this.filterData.contactPersonName),
      clientCode: new FormControl(this.filterData.clientCode),
      plantCode: new FormControl(this.filterData.plantCode)
    })
  }

  reset() {
    this.filterForm.reset();
    this.filterData = this.filterForm.value;
    this.formInitialize();
  }

  resetControl(param) {
    if (param === 'hasError' || param === 'hasWarning') {
      this.filterForm.get(`${param}`).patchValue(null);
      this.select['value'].splice(this.select['value'].findIndex((element) => element == param), 1);
    } else {
      this.filterForm.get(`${param}`).patchValue(null)
    }
  }

  sendFilter() {
    // let data = this.dataTransform();
    // console.log(this.filterForm.value, 'FILTER VALUE');
    // if (data) {
      this.generateServices.setPageData({ page: 0, size: 10, tab: this.selectedTab });
      this.messageEvent.emit(this.filterForm.value);
      this.closeFilterModal();
    // }
  }

  closeFilterModal() {
    const el = document.querySelector('.settings-panel');
    el.classList.remove('open');
  }

  setErrWarnValue(e) {
    let valueList = e.value;
      if (valueList.length > 0) {
        if (valueList.length !== 4) {
          this.filterForm.get('hasError').patchValue(null);
          this.filterForm.get('hasWarning').patchValue(null);
        }
        valueList.forEach(element => {
          this.filterForm.get(`${element}`).patchValue(true);
        });
      } else {
        this.filterForm.get('hasError').patchValue(null);
        this.filterForm.get('hasWarning').patchValue(null);
      }
  }
}
