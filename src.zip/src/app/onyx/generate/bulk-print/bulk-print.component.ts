import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { BaseResponse } from '../../../models/response';
import { DataTableDirective } from 'angular-datatables';
import { paginationPrams } from '../../../shared/constant';
import { Subject } from 'rxjs';
import { ToasterService } from '../../../shared/services/toaster.service';
import { GetterSetterService } from '../../../shared/services/getter-setter.service';
import { GenerateService } from '../../services/generate.service';
import { APP_NAME } from 'src/app/shared/constant';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-bulk-print',
  templateUrl: './bulk-print.component.html',
  styleUrls: ['./bulk-print.component.scss']
})
export class BulkPrintComponent implements OnInit {

  @ViewChild(DataTableDirective, { static: false })

  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  bulkPrintHistoryList: any = [];
  req: any;
  isBulkUpload: boolean = false;
  page: number = 0;
  size: number = 10;
  code: any;
  p: any
  size1: number = paginationPrams.pageLen;
  rows: number;
  pageOption: any;
  errorId: any;
  totalElementsVal: any;
  noDataFound: Boolean = false;
  navContData: any;
  compID: any;
  isClickable: boolean = false;
  page1: number = 0;

  totalElementsValBulkPrintHistory: any;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  fileUrl: any;
  isEsignVal: any = false;
  bulkPrintHistoryEinvoiceList: any;
  totalElementsValBulkPrintHistoryEinvoice: any;
  esignLink: any;
  isDisable: boolean = false;

  constructor(
    private toaster: ToasterService,
    private router: Router,
    private generateServices: GenerateService,
    private activeSnapShot: ActivatedRoute
  ) {
    this.rows = paginationPrams.pageLen;
    this.pageOption = paginationPrams.pageOption;
    this.APP_NAME = APP_NAME;
    this.isEsignVal = this.activeSnapShot.snapshot.params.isEsign;
  }

  ngOnInit() {
    this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
    if (this.isEsignVal) {
      this.getBulkHistoryEsign(this.page, this.size);
    } else {
      this.initializeData(this.page, this.size);
    }

  }

  initializeData(page?, size?) {
    let req = {
      page: this.page,
      size: this.size,
      companyUniqueCode: this.req.gstin
    }
    this.generateServices.getBulkPrintHistory(req).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.bulkPrintHistoryList = response.response.data;
        this.totalElementsValBulkPrintHistory = response.response.totalElements;
        this.dtTrigger.next();
        if (this.bulkPrintHistoryList.length === 0) {
          this.noDataFound = true;
        }
      } else {
        this.toaster.showError(response.errors[0].msg);
        this.noDataFound = true;
      }
    });
  }

  getBulkHistoryEsign(page?, size?) {
    let req = {
      page: this.page,
      size: this.size,
      companyUniqueCode: this.req.gstin
    }
    this.generateServices.getBulkPrintHistoryEinvoice(req).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.bulkPrintHistoryEinvoiceList = response.response.data;
        this.totalElementsValBulkPrintHistoryEinvoice = response.response.totalElements;
        this.dtTrigger.next();
        if (this.bulkPrintHistoryEinvoiceList.length === 0) {
          this.noDataFound = true;
        }
      } else {
        this.toaster.showError(response.errors[0].msg);
        this.noDataFound = true;
      }
    });
  }

  tabChange(tab) {
    this.noDataFound = false;
    this.page = 0;
    this.size = 10;
    if (tab == '1')
      this.initializeData(this.page, this.size);
    else
      this.getBulkHistoryEsign(this.page, this.size);
  }

  downloadStatus(obj: any, type?, moduleVal?) {
    this.isDisable = true;
    if (type == 'withoutEsign') {
      let req = {
        "id": obj.id,
        "esignFlag": 0
      }
      this.generateServices.downloadFileStatus(req).subscribe((response: BaseResponse) => {
        this.isDisable = false;
        if (response.status === 'SUCCESS') {
          if (type == 'withoutEsign' && moduleVal) {
            this.bulkPrintHistoryEinvoiceList.forEach((item) => {
              if (item.id === obj.id) {
                this.openUrl(response.response);
              }
            })
          } else {
            this.bulkPrintHistoryList.forEach((item) => {
              if (item.id === obj.id) {
                this.openUrl(response.response);
              }
            })
          }
        } else {
          this.toaster.showError(response.message);
        }
      })
    }
    else {
      let req = {
        "id": obj.id,
        "esignFlag": 1
      }
      this.generateServices.downloadFileStatus(req).subscribe((response: BaseResponse) => {
        this.isDisable = false;
        if (response.status === 'SUCCESS') {
          this.bulkPrintHistoryEinvoiceList.forEach((item) => {
            if (item.id === obj.id) {
              this.openUrl(response.response);
            }
          })
        } else {
          this.toaster.showError(response.message);
        }
      })
    }

  }

  downloadFile(data) {
    let req = {
      "id": data.id
    }
    this.generateServices.downloadBulkPrintFile(req).subscribe(x => {
      const newBlob = new Blob([x], { type: 'application/zip' });

      // IE doesn't allow using a blob object directly as link href
      // instead it is necessary to use msSaveOrOpenBlob
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(newBlob);
        return;
      }

      // For other browsers:
      // Create a link pointing to the ObjectURL containing the blob.
      const data = window.URL.createObjectURL(newBlob);

      const link = document.createElement('a');
      link.href = data;
      link.download = 'BulkPrint.zip';
      // this is necessary as link.click() does not work on the latest firefox
      link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

      setTimeout(() => {
        // For Firefox it is necessary to delay revoking the ObjectURL
        window.URL.revokeObjectURL(data);
        link.remove();
      }, 100);
    })
  }

  paginate(event) {
    this.page = event.page;
    this.size = event.rows;
    this.initializeData(this.page, this.size);
  }

  paginateEinv(event) {
    this.page = event.page;
    this.size = event.rows;
    this.getBulkHistoryEsign(this.page, this.size);
  }

  gotoView() {
    this.router.navigate([`${this.APP_NAME.ONYX}/generate`])
  }

  openDSCTokenLink(obj) {
    this.generateServices.getEsignLink(obj.id).subscribe((response: any) => {
      if (response.status == "SUCCESS") {
        this.esignLink = response.response;
        this.openUrl(this.esignLink);
      } else {
        this.toaster.showError(response.errors[0].msg);
      }
    });
  }

  openUrl(url) {
    window.open(url, '_blank');
  }

}
