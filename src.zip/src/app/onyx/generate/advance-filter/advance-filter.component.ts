import { Component, OnInit, Output, EventEmitter, ElementRef, ViewChild, Input, SimpleChanges } from '@angular/core';
import { AdvanceFilterService } from '../../services/advance-filter.service';
import { BaseResponse } from '../../../models/response';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { DOCUMENT_TYPE, DOCUMENT_STATUS, INVOICE_TYPE, IRN_STATUS, ERROR_WARNING_LIST, OPERATOR_LIST, SUPPLY_TYPE, INVOICE_STATUS_IRNEWB, INVOICE_STATUS_OTHER, INVOICE_TYPE_B2C } from '../../../shared/constant';
import { ToasterService } from '../../../shared/services/toaster.service';
import * as moment from 'moment';
@Component({
  selector: 'app-advance-filter',
  templateUrl: './advance-filter.component.html',
  styleUrls: ['./advance-filter.component.scss']
})
export class AdvanceFilterComponent implements OnInit {

  filterList = [];
  filterForm: FormGroup;
  flag: boolean;
  docTypeList: { label: string; value: string; }[];
  docStatusList: { label: string; value: string; }[];
  catgList: { value: string; label: string; }[];
  supplyTypeList: { value: string; key: string; }[];
  irnStatusList: { label: string; value: string; }[];
  errorWarnigList: { label: string; value: string; }[];
  operatorList: { value: string; key: string; }[];
  itemCountOperator: any;
  totinvOperator: any;
  maxDate = new Date();
  @Output() messageEvent = new EventEmitter<any>();
  @Input() filterData: any;
  @Input() tab: string;
  @ViewChild('select', { static: false }) select: ElementRef;
  docToDate: Date;
  toUploadDate: Date;
  toAcknowledgementDate: Date;
  cancelToDate: Date;
  currentYear;
  docDateEwb: Date;
  docDateIrn: Date;
  docDateCnlEwb: Date;
  catgListB2c: any;
  ivStatusListIrnEwb: { label: string; value: string; }[];
  ivStatusListOther: { label: string; value: string; }[];

  constructor(
    private AFS: AdvanceFilterService,
    private fb: FormBuilder,
    private toaster: ToasterService
  ) {
    this.docTypeList = DOCUMENT_TYPE;
    this.docStatusList = DOCUMENT_STATUS;
    this.catgList = INVOICE_TYPE;
    this.catgListB2c = INVOICE_TYPE_B2C;
    this.ivStatusListIrnEwb = INVOICE_STATUS_IRNEWB;
    this.ivStatusListOther = INVOICE_STATUS_OTHER;
    this.irnStatusList = IRN_STATUS;
    this.errorWarnigList = ERROR_WARNING_LIST;
    this.operatorList = OPERATOR_LIST;
    this.supplyTypeList = SUPPLY_TYPE;
  }

  ngOnInit() {
    const userid = sessionStorage.getItem('UserId');
    this.maxDate = new Date();
    this.fetchInitials(userid);
    this.formInitialize();
    this.currentYear = (new Date()).getFullYear();
  }


  ngOnChanges(changes: SimpleChanges) {
    if (this.tab === 'tab1' || this.tab === 'tab2') {
      this.catgList.forEach((item, index) => {
        if (item.value === 'B2C') {
          this.catgList.splice(index, 1);
        }
      })
    }
    this.formInitialize();
  }

  formInitialize() {
    this.filterForm = new FormGroup({
      fromDt: new FormControl(this.filterData.fromDate),
      fromEWBDate: new FormControl(this.filterData.fromEWBDate),
      toDt: new FormControl(this.filterData.toDate),
      toEWBDate: new FormControl(this.filterData.toEWBDate),
      ackNo: new FormControl(this.filterData.ackNo),
      no: new FormControl(null),
      bgstin: new FormControl(null),
      btrdNm: new FormControl(null),
      blglNm: new FormControl(null),
      catg: new FormControl(this.filterData.catg),
      docType: new FormControl(null),
      invStatus: new FormControl(this.filterData.invStatus),
      irnStatus: new FormControl(null),
      ewbStatus: new FormControl(this.filterData.ewbStatus),
      hasError: new FormControl(null),
      hasWarning: new FormControl(null),
      hasIrnError: new FormControl(null),
      totinvval: new FormControl(null, (Validators.pattern('^[+-]?([0-9]*[.])?[0-9]+$'))),
      itemCount: new FormControl(null, (Validators.pattern('^[+-]?([0-9]*[.])?[0-9]+$'))),
      fromUpDt: new FormControl(this.filterData.fromUpDt),
      toUpDt: new FormControl(this.filterData.toUpDt),
      fromAckDt: new FormControl(this.filterData.fromAckDt),
      toAckDt: new FormControl(this.filterData.toAckDt),
      fromCnlDt: new FormControl(null),
      fromIRNCancelledDate: new FormControl(this.filterData.fromIRNCancelledDate),
      fromEWBCancelledDate: new FormControl(this.filterData.fromEWBCancelledDate),
      toIRNCancelledDate: new FormControl(this.filterData.toIRNCancelledDate),
      toEWBCancelledDate: new FormControl(this.filterData.toEWBCancelledDate),
      toCnlDt: new FormControl(null),
      supplyType: new FormControl(this.filterData.supplyType),
    })
  }

  fetchInitials(userid) {
    this.AFS.fetchData(userid).subscribe((response: BaseResponse) => {
      this.filterList = [];
      if (response.status === 'SUCCESS') {
        if (response.response.filterPrefs) {
          this.filterList = response.response.filterPrefs;
        }
        if (this.filterList.length > 0) {
          this.filterList.forEach((element, index) => {
            this.filterList.splice(index, 1, element.trim());
          });
        }
      }
    })
  }

  totinvvalOperatorSelection(event) {
    this.totinvOperator = event.target.value;
  }
  itemCountOperatorSelection(event) {
    this.itemCountOperator = event.target.value;
  }
  sendFilter() {
    let data = this.dataTransform();
    // console.log(this.filterForm.value, 'FILTER VALUE');
    if (data) {
      this.messageEvent.emit(this.filterForm.value);
      this.closeFilterModal();
    }
  }

  dataTransform() {
    let fromDate;
    let toDate;
    if (this.filterForm.value.no) {
      this.filterForm.value.no = this.filterForm.value.no.trim();
    }
    if (this.filterForm.value.bgstin) {
      this.filterForm.value.bgstin = this.filterForm.value.bgstin.trim();
    }
    if (this.filterForm.value.fromDt && this.filterForm.value.toDt) {
      fromDate = moment(this.filterForm.value.fromDt);
      toDate = moment(this.filterForm.value.toDt);
      if (!this.checkDateRange(fromDate, toDate, 'Document Date')) {
        return false;
      }
    }
    if (this.filterForm.value.bgstin === '') {
      this.filterForm.value.bgstin = null;
    }
    if (this.filterForm.value.fromAckDt && this.filterForm.value.toAckDt) {
      fromDate = moment(this.filterForm.value.fromAckDt);
      toDate = moment(this.filterForm.value.toAckDt);
      if (!this.checkDateRange(fromDate, toDate, 'Ack Date')) {
        return false;
      }
    }
    if (this.filterForm.value.fromUpDt && this.filterForm.value.toUpDt) {
      fromDate = moment(this.filterForm.value.fromUpDt);
      toDate = moment(this.filterForm.value.toUpDt);
      if (!this.checkDateRange(fromDate, toDate, 'Uploaded Date')) {
        return false;
      }
    }
    if (this.filterForm.value.fromCnlDt && this.filterForm.value.toCnlDt) {
      fromDate = moment(this.filterForm.value.fromCnlDt);
      toDate = moment(this.filterForm.value.toCnlDt);
      if (!this.checkDateRange(fromDate, toDate, 'Cancel Date')) {
        return false;
      }
    }
    if (this.filterForm.value.totinvval) {
      let temp = {};
      temp[`${this.totinvOperator}`] = this.filterForm.value.totinvval;
      this.filterForm.value.totinvval = temp;
    }
    if (this.filterForm.value.itemCount) {
      let temp = {};
      temp[`${this.itemCountOperator}`] = this.filterForm.value.itemCount;
      this.filterForm.value.itemCount = temp;
    }
    return this.filterForm.value;
  }


  checkDateRange(fromDate, toDate, dateType) {
    if (toDate.diff(fromDate, 'days') > 30) {
      this.toaster.showError(`${dateType} : Max date range allowed: 30 days`)
      return false;
    } else {
      return true;
    }
  }


  setErrWarnValue(e) {
    let valueList = e.value;

    if (valueList.includes('noError')) {
      this.filterForm.get('hasError').patchValue(false);
      this.filterForm.get('hasIrnError').patchValue(false);
      if (valueList.includes('hasError')) {
        this.select['value'].splice(this.select['value'].findIndex((element) => element === 'hasError'), 1);
      }
      if (valueList.includes('hasIrnError')) {
        this.select['value'].splice(this.select['value'].findIndex((element) => element === 'hasIrnError'), 1);
      }
      if (!valueList.includes('hasWarning')) {
        this.filterForm.get('hasWarning').patchValue(null);
      } else {
        this.filterForm.get('hasWarning').patchValue(true);
      }
    } else {
      if (valueList.length > 0) {
        if (valueList.length !== 3) {
          this.filterForm.get('hasError').patchValue(null);
          this.filterForm.get('hasIrnError').patchValue(null);
          this.filterForm.get('hasWarning').patchValue(null);
        }
        valueList.forEach(element => {
          this.filterForm.get(`${element}`).patchValue(true);
        });
      } else {
        this.filterForm.get('hasError').patchValue(null);
        this.filterForm.get('hasIrnError').patchValue(null);
        this.filterForm.get('hasWarning').patchValue(null);
      }
    }
  }

  reset() {
    this.filterForm.reset();
    this.formInitialize();
  }

  resetControl(param) {
    // this.filterForm.get(`${param}`).reset();
    if (param === 'hasError' || param === 'hasWarning' || param === 'hasIrnError') {
      this.filterForm.get(`${param}`).patchValue(null);
      this.select['value'].splice(this.select['value'].findIndex((element) => element == param), 1);
    } else if (param === 'docDt') {
      this.filterForm.get(`fromDt`).patchValue(null);
      this.filterForm.get(`toDt`).patchValue(null);
    } else if (param === 'ackDt') {
      this.filterForm.get(`fromAckDt`).patchValue(null);
      this.filterForm.get(`toAckDt`).patchValue(null);
    } else if (param === 'upDt') {
      this.filterForm.get(`fromUpDt`).patchValue(null);
      this.filterForm.get(`toUpDt`).patchValue(null);
    } else if (param === 'cnlDt') {
      this.filterForm.get(`fromCnlDt`).patchValue(null);
      this.filterForm.get(`toCnlDt`).patchValue(null);
    } else if (param === 'cnlDtEwb') {
      this.filterForm.get(`fromEWBCancelledDate`).patchValue(null);
      this.filterForm.get(`toEWBCancelledDate`).patchValue(null);
    } else if (param === 'cnlDtIrn') {
      this.filterForm.get(`fromIRNCancelledDate`).patchValue(null);
      this.filterForm.get(`toIRNCancelledDate`).patchValue(null);
    } else if (param === 'docDtEwb') {
      this.filterForm.get(`fromEWBDate`).patchValue(null);
      this.filterForm.get(`toEWBDate`).patchValue(null);
    } else {
      this.filterForm.get(`${param}`).patchValue(null)
    }
  }

  closeFilterModal() {
    const el = document.querySelector('#quickSort');
    el.classList.remove('open');
  }

  dateSelection(type) {
    if(type == 'docDt'){
      this.docToDate = new Date(this.filterForm.value.fromDt);
      this.filterForm.get('toDt').setValue(null);
    }
    if(type == 'upDt'){
      this.toUploadDate = new Date(this.filterForm.value.fromUpDt);
      this.filterForm.get('toUpDt').setValue(null);
    }
    if(type == 'ackDt'){
      this.toAcknowledgementDate = new Date(this.filterForm.value.fromAckDt);
      this.filterForm.get('toAckDt').setValue(null);
    }
    if(type == 'cnlDt'){
      this.cancelToDate = new Date(this.filterForm.value.fromCnlDt);
      this.filterForm.get('toCnlDt').setValue(null);
    }
    if(type == 'docDtEwb'){
      this.docDateEwb = new Date(this.filterForm.value.fromEWBDate);
      this.filterForm.get('toEWBDate').setValue(null);
    }
    if(type == 'cnlDtIrn'){
      this.docDateIrn = new Date(this.filterForm.value.fromIRNCancelledDate);
      this.filterForm.get('toIRNCancelledDate').setValue(null);
    }
    if(type == 'cnlDtEwb'){
      this.docDateCnlEwb = new Date(this.filterForm.value.fromEWBCancelledDate);
      this.filterForm.get('toEWBCancelledDate').setValue(null);
    }
  }

}