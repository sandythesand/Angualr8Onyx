import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { DataTableDirective } from "angular-datatables";
import { FileUploader } from "ng2-file-upload";
import { Subject } from "rxjs";
import { BaseResponse } from "src/app/models/response";
import { paginationPrams } from "src/app/shared/constant";
import { GetterSetterService } from "src/app/shared/services/getter-setter.service";
import { ToasterService } from "src/app/shared/services/toaster.service";
import { UploadService } from "../services/upload.service";
import { VendorMaster } from "../generate/genrate.modal";
import * as cloneDeep from 'lodash/cloneDeep';

@Component({
  selector: "app-master",
  templateUrl: "./master.component.html",
  styleUrls: ["./master.component.scss"],
})
export class MasterComponent implements OnInit {
  uploader: FileUploader;
  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  selectedTab: string = "tab1";
  navContData: any;
  compID: any;
  code: any;
  req: any;
  page1: number = 0;
  size1: number = paginationPrams.pageLen;
  uploadHistoryList: any = [];
  totalElementsValUploadHistory: any;
  noDataFound: boolean = false;
  pageOption: number[];
  page: number = 0;
  size: number = paginationPrams.pageLen;
  errorId: any;
  errorList: any = [];
  totalElementsVal: any;
  rows: number;
  selectedFile: any;
  formData: FormData = new FormData();
  @ViewChild("file", { static: false }) file: ElementRef;
  isClickable: boolean = false;
  page2: number = 0;
  size2: number = paginationPrams.pageLen;
  viewVendorMaster: any = [];
  totalElementsValMasterView: any;
  noDataFoundMasterView: boolean = false;
  allChecked: boolean = false;
  requestInit: boolean = false;
  selectedId = [];
  selectedItemListId: any = {};
  @ViewChild("openMode1DelB2cOth", { static: false })
  openMode1DelB2cOth: ElementRef;
  @ViewChild("closeModalDel", { static: false }) closeModalDel: ElementRef;
  modalHeader: string;
  modalBody: string;
  selectedItemListIdsVal = [];
  parentVal: any;
  filterData: any;
  filterObj = new VendorMaster();
  flag: boolean = false;
  errors: any = [];

  constructor(
    private getSet: GetterSetterService,
    private uploadService: UploadService,
    private toaster: ToasterService
  ) {
    this.loadScripts();
    this.rows = paginationPrams.pageLen;
    this.pageOption = paginationPrams.pageOption;
  }

  loadScripts() {
    const externalScriptArray = ["../assets/js/settings.js"];
    for (let i = 0; i < externalScriptArray.length; i++) {
      const scriptTag = document.createElement("script");
      scriptTag.src = externalScriptArray[i];
      scriptTag.type = "text/javascript";
      scriptTag.async = false;
      scriptTag.charset = "utf-8";
      document.getElementsByTagName("head")[0].appendChild(scriptTag);
    }
  }

  ngOnInit() {
    this.navContData = JSON.parse(this.getSet.getNavContextData());
    if (this.navContData.entityType == "Business") {
      this.compID = this.getSet.getSetCompanyId();
    } else {
      this.compID = this.navContData.companyId;
    }
    if (
      this.navContData.entityType == "Business" ||
      this.navContData.entityType == "LEGAL"
    ) {
      this.code = this.navContData.pan;
    } else {
      this.req = JSON.parse(sessionStorage.getItem("selectedFilling"));
      this.code = this.req.gstin;
    }
    this.initializeUploadHistory();
  }

  initializeUploadHistory() {
    if (this.code != null) {
      let req = {
        code: this.code,
        page: this.page1,
        size: this.size1,
      };
      this.uploadService
        .getUploadHistoryMaster(req)
        .subscribe((response: BaseResponse) => {
          if (response.status == "SUCCESS") {
            this.uploadHistoryList = response.response.data;
            this.totalElementsValUploadHistory =
              response.response.totalElements;
            this.dtTrigger.next();
            if (this.uploadHistoryList.length === 0) {
              this.noDataFound = true;
            }
          } else {
            this.toaster.showError(response.message);
            this.noDataFound = true;
          }
        });
    } else {
      this.toaster.showError("GSTIN number not found.");
    }
  }

  tabChanged(tab, check?) {
    this.filterObj = {};
    this.selectedTab = tab;
    if (this.selectedTab === "tab1") {
      // this.checkStatus('gstr1');
    } else if (this.selectedTab === "tab2") {
      this.fetchView();
    }
  }

  receiveFilter(event) {
    this.filterObj = cloneDeep(event);
    this.fetchView(this.filterObj);
  }

  fetchView(filterObj?) {
    if(filterObj == undefined){
      filterObj = {};
    }
    if (this.code != null) {
      let model = cloneDeep(filterObj);
      model['companyId'] = this.req.id;
      model['companyUniqueCode'] = this.code;
      model['page'] = this.page2;
      model['size'] = this.size2;
      this.uploadService
        .fetchMasterView(model)
        .subscribe((response: BaseResponse) => {
          if (response.status == "SUCCESS") {
            this.noDataFoundMasterView = false;
            this.viewVendorMaster = response.response.data;
            this.totalElementsValMasterView = response.response.totalElements;
            this.dtTrigger.next();
            if (this.viewVendorMaster.length === 0) {
              this.noDataFoundMasterView = true;
            }
          } else {
            this.toaster.showError(response.message);
            this.noDataFoundMasterView = false;
          }
        });
    } else {
      this.toaster.showError("GSTIN number not found.");
    }
  }
  fetchDetails() {
    if (this.req.id != null) {
      let req = {
        companyUniqueCode: this.code,
        idList: this.getUnique(this.selectedItemListId)
      };
      this.requestInit = true;
      this.uploadService
        .fetchDetailsVendorMaster(req)
        .subscribe((response: BaseResponse) => {
          this.requestInit = false;
          if (response.status == "SUCCESS") {
            this.toaster.showSuccess(response.message);
            this.fetchView();
          } else {
            this.toaster.showError(response.message);
          }
        });
    } else {
      this.toaster.showError("GSTIN number not found.");
    }
  }

  download() {
    if(this.filterObj == undefined){
      this.filterObj = {};
    }
    if (this.req.id != null) {
      let model = cloneDeep(this.filterObj);
      model['companyId'] = this.req.id;
      model['companyUniqueCode'] = this.code;
      model['page'] = this.page2;
      model['size'] = this.size2;
      this.requestInit = true;
      this.uploadService.downloadMaster(model).subscribe((response) => {
        this.requestInit = false;
        this.downloadFile(response);
      });
    } else {
      this.toaster.showError("GSTIN number not found.");
    }
  }

  downloadFile(data: any) {
    let blob = new Blob([data], { type: 'application/octet-stream' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", `Vendor_Master_${this.code}.csv`);
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  selectAll(event, listId) {
    this.selectedItemListId = {};
    this.viewVendorMaster.forEach((element1) => {
      element1.vendorMasterItemList.forEach((element2) => {
        if (element2.vendorIdFk === listId) {
          element2["ischeck"] = event.target.checked;
        }
      });
    });
  }

  checkMultipleSelected(event, childItem, parentId) {
    if (event.srcElement.checked) {
      childItem.ischeck = true;
    } else {
      childItem.ischeck = false;
    }
  }
  paginate(event) {
    this.page = event.page;
    this.size = event.rows;
    this.errorDetail(this.errorId, this.page, this.size);
  }

  paginateUploadHistory(event) {
    this.page1 = event.page;
    this.size1 = event.rows;
    this.initializeUploadHistory();
  }

  paginateMasterView(event) {
    this.page2 = event.page;
    this.size2 = event.rows;
    this.fetchView();
  }

  errorDetail(uploadId, page?, size?) {
    this.page = 0;
    this.errorId = uploadId;
    if (uploadId != null) {
      this.uploadService
        .getErrorDetailsMaster(uploadId, page, size)
        .subscribe((response: BaseResponse) => {
          if (response.status == "SUCCESS") {
            this.errorList = response.response.data;
            this.totalElementsVal = response.response.totalElements;
            this.dtTrigger.next();
          } else {
            this.toaster.showError(response.message);
          }
        });
    } else {
      this.toaster.showError("Upload Id is not valid.");
    }
  }

  onFileSelect(event) {
    if (event.target.files[0] !== undefined) {
      if (this.checkExtensionFunction(event.target.files[0], ["csv", "zip"])) {
        this.selectedFile = event.target.files[0];
        this.formData.append("file", this.selectedFile);
      } else {
        this.selectedFile = null;
        this.toaster.showError("This file type is not supported");
      }
    } else {
      this.toaster.showError("File is not selected");
    }
  }

  checkExtensionFunction(selectedFile, extensionAllowedArray) {
    // extensionAllowedArray --- ['csv','pdf']
    let checkExtensions = false;
    const extensionArray = selectedFile.name.split(".");
    const extension = extensionArray[extensionArray.length - 1].toLowerCase();
    extensionAllowedArray.forEach((element) => {
      if (element == extension) {
        checkExtensions = true;
      }
    });
    return checkExtensions;
  }

  upload() {
    this.isClickable = true;
    this.uploadService
      .uploadFileMaster(this.formData, this.code)
      .subscribe((response) => {
        this.isClickable = false;
        if (response.status === "SUCCESS") {
          this.file.nativeElement.value = null;
          this.selectedFile = null;
          this.formData = new FormData();
          this.toaster.showSuccess(response.message);
          this.initializeUploadHistory();
        } else {
          this.toaster.showError(response.message);
        }
      });
  }

  deleteDta(type) {
    this.selectedItemListId = {};
    for (var i = 0; i < this.viewVendorMaster.length; i++) {
      var master = this.viewVendorMaster[i];
      for (var j = 0; j < master.vendorMasterItemList.length; j++) {
        if (
          master.vendorMasterItemList[j] != null &&
          master.vendorMasterItemList[j]["ischeck"] != null
        ) {
          if(master.vendorMasterItemList[j]["ischeck"]){
            var childItem = master.vendorMasterItemList[j];
          if (this.selectedItemListId == null) {
            this.selectedItemListId = {};
            this.selectedItemListId[childItem.vendorIdFk] = [childItem.id];
          } else if (this.selectedItemListId[childItem.vendorIdFk] == null) {
            this.selectedItemListId[childItem.vendorIdFk] = [childItem.id];
          } else if (this.selectedItemListId[childItem.vendorIdFk] != null) {
            var childs = this.selectedItemListId[childItem.vendorIdFk];
            childs.push(childItem.id);
          }
          }

        }
      }
    }
    if (!this.isEmpty(this.selectedItemListId) && type === 'deleteData') {
      this.openMode1DelB2cOth.nativeElement.click();
      this.modalHeader = "Delete";
      this.modalBody = `Selected records will be deleted, Are you sure you want to delete?`;
    } else if( type === 'fetchData' && !this.isEmpty(this.selectedItemListId)) {
      this.fetchDetails();
    } else {
      this.toaster.showWarning("Select atlease single record to delete");
      return;
    }
  }

  confirmb2cOtherDelete(action) {
    this.closeModalDel.nativeElement.click();
    if (action === "Delete") {
      this.deleteInvoices();
    }
  }

  getViewData(val:any) {
    this.errors = val;
  }

  deleteInvoices() {
    this.requestInit = true;
    let data = {};
    data["ids"] = this.getUnique(this.selectedItemListId);
    data["itemIds"] = this.selectedItemListId;
    data["companyId"] = this.req.id;
    data["companyUniqueCode"] = this.code;
    this.uploadService
      .deleteInvoices(data)
      .subscribe((response: BaseResponse) => {
        this.requestInit = false;
        if (response.status == "SUCCESS") {
          this.toaster.showSuccess(response.message);
          this.fetchView();
        } else {
          if (response.status == "FAILURE") {
            if (response.errors) {
              if (response.errors.length > 0) {
                this.toaster.showError(response.errors[0].msg);
              }
            } else {
              this.toaster.showError(response.response);
            }
          } else {
            this.toaster.showError(response.message);
          }
        }
      });
    this.selectedItemListId = {};
  }

  getUnique(Obj) {
    var uniqueArray = [];
    // Loop through array values
    for (let value of Object.keys(Obj)) {
      uniqueArray.push(value);
    }
    return uniqueArray;
  }

  isEmpty(obj) {
    for(var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
    }
    return true;
}
}
