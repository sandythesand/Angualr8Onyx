import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../shared/services/common.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { GetterSetterService } from '../../shared/services/getter-setter.service';
import { InvoiceRepoServiceService } from '../services/invoice-repo-service.service';
import { BaseResponse } from '../../models/response';
import { ToasterService } from '../../shared/services/toaster.service';
import { UploadService } from '../services/upload.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { BusinessEntityService } from '../../shared/services/business-entity.service';
import { BULK_FILTERS, DEFAULT_FILTER, MOTHNS_VAL, paginationPrams } from '../../shared/constant';
import { DatePipe } from '@angular/common';
import { BulkDownload } from '../generate/genrate.modal';
import * as cloneDeep from 'lodash/cloneDeep';

@Component({
  selector: 'app-invoice-repository',
  templateUrl: './invoice-repository.component.html',
  styleUrls: ['./invoice-repository.component.scss']
})
export class InvoiceRepositoryComponent implements OnInit {
  invoiceRepoForm: FormGroup;
  filingData: any;
  navContData: any;
  req: any;
  code: any;
  statusFlag: boolean = false;
  isDwdCheckStsInprog: boolean = false;
  checkDwdFlag: boolean = false;
  downloadPath: any;
  disableButton: boolean = false;
  requestInit: boolean = false;
  selectedTab: any;
  downloadPathEwb: any;
  statusFlagEwb: boolean = false;
  checkDwdFlagEwb: boolean = false;
  disableButtonEwb: boolean = false;
  compID: any;
  ewbTitle: string;
  gstr1Title: string;
  statusFlagTime: boolean = false;
  statusFlagTimeEwb: boolean = false;
  gstr1ReqTime: any;
  gstr1CompleteTime: any;
  ewbCompleteTime: any;
  ewbReqTime: any;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  bulkData: any;
  bsEntitySubscribe: any;
  gstinData: any;
  gstinDataVal: any;
  filingPeriodDates: any;
  monthVal: { name: string; value: string; }[];
  page: number = 0;
  size: number = paginationPrams.pageLen;
  pageOption: any;
  maxDate = new Date();
  toDate: any;
  fromDate: any;
  rows: number;
  totalElementsValUploadHistory: any;
  toUpDt: Date;
  fromUpDt: Date;
  toDt: Date;
  fromDt: Date;
  transUploadMon: any;
  transUploadYear: any;
  transDocMon: any;
  transDocYear: any;
  docToDate: Date;
  docToDateTrans: Date;
  isDisable: boolean = false;
  defaultFilterVal: { label: string; value: string; }[];
  defaultVal: string;
  filterObj = new BulkDownload();
  filterData: any;
  filterName: any;
  filterDataRefresh: any = [];
  currentYear: number;
  constructor(
    private fb: FormBuilder,
    private getCommonService: CommonService,
    private invoiceRepoService: InvoiceRepoServiceService,
    private toaster: ToasterService,
    private getSet: GetterSetterService,
    private uploadService: UploadService,
    private bsEntity: BusinessEntityService,
    private datePipe: DatePipe,
  ) {
    this.loadScripts();
    this.monthVal = MOTHNS_VAL;
    this.defaultFilterVal = DEFAULT_FILTER;
    this.filterName = BULK_FILTERS;
    this.rows = paginationPrams.pageLen;
  }

  loadScripts() {
    const externalScriptArray = [
      '../assets/js/settings.js'
    ];
    for (let i = 0; i < externalScriptArray.length; i++) {
      const scriptTag = document.createElement('script');
      scriptTag.src = externalScriptArray[i];
      scriptTag.type = 'text/javascript';
      scriptTag.async = false;
      scriptTag.charset = 'utf-8';
      document.getElementsByTagName('head')[0].appendChild(scriptTag);
    }
  }

  ngOnInit() {
    this.currentYear = (new Date()).getFullYear();
    this.maxDate.setDate(this.maxDate.getDate() - 1);
    this.pageOption = paginationPrams.pageOption;
    this.selectedTab = 'tab1';
    this.ewbTitle = 'Previous request is in progress';
    this.gstr1Title = 'Previous request is in progress';
    this.navContData = JSON.parse(this.getSet.getNavContextData());
    this.filingPeriodDates = this.getCommonService.setFillingPeriodData();
    if (this.navContData.entityType == 'Business') {
      this.compID = this.getSet.getSetCompanyId();
    } else {
      this.compID = this.navContData.companyId;
    }
    if (this.navContData.entityType == 'Business' || this.navContData.entityType == 'LEGAL') {
      // this.getBusinessDetails();
      this.code = this.navContData.pan;
      this.checkStatus('gstr1');
      this.filingData = this.getCommonService.getFilingPeriod();
      this.formInitialization();
    } else {
      this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
      this.code = this.req.gstin;
      this.filingData = this.getCommonService.getFilingPeriod();
      this.formInitialization();
      this.checkStatus('gstr1');
    }
    /**
     * Code for multiselect tree with gstin list
     */
    if(this.navContData.entityType == 'Business') {
      this.bsEntitySubscribe = this.bsEntity.fetchFillingBusiness().subscribe((value: any) => {
      if(value) {
        this.gstinData = value.response;
          if(this.gstinData.length > 0) {
            this.gstinData.forEach(e=> {
              this.dropdownList.push({
                'item_text':e.companyname,
                'item_id':e.gstinno
              })
            })
          }
      }
    })
    } else {
      this.bsEntity.getLegalVal().subscribe((value) => {
        if(value) {
          this.gstinData = value.data;
            if(this.gstinData.length > 0) {
              this.gstinData.forEach(e=> {
                if(e.entityType == 'FILING') {
                  this.dropdownList.push({
                  'item_text':e.companyName,
                  'item_id':e.gstin
                })
                }
              })
            }
        }
      })
    }

    /**Code ends here */

    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 4,
      allowSearchFilter: true
    };
  }

  getBusinessDetails() {
    this.uploadService.getBusinessDetails(this.compID).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS") {
        this.code = response.response.panNo;
        this.checkStatus('gstr1');
      } else {
        this.toaster.showError(response.message);
      }
    });
  }

  formInitialization() {
    this.invoiceRepoForm = this.fb.group({
      fp: [this.filingData[0].value, [Validators.required]],
    });
  }

  downloadGstr1() {
    if (this.invoiceRepoForm.valid && this.code != null) {
      this.requestInit = true;
      let model = {
        "companyUniqueCode": this.code,
        "returnPeriod": this.invoiceRepoForm.value.fp
      }
      this.invoiceRepoService.downloadGstr1Initiate(model).subscribe((response: BaseResponse) => {
        this.requestInit = false;
        if (response.status == "SUCCESS") {
          this.statusFlag = true;
          this.checkDwdFlag = false;
          this.disableButton = true;
          this.addClass();
        } else {
          this.toaster.showError(response.message);
        }
      });
    }
  }

  downloadEwbBulk(filterObj?) {
    if(filterObj == undefined){
      filterObj = {};
    }

    let finalGstin: any = [];
    if(this.selectedItems.length > 0) {
      this.selectedItems.forEach(element => {
        finalGstin.push(element.item_id);
      });
    } else {
      this.toaster.showWarning('Select at least single GSTIN');
      return;
    }
    if (this.code != null) {
      let model = cloneDeep(filterObj);
      model['gstin'] = finalGstin.toString();
      model['companyUniqueCode'] = this.code;
      model['page'] = this.page;
      model['size'] = this.size;
      if(this.toUpDt && this.fromUpDt) {
        let dateDiff = this.differenceValGet(this.toUpDt, this.fromUpDt);
        if(dateDiff > 31) {
          this.toaster.showWarning('Date range should not be more than 31 days');
          return;
        }
        model['toUpDt'] = this.datePipe.transform(this.toUpDt, 'dd/MM/yyyy');
        model['fromUpDt'] = this.datePipe.transform(this.fromUpDt, 'dd/MM/yyyy');
      }
      if(this.toDt && this.fromDt) {
        let dateDiff = this.differenceValGet(this.toDt, this.fromDt);
        if(dateDiff > 31) {
          this.toaster.showWarning('Date range should not be more than 31 days');
          return;
        }
        model['toDt'] = this.datePipe.transform(this.toDt, 'dd/MM/yyyy');
        model['fromDt'] = this.datePipe.transform(this.fromDt, 'dd/MM/yyyy');
      }
      if(this.transUploadMon && this.transUploadYear) {
        this.getToNFromDate(this.transUploadMon, this.transUploadYear);
        model['toUpDt'] = this.toDate;
        model['fromUpDt'] = this.fromDate;
      }
      if(this.transDocMon && this.transDocYear) {
        this.getToNFromDate(this.transDocMon, this.transDocYear);
        model['toDt'] = this.toDate;
        model['fromDt'] = this.fromDate;
      }
      if((this.toUpDt == null && this.fromUpDt == null) && (this.toDt == null && this.fromDt == null) && (this.toDate == null && this.fromDate == null)) {
        this.toaster.showWarning('Default filter is mandatory');
          return;
      }
      if (this.filterObj.fromEWBDate && this.filterObj.toEWBDate) {
        let dateDiff = this.differenceValGet(this.filterObj.toEWBDate, this.filterObj.fromEWBDate);
        if(dateDiff > 31) {
          this.toaster.showWarning('EWB Date range should not be more than 31 days');
          return;
        }
        model["fromEWBDate"] = this.datePipe.transform(
          this.filterObj.fromEWBDate,
          "dd/MM/yyyy"
        );
        model["toEWBDate"] = this.datePipe.transform(
          this.filterObj.toEWBDate,
          "dd/MM/yyyy"
        );
      }
      if (
        this.filterObj.fromIRNCancelledDate &&
        this.filterObj.toIRNCancelledDate
      ) {
        let dateDiff = this.differenceValGet(this.filterObj.toIRNCancelledDate, this.filterObj.fromIRNCancelledDate);
        if(dateDiff > 31) {
          this.toaster.showWarning('IRN Cancel Date range should not be more than 31 days');
          return;
        }
        model["fromIRNCancelledDate"] = this.datePipe.transform(
          this.filterObj.fromIRNCancelledDate,
          "dd/MM/yyyy"
        );
        model["toIRNCancelledDate"] = this.datePipe.transform(
          this.filterObj.toIRNCancelledDate,
          "dd/MM/yyyy"
        );
      }
      if (
        this.filterObj.fromEWBCancelledDate &&
        this.filterObj.toEWBCancelledDate
      ) {
        let dateDiff = this.differenceValGet(this.filterObj.toEWBCancelledDate, this.filterObj.fromEWBCancelledDate);
        if(dateDiff > 31) {
          this.toaster.showWarning('EWB Cancel Date range should not be more than 31 days');
          return;
        }
        model["fromEWBCancelledDate"] = this.datePipe.transform(
          this.filterObj.fromEWBCancelledDate,
          "dd/MM/yyyy"
        );
        model["toEWBCancelledDate"] = this.datePipe.transform(
          this.filterObj.toEWBCancelledDate,
          "dd/MM/yyyy"
        );
      }
      if (this.filterObj.fromAckDt && this.filterObj.toAckDt) {
        let dateDiff = this.differenceValGet(this.filterObj.toAckDt, this.filterObj.fromAckDt);
        if(dateDiff > 31) {
          this.toaster.showWarning('Ack Date range should not be more than 31 days');
          return;
        }
        model["fromAckDt"] = this.datePipe.transform(
          this.filterObj.fromAckDt,
          "dd/MM/yyyy"
        );
        model["toAckDt"] = this.datePipe.transform(
          this.filterObj.toAckDt,
          "dd/MM/yyyy"
        );
      }
      if (this.filterObj.fromCnlDt && this.filterObj.toCnlDt) {
        let dateDiff = this.differenceValGet(this.filterObj.toCnlDt, this.filterObj.fromCnlDt);
        if(dateDiff > 31) {
          this.toaster.showWarning('IRN Cancel Date range should not be more than 31 days');
          return;
        }
        model["fromCnlDt"] = this.datePipe.transform(
          this.filterObj.fromCnlDt,
          "dd/MM/yyyy"
        );
        model["toCnlDt"] = this.datePipe.transform(
          this.filterObj.toCnlDt,
          "dd/MM/yyyy"
        );
      }
      if (this.filterObj.irnGenFromDate && this.filterObj.irnGenToDate) {
        let dateDiff = this.differenceValGet(this.filterObj.irnGenToDate, this.filterObj.irnGenFromDate);
        if(dateDiff > 31) {
          this.toaster.showWarning('IRN Gen Date range should not be more than 31 days');
          return;
        }
        model["irnGenFromDate"] = this.datePipe.transform(
          this.filterObj.irnGenFromDate,
          "dd/MM/yyyy"
        );
        model["irnGenToDate"] = this.datePipe.transform(
          this.filterObj.irnGenToDate,
          "dd/MM/yyyy"
        );
      }
      this.requestInit = true;
      this.invoiceRepoService.downloadEwbInitiateBulk(model).subscribe((response: BaseResponse) => {
        this.requestInit = false;
        if (response.status == "SUCCESS") {
          this.toaster.showSuccess(response.message);
          this.getBulkDownloadHistory();
        } else {
          this.toaster.showError(response.message);
        }
      });
    }
  }

  receiveFilter(event) {
    this.filterObj = cloneDeep(event);
    this.downloadEwbBulk(this.filterObj);
  }

  differenceValGet(tDt, fDt) {
    if(tDt && fDt) {
      var Difference_In_Time = tDt.getTime() - fDt.getTime();
      return Difference_In_Time / (1000 * 3600 * 24);
    }
  }

  dateSelection(type) {
    if(type == 'docDt'){
      this.docToDate = new Date(this.fromUpDt);
      this.toUpDt = null;
    }
    if(type == 'docDtTrans'){
      this.docToDateTrans = new Date(this.fromDt);
      this.toDt = null;
    }
  }

  checkStatus(type: any) {
    if(type == 'gstr1') {
      let model = {
            gstin: this.code,
            type: 'Dnld_Gstr1'
          }
          this.invoiceRepoService.downloadStatus(model).subscribe((response: BaseResponse) => {
            if (response.status == "SUCCESS" && response.response != null && response.response.status == 'COMPLETED') {
              this.statusFlag = false;
              this.checkDwdFlag = true;
              this.disableButton = false;
              this.statusFlagTime = false;
              this.gstr1CompleteTime = response.response.completionTime;
              this.downloadPath = response.response.filePath;
            } else if ( response.response != null && response.response.status === 'INPROGRESS') {
              this.statusFlag = false;
              this.gstr1ReqTime = response.response.requestTime;
              this.statusFlagTime = true;
              this.disableButton = true;
            } else {
              this.toaster.showError(response.message);
            }
          });
    }
    if(type == 'ewb') {
      let model = {
        gstin: this.code,
        type: 'Dnld_EWB'
      }
      this.invoiceRepoService.downloadStatus(model).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS" && response.response != null && response.response.status == 'COMPLETED') {
          this.statusFlagEwb = false;
          this.checkDwdFlagEwb = true;
          this.disableButtonEwb = false;
          this.statusFlagTimeEwb = false;
          this.ewbCompleteTime = response.response.completionTime;
          this.downloadPathEwb = response.response.filePath;
        } else if ( response.response != null && response.response.status === 'INPROGRESS') {
          this.ewbReqTime = response.response.requestTime;
          this.statusFlagEwb = false;
          this.statusFlagTimeEwb = true;
          this.disableButtonEwb = true;
        } else {
          this.toaster.showError(response.message);
        }
      });
    }

  }

  downloadFile(downloadPath) {
    window.location.href = downloadPath;
  }

  addClass() {
    const el = document.getElementById('navigation-bar');
    el.classList.add('show');
  }

  removeClass() {
    const el = document.getElementById('navigation-bar');
    el.classList.remove('show');
  }

  onClickedOutside(e: Event) {
    this.removeClass();
  }

  getBulkDownloadHistory() {
    let model = {
      'companyCode': this.code,
      'page' : this.page,
      'size' : this.size
    }
    this.invoiceRepoService.getBulkDownloadHis(model).subscribe((response: BaseResponse) => {
      if (response.status == "SUCCESS" && response.response != null) {
        this.bulkData = response.response.data;
        this.totalElementsValUploadHistory = response.response.totalElements;
      } else {
        this.toaster.showError(response.message);
      }
    });
  }

  viewFilter(filters) {
    console.log(filters);
    this.filterData = JSON.parse(filters);
    let temFilter = this.filterData;
    /**Remove the null values from the filter object */
    $.each(temFilter, function(key, val){
      if(val === ''|| val === null){
        delete temFilter[key];
      }
    });
    this.filterData = temFilter;
    let flts = [];
    this.filterName.filter(function (e) {
        if (temFilter.hasOwnProperty(e.key)) {
            flts.push({'name':e.name, 'value': temFilter[e.key]});
        }
    })
    this.filterDataRefresh = flts;
  }

  getToNFromDate(dateValMon, dateYear) {
    if(dateValMon && dateYear){
      let a = dateValMon;//month
      let c;
      let b = dateYear;//year
      if(a == '01' || a == '03' || a == '05' || a == '07' || a == '08' || a == '10' || a == '12') {
        c = '31';
      } else if(a == '04' || a == '04' || a == '09' || a == '11') {
        c = '30';
      } else {
        if(b%4 == 0) {
          c = '29';
        } else {
          c = '28';
        }
      }
      this.toDate = c+'/'+a+'/'+b;
      this.fromDate = '01/'+a+'/'+b;
    }
  }


  paginateUploadHistory(event) {
    this.page = event.page;
    this.size = event.rows;
    this.getBulkDownloadHistory();
  }

  download(obj: any) {
    this.isDisable = true;
    let req = {
      "downloadId": obj.id,
      "companyCode": this.code
    }
    this.invoiceRepoService.downloadStatusBulk(req).subscribe((response: BaseResponse) => {
      this.isDisable = false;
      if (response.status === 'SUCCESS') {
        this.bulkData.forEach((item) => {
          if (item.id === obj.id) {
            if (response.response.status === undefined || response.response.status === 'INPROGRESS') {
              item['checkStatus'] = true;
              item['downloadFlag'] = false;
              item['isDownload'] = false;
            } else if (response.response.status === 'COMPLETED') {
              if (response.response.filePath != null) {
                item['checkStatus'] = false;
                item['downloadFlag'] = true;
                item['isDownload'] = false;
                this.downloadFile(response.response.filePath)
                // this.toaster.showSuccess(response.message);
              } else {
                this.toaster.showError(response.response.error);
                item['checkStatus'] = true;
              }
            }
          }
        })
      }
    })
  }

  clearVal() {
    this.toDt = null;
    this.fromDt = null;
    this.toUpDt = null;
    this.fromUpDt = null;
    this.transUploadMon = null;
    this.transUploadYear = null;
    this.transDocMon = null;
    this.transDocYear = null;
  }

  clearAll() {
    this.toDt = null;
    this.fromDt = null;
    this.toUpDt = null;
    this.fromUpDt = null;
    this.transUploadMon = null;
    this.transUploadYear = null;
    this.transDocMon = null;
    this.transDocYear = null;
    this.defaultVal = null;
    this.selectedItems = [];
  }

  tabChanged(tab, check?) {
    this.filterObj = {};
    this.selectedTab = tab;
    if (this.selectedTab === 'tab1') {
      this.checkStatus('gstr1');
    } else if (this.selectedTab === 'tab2') {
      this.checkStatus('ewb');
    } else if (this.selectedTab === 'tabBulkDownload') {
      this.getBulkDownloadHistory();
      this.clearAll();
    }
  }


}
