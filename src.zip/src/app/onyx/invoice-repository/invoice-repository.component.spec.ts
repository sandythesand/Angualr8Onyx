import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceRepositoryComponent } from './invoice-repository.component';

describe('InvoiceRepositoryComponent', () => {
  let component: InvoiceRepositoryComponent;
  let fixture: ComponentFixture<InvoiceRepositoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceRepositoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceRepositoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
