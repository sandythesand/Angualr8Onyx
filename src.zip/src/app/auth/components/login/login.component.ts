import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { TokenService } from '../../../shared/services/token.service';
import { BaseResponse } from '../../../models/response';
import { Router } from '@angular/router';
import { APP_NAME } from '../../../shared/constant'
import { ToasterService } from '../../../shared/services/toaster.service';
import { GetterSetterService } from '../../../shared/services/getter-setter.service';
import { BusinessHeaderComponent } from '../../../base/components/business-header/business-header.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  @ViewChild(BusinessHeaderComponent, { static: false }) childBusinessHeaderComp: BusinessHeaderComponent;
  loginForm: FormGroup;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  isSubmitted: boolean = false;
  subArrowShow: boolean;
  constructor(
    private _fb: FormBuilder,
    private authService: AuthService,
    private tokenService: TokenService,
    private router: Router,
    private toaster: ToasterService,
    private getSet: GetterSetterService,
  ) {
    this.APP_NAME = APP_NAME;
    window.open(this.tokenService.getUumUrl(), '_self');
  }

  ngOnInit() {
    this.formInitialization();
  }

  formInitialization() {
    this.loginForm = this._fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(16), Validators.pattern(new RegExp('^[a-zA-Z0-9!@#$&*%?()\\-`.+,/\"]*$'))]]
    });
  }

  login() {
    this.isSubmitted = true;
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value).subscribe((response: BaseResponse) => {
        if (response.status === 'SUCCESS') {
          this.toaster.showSuccess('Login Successful.');
          this.tokenService.setter(response.response);
          this.authService.setLoginIndicator(2);
          this.getSet.getSetCompany(response.response.rootCompanyName);
          this.getSet.getSetUser(response.response.username);
          this.getSet.getSetUserId(response.response.email);
          this.getSet.setProduct(response.response.products);
          // this.BusinessHeaderComponent.getBusinessHierarchy()
          if (response.response.rootCompanyid != undefined) {
            this.getSet.getSetCompanyId(response.response.rootCompanyid);
          } 
          this.router.navigate([`${this.APP_NAME.ONYX}`]);
        } else {
          if (response.response != null && response.response.isValidPassword == false) {
            this.toaster.showError('Your password has expired and must be changed after redirecting.');
            this.authService.setLoginEmail(response.response.email);
            this.router.navigate(['change-password']);
        }
          this.toaster.showError(response.message);
        }
      });
    }
  }

  forgotPassword() {
    this.router.navigate(['forgot-password']);
  }

  signup() {
    this.router.navigate(['signup']);
  }
}
