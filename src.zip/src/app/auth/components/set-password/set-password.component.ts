import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from '../../../shared/services/toaster.service';
import { BaseResponse } from '../../../models/response';
import { timer } from 'rxjs';

@Component({
  selector: 'app-set-password',
  templateUrl: './set-password.component.html',
  styleUrls: ['./set-password.component.css']
})
export class SetPasswordComponent implements OnInit {
  resetForm: FormGroup;
  isSubmitted: boolean = false;
  constructor(
    private fbuild: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private toaster: ToasterService,
    private activeSnapShot: ActivatedRoute
  ) { }

  ngOnInit() {
    this.formInitialization();
  }

  formInitialization() {
    this.resetForm = this.fbuild.group({
      newpassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(16), Validators.pattern(new RegExp('^[a-zA-Z0-9!@#$&*%?()\\-`.+,/\"]*$'))]]
    });
  }

  resetPassword() {
    this.isSubmitted = true;
    if (this.resetForm.valid) {
      let formData1 = {
        "token": this.activeSnapShot.snapshot.queryParams.token,
        "newpassword": this.resetForm.value.newpassword
      }
      this.authService.doResetPassword(formData1).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.toaster.showSuccess(response.message);
          timer(1000).subscribe((val) => {
            this.router.navigate(['login']);
          });
        } else {
          this.toaster.showWarning(response.message);
        }
      });
    } else {
      console.log("Invalid data");
    }
  }
}
