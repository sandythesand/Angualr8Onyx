import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { APP_NAME } from '../../../shared/constant';
import { timer } from 'rxjs';

@Component({
  selector: 'app-thankyou',
  templateUrl: './thankyou.component.html',
  styleUrls: ['./thankyou.component.scss']
})
export class ThankyouComponent implements OnInit {

  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  constructor(
    private router: Router,
  ) {
    this.APP_NAME = APP_NAME;
  }

  ngOnInit() {
    timer(5000).subscribe((val) => {
      this.router.navigate(['login']);
    });
  }

}
