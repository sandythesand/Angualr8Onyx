import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { BaseResponse } from '../../../models/response';
import { ToasterService } from '../../../shared/services/toaster.service';
import { TokenService } from '../../../shared/services/token.service';
import { GetterSetterService } from '../../../shared/services/getter-setter.service';
import { APP_NAME } from 'src/app/shared/constant';

@Component({
  selector: 'app-token-verify',
  templateUrl: './token-verify.component.html',
  styleUrls: ['./token-verify.component.scss']
})
export class TokenVerifyComponent implements OnInit {
  tokenParam: any;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };

  constructor(
    private authService: AuthService,
    private router: Router,
    private activeSnapShot: ActivatedRoute,
    private toaster: ToasterService,
    private tokenService: TokenService,
    private getSet: GetterSetterService,
  ) {
    this.tokenParam = this.activeSnapShot.snapshot.queryParams.token;
    this.APP_NAME = APP_NAME;
   }

  ngOnInit() {
    if (this.tokenParam != undefined && this.tokenParam != null) {
      sessionStorage.clear();
      /*checking token is valid or not*/
      this.authService.tokenVerifyExternal(this.tokenParam).subscribe((response: BaseResponse) => {
        if (response.status == 'SUCCESS') {
          this.toaster.showSuccess('Login Successful.');
          this.tokenService.setter(response.response);
          this.authService.setLoginIndicator(2);
          this.getSet.getSetCompany(response.response.rootCompanyName);
          this.getSet.getSetUser(response.response.username);
          this.getSet.getSetUserId(response.response.email);
          this.getSet.setProduct(response.response.products);
          // this.BusinessHeaderComponent.getBusinessHierarchy()
          if (response.response.rootCompanyid != undefined) {
            this.getSet.getSetCompanyId(response.response.rootCompanyid);
          } 
          this.router.navigate([`${this.APP_NAME.ONYX}`]);
          // this.username = response.response.username;
        } else {
          this.toaster.showError("Your token has been expired");
          this.router.navigate(['login']);
        }
      });
    } 
  }

}
