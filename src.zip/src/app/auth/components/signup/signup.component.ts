import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { APP_NAME } from '../../../shared/constant';
import { BaseResponse } from '../../../models/response';
import { ToasterService } from '../../../shared/services/toaster.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  signupForm: FormGroup;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  isSubmitted: boolean;
  constructor(
    private fBuild: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private toaster: ToasterService
  ) {
    this.APP_NAME = APP_NAME;
  }

  ngOnInit() {
    this.formInitialization();
  }

  formInitialization() {
    this.signupForm = this.fBuild.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]]
    });
  }
  get f() { return this.signupForm.controls; }

  forgotPassword() {
    this.router.navigate(['forgot-password']);
  }

  login() {
    this.router.navigate(['login']);
  }

  signup() {
    this.isSubmitted = true;
    if (this.signupForm.valid) {
      this.authService.signup(this.signupForm.value).subscribe((response: BaseResponse) => {
        if (response.status == 'SUCCESS') {
          this.toaster.showSuccess('Registration Successful!');
          this.router.navigate(['thankyou']);
        } else {
          this.toaster.showError("Regsistration Failed..! " + response.errors[0].field);
        }
      });
    }
  }

}
