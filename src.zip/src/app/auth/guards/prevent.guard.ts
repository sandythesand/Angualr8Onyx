import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../../auth/services/auth.service';
import { APP_NAME } from '../../shared/constant';

@Injectable({
  providedIn: 'root'
})
export class PreventGuard implements CanActivate {
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };

  constructor(
    private _router: Router,
    private auth: AuthService,
    private route: ActivatedRoute
  ) {
    this.APP_NAME = APP_NAME;
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (this.auth.isAuthenticated()) {
      this._router.navigate([`${this.APP_NAME.ONYX}/dashboard`]);
      return false;
    } else {
      this.auth.loginIndicator.next(0);
    }
    return true;
  }
}
