import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './auth';
// import { DashboardComponent } from './onyx/dashboard/dashboard.component';
import { APP_NAME } from './shared/constant';
import { ForgotPasswordComponent } from './auth/components/forgot-password/forgot-password.component';
import { SignupComponent } from './auth/components/signup/signup.component';
import { ThankyouComponent } from './auth/components/thankyou/thankyou.component';
import { AuthGuard } from './auth/guards/auth.guard';
import { CompleteRegistrationComponent } from './auth/components/complete-registration/complete-registration.component';
import { AddBusinessComponent } from './businessManagement/components/add-business/add-business.component';
import { PreventGuard } from './auth/guards/prevent.guard';
import { SetPasswordComponent } from './auth/components/set-password/set-password.component';
import { ChangePasswordComponent } from './auth/components/change-password/change-password.component';
import { TokenVerifyComponent } from './auth/components/token-verify/token-verify.component';

const routes: Routes = [
  {
    path: 'login',
    canActivate: [PreventGuard],
    component: LoginComponent
  },
  {
    path: `${APP_NAME.ONYX}`,
    canActivate: [AuthGuard],
    // component: DashboardComponent
    loadChildren: () => import('./onyx/onyx.module').then(m => m.OnyxModule)
  },
  {
    path: 'settings',
    canActivate: [AuthGuard],
    loadChildren: () => import('./businessManagement/components/settings/settings.module').then(m => m.SettingsModule)
  },
  {
    path: 'forgot-password',
    canActivate: [PreventGuard],
    component: ForgotPasswordComponent
  }, 
  {
    path: 'token-verify',
    canActivate: [PreventGuard],
    component: TokenVerifyComponent
  }, {
    path: 'reset-password',
    canActivate: [PreventGuard],
    component: SetPasswordComponent
  }, {
    path: 'signup',
    canActivate: [PreventGuard],
    component: SignupComponent
  }, {
    path: 'thankyou',
    canActivate: [PreventGuard],
    component: ThankyouComponent
  }, {
    path: 'complete-reg',
    canActivate: [PreventGuard],
    component: CompleteRegistrationComponent
  }, {
    path: 'add-business',
    canActivate: [AuthGuard],
    component: AddBusinessComponent
  }, {
    path: 'change-password',
    canActivate: [PreventGuard],
    component: ChangePasswordComponent
  }, {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
