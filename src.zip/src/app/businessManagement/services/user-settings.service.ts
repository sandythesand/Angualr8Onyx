import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserSettingsService {

  constructor(
    private http: HttpClient
  ) { }

  saveFtp(sftpVal: boolean) {
    return this.http.get(`${environment.apiUrl}/mgmt/company/garnetAdmin?isAdmin=${sftpVal}`).pipe(map((resp) => {
      return resp;
    }));
  }

  fetchUserList(cmpId) {
    return this.http.get(`${environment.apiUrl}/mgmt/company/users?companyid=${cmpId}`).pipe(map((resp) => {
      return resp;
    }));
  }
  fetchRoleList() {
    return this.http.get(`${environment.apiUrl}/mgmt/user/roles`).pipe(map((resp) => {
      return resp;
    }));
  }
  fetchSftp() {
    return this.http.get(`${environment.apiUrl}/mgmt/company/isGarnetAdmin`).pipe(map((resp) => {
      return resp;
    }));
  }
  changeUserRole(roleID, userid, viewHierarchy_id) {
    return this.http.post(`${environment.apiUrl}/mgmt/company/users?userid=${userid}&roleid=${roleID}&companyId=${viewHierarchy_id}`, {}).pipe(map((resp) => {
      return resp;
    }));
  }
  bulkPrintAllow(pan, data) {
    return this.http.post(`${environment.apiUrl}/mgmt/company/business/metadata?companyIdentifier=${pan}`, data).pipe(map((resp) => {
      return resp;
    }));
  }
  deleteUserRole(userid, viewHierarchy_id) {
    return this.http.delete(`${environment.apiUrl}/mgmt/company/user/role?userid=${userid}&companyid=${viewHierarchy_id}`).pipe(map((resp) => {
      return resp;
    }));
  }
  inviteUser(data,) {
    return this.http.put(`${environment.apiUrl}/mgmt/company/inviteuser`, data).pipe(map((resp) => {
      return resp;
    }));
  }
}
