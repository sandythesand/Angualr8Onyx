import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PreferenceService {

  constructor(
    private http: HttpClient
  ) { }

  setPreference(data) {
    return this.http.post(`${environment.apiUrl}/onyx/einvoice/pref`,data).pipe(map((resp) => {
      return resp;
    }));
  }
}
