import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../auth/guards/auth.guard';
import { PreferenceComponent } from './preference.component';
import { MyPreferenceComponent } from './my-preference/my-preference.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthGuard],
        component: PreferenceComponent
    },
    {
        path: 'my-preference',
        canActivate: [AuthGuard],
        component: PreferenceComponent
    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)]
})
export class PreferenceRoutingModule { }
