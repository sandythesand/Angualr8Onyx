import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../../shared/shared.module';
import { PreferenceRoutingModule } from './preference-routing.module';
import { MyPreferenceComponent } from './my-preference/my-preference.component';
import { PreferenceComponent } from './preference.component';


@NgModule({
    declarations: [
        PreferenceComponent,
        MyPreferenceComponent,
    ],
    imports: [
        CommonModule,
        PreferenceRoutingModule,
        SharedModule,
    ]
})
export class PreferenceModule { }
