import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { FILTER_LIST } from '../../../../shared/constant';
import { ToasterService } from '../../../../shared/services/toaster.service';
import { PreferenceService } from '../../../services/preference.service';
import { BaseResponse } from '../../../../models/response';

@Component({
  selector: 'app-my-preference',
  templateUrl: './my-preference.component.html',
  styleUrls: ['./my-preference.component.scss']
})
export class MyPreferenceComponent implements OnInit {
  filterList: { key: string; value: string; }[];
  myPreferenceForm: FormGroup;
  tempList = [];
  lastFilterIndex: any;
  constructor(
    private fb: FormBuilder,
    private toaster: ToasterService,
    private preferenceService: PreferenceService
  ) {
    this.filterList = FILTER_LIST;
  }

  ngOnInit() {
    this.myPreferenceForm = this.fb.group({
      userEmail: [`${sessionStorage.getItem('UserId')}`, Validators.required],
      filterPrefs: [''],
      viewColumnPrefs: [[]]
    })
  }

  onFilterChange(event, currentFilterNo) {
    const ind = this.tempList.indexOf(event.target.value);
    if (this.lastFilterIndex != currentFilterNo) {
      if (ind === -1) {
        this.tempList.push(event.target.value);
        this.lastFilterIndex = currentFilterNo
      } else {
        this.toaster.showError('Pls! select unique filters');
        event.target.value = '';
      }
    } else {
      this.tempList.splice(ind, 1);
      this.tempList.push(event.target.value)
    }
  }

  addPreference() {
    if (this.tempList.length) {
      this.myPreferenceForm.value.filterPrefs = this.tempList;
      // this.myPreferenceForm.value.filterPrefs = this.tempList;
      this.preferenceService.setPreference(this.myPreferenceForm.value).subscribe((response: BaseResponse) => {
        if (response.status === 'SUCCESS') {
          this.myPreferenceForm.reset();
          this.toaster.showSuccess(response.message)
        } else {
          this.toaster.showError(response.message)
        }
      })
    } else {
      this.toaster.showError('pls ! select filters')
    }
  }

}
