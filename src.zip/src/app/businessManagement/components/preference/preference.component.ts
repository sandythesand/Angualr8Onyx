import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-preference',
  templateUrl: './preference.component.html',
  styleUrls: ['./preference.component.scss']
})
export class PreferenceComponent implements OnInit {
  activeFlag: boolean = false;

  constructor(
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    if (this.route.snapshot.routeConfig.path === 'preference') {
      this.activeFlag = true;
    } else {
      this.activeFlag = false;
    }
  }

  myPreference(){
    this.router.navigate(['my-preference']);
  }
}
