import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToasterService } from '../../../shared/services/toaster.service';
import { APP_NAME } from '../../../shared/constant';
import { BaseResponse } from '../../../models/response';
import { GetterSetterService } from '../../../shared/services/getter-setter.service';
import { BusinessHeaderComponent } from '../../../base/components/business-header/business-header.component';
import { BusinessService } from '../../services/business.service';

@Component({
  selector: 'app-add-business',
  templateUrl: './add-business.component.html',
  styleUrls: ['./add-business.component.scss']
})
export class AddBusinessComponent implements OnInit {

  @ViewChild(BusinessHeaderComponent, { static: false })
  childBusinessHeaderComp: BusinessHeaderComponent;
  addBusinessForm: FormGroup;
  subscribeForm: FormGroup;
  // uploadHierarchyForm: FormGroup;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  isSubmitted: boolean = false;
  businessDetailsFilled: any;
  activeStep1: boolean = true;
  activeStep2: boolean = false;
  activeStep3: boolean = false;
  entityType: string;
  subscriptionCode: any;

  constructor(
    private fBuild: FormBuilder,
    private router: Router,
    private toaster: ToasterService,
    private getterSetter: GetterSetterService,
    private businessSerivce: BusinessService
  ) {
    this.APP_NAME = APP_NAME;
  }

  ngOnInit() {
    this.formInitialization();
  }

  formInitialization() {
    this.addBusinessForm = this.fBuild.group({
      companyname: ['', [Validators.required]],
      pan: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(new RegExp('^[a-zA-Z]{4}[a-zA-Z0-9]{1}[0-9]{4}[a-zA-Z]{1}'))]],
      address: []
    });
    this.subscribeForm = this.fBuild.group({
      subCode: ['', [Validators.required]]
    });
    // this.uploadHierarchyForm = this.fBuild.group({
    //   subCode: ['', [Validators.required]]
    // });
  }

  checkSubmitValidation(data: any) {
    this.isSubmitted = true;
    if (this.addBusinessForm.valid && data == 'addBusinessTab') {
      this.businessSerivce.getSubscriptionPlan(this.addBusinessForm.value).subscribe((response: BaseResponse) => {
        if (response.status == 'SUCCESS') {
          // sessionStorage.setItem('planName', response.response.planName);
          this.businessDetailsFilled = true;
          this.activeStep1 = false;
          this.activeStep2 = true;
          this.subscriptionCode = response.response.subscriptionCode;
        } else if (response.status == 'FAILURE') {
          this.toaster.showWarning(response.message);
        }
      });
    }
    if (this.subscribeForm.valid && data == 'subscribeTab') {
      // this.businessSerivce.getCorporatePlan(this.subscribeForm.value).subscribe((response: BaseResponse) => {
      //   if (response.status == 'SUCCESS') {
      //     this.entityType = "BUSINESS";
      //     this.activeStep1 = false;
      //     this.activeStep2 = true;
      //     this.checkValidationsForFinish(this.subscribeForm.value.subCode);
      //   } else if (response.status == 'FAILURE') {
      //     this.toaster.showWarning(response.message);
      //   }
      // });
      if (this.subscribeForm.value.subCode == this.subscriptionCode) {
        this.entityType = "BUSINESS";
        this.activeStep1 = false;
        this.activeStep2 = true;
        this.checkValidationsForFinish(this.subscriptionCode);
      } else {
        this.toaster.showWarning("Please Enter Valid Subscription Code");
      }
    }
  }

  OpenForm(step: string) {
    if (step == 'step2' && this.businessDetailsFilled) {
      this.activeStep1 = false;
      this.activeStep2 = true;
      this.activeStep3 = false;
    }
    else if (step == 'step3' && this.businessDetailsFilled) {
      this.activeStep1 = false;
      this.activeStep2 = false;
      this.activeStep3 = true;
    }
    else {
      this.activeStep1 = true;
      this.activeStep2 = false;
      this.activeStep3 = false;
    }
  }

  checkValidationsForFinish(subCodeVal: any) {
    // if (this.addBusinessForm.valid) {
    //   if (subCodeVal != undefined) {
    //     this.businessSerivce.getCorporatePlan(subCodeVal).subscribe((response: BaseResponse) => {
    //       if (response.status == 'SUCCESS') {
    //         this.entityType = "BUSINESS";
    //         this.addBusiness();
    //       } else if (response.status == 'FAILURE') {
    //         this.toaster.showWarning(response.message);
    //       }
    //     });
    //   } else {
    //     this.toaster.showError('Enter valid subscription code.');
    //   }
    // }

    if (this.addBusinessForm.valid) {
      if (subCodeVal != undefined) {
            this.entityType = "BUSINESS";
            this.addBusiness();
      } else {
        this.toaster.showError('Enter valid subscription code.');
      }
    } else {
      this.toaster.showWarning('Please fill Business Details');
    }
  }

  addBusiness() {
    let model = {
      'companyname': this.addBusinessForm.value.companyname,
      'pan': this.addBusinessForm.value.pan,
      'address': this.addBusinessForm.value.address,
      'entitytype': this.entityType
    };

    this.businessSerivce.addBusinessFunction(model).subscribe((response: BaseResponse) => {
      if (response.status == 'SUCCESS') {
        this.toaster.showSuccess(response.message);
        this.getterSetter.getSetCompany(this.addBusinessForm.value.companyname);
        this.getterSetter.getSetCompanyId(response.response.companyid);
        // this.getterSetter.set_UserRole(1);
        //UPDATE COMPANY LIST
        this.childBusinessHeaderComp.getCompanyList();
        this.childBusinessHeaderComp.getBusinessHierarchy();
        this.router.navigate[`${APP_NAME.ONYX}/dashboard`];
      } else {
        this.toaster.showError(response.message);
      }
    });
  }

}
