import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserAccessComponent } from './user-access/user-access.component';
import { SettingsRoutingModule } from './settings-routing.module';
import { SettingsComponent } from './settings.component';
import { BusinessHierarchyComponent } from './business-hierarchy/business-hierarchy.component';
import { SharedModule } from '../../../shared/shared.module';
import { AddGstinComponent } from './add-gstin/add-gstin.component';
import { AddPOBComponent } from './add-pob/add-pob.component';
import { InvoiceTemplateEditorComponent } from './invoice-template-editor/invoice-template-editor.component'
import { EditorModule } from '@tinymce/tinymce-angular';
import { UserSettingComponent } from './user-setting/user-setting.component';
import { InvoiceTemplateListComponent } from './invoice-template-list/invoice-template-list.component';


@NgModule({
  declarations: [
    SettingsComponent,
    UserAccessComponent,
    BusinessHierarchyComponent,
    AddGstinComponent,
    AddPOBComponent,
    InvoiceTemplateEditorComponent,
    UserSettingComponent,
    InvoiceTemplateListComponent
  ],
  imports: [
    CommonModule,
    SettingsRoutingModule,
    SharedModule,
    EditorModule
  ]
})
export class SettingsModule { }
