import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddGstinComponent } from './add-gstin.component';

describe('AddGstinComponent', () => {
  let component: AddGstinComponent;
  let fixture: ComponentFixture<AddGstinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddGstinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddGstinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
