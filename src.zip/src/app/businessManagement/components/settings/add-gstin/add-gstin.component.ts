import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToasterService } from '../../../../shared/services/toaster.service';
import { GetterSetterService } from '../../../../shared/services/getter-setter.service';
import { BusinessService } from '../../../services/business.service';
import { APP_NAME } from 'src/app/shared/constant';
import { StateListService } from '../../../../shared/services/state-list.service';
import { BaseResponse } from '../../../../models/response';
import { taxpayerTypes, STATE_LIST } from '../../../../shared/constant';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-gstin',
  templateUrl: './add-gstin.component.html',
  styleUrls: ['./add-gstin.component.scss']
})
export class AddGstinComponent implements OnInit {

  addGstinForm: FormGroup;
  nicForm: FormGroup;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  isSubmitted: boolean = false;
  parentCompanyName: string;
  parentId: any;
  stateCode: any = null;
  stateList: any = [];
  pan: any;
  gstinNo: any;
  taxpayerList: any = [];
  taxpayerType: any;
  isTopazLogin: boolean = false;
  isOnyxLogin: boolean = false;
  currentProductAccess: any;
  isTopazAccess: boolean = false;
  isOnyxAccess: boolean = false;
  isDisableTopazField: boolean = false;
  docToDate: Date;
  maxDate = new Date();
  currentYear: any;
  isDisabled: boolean = false;

  constructor(
    private fBuild: FormBuilder,
    private router: Router,
    private toaster: ToasterService,
    private getterSetter: GetterSetterService,
    private businessSerivce: BusinessService,
    private stateService: StateListService,
    private BS: BusinessService,
    private datePipe: DatePipe
  ) {
    this.APP_NAME = APP_NAME;
    this.taxpayerList = taxpayerTypes;
    this.taxpayerType = this.taxpayerList[0].key;
    this.parentCompanyName = this.getterSetter.getviewHierarchy_name();
    this.parentId = this.getterSetter.getviewHierarchy_id();
  }

  ngOnInit() {
    this.currentYear = (new Date()).getFullYear();
    this.currentProductAccess = sessionStorage.getItem('products');
    let tempArrProduct = this.currentProductAccess.split(',');
    if (tempArrProduct) {
      tempArrProduct.forEach(e => {
        if (e == 'TOPAZ') {
          this.isTopazAccess = true;
        }
        if (e == 'ONYX') {
          this.isOnyxAccess = true;
        }
      });
    }

    // this.initalStateData();
    this.stateList = STATE_LIST;
    this.initalCompanyData();
    this.initalNicForm();

  }

  initalStateData() {
    this.stateService.getStatesList().subscribe((response: BaseResponse) => {
      if (response.status == 'SUCCESS') {
        this.stateList = response.response;
      } else if (response.status == 'FAILURE') {
        this.toaster.showWarning(response.message);
      }
    });
  }

  initalCompanyData() {
    this.businessSerivce.viewEntity(this.parentId).subscribe((response: BaseResponse) => {
      if (response.status == 'SUCCESS') {
        this.pan = response.response.panNo;
        this.formInitialization();
        // this.setTopazFormValidity();
      } else if (response.status == 'FAILURE') {
        this.toaster.showWarning(response.message);
      }
    });
  }

  gotoBusiness() {
    this.router.navigate(['settings']);
  }

  formInitialization() {
    this.addGstinForm = this.fBuild.group({
      state: [null, [Validators.required]],
      entityNo: [null, [Validators.required]],
      companyname: ['', [Validators.required]],
      pan: [this.pan, [Validators.required]],
      stateCode: [null, [Validators.required]],
      nicUserNameOnyx: ['', [Validators.required]],
      nicPasswordOnyx: ['', [Validators.required]],
      nicUserNameTopaz: [null],
      nicPasswordTopaz: [null],
      isTopazNicCredential: [null],
      address: [null],
      address1: [null],
      phone: [null],
      email: [null],
      city: [null],
      pincode: ['', [Validators.required]],
      taxpayerType: [this.taxpayerType, [Validators.required]],
      registartionDate: [null, [Validators.required]]
    });
  }
  initalNicForm() {
    this.nicForm = this.fBuild.group({});
  }
  toDashboard() {
    this.router.navigate([`${this.APP_NAME.ONYX}`]);
  }

  setTopazFormValidity() {
    let tempTopaznicUname = this.addGstinForm.get('nicUserNameTopaz');
    let tempTopaznicPassword = this.addGstinForm.get('nicPasswordTopaz');
    if (this.isTopazAccess) {
      tempTopaznicUname.setValidators([Validators.required]);
      tempTopaznicPassword.setValidators([Validators.required]);
    }
  }

  addGstin() {
    this.isSubmitted = true;
    this.isDisabled = true;
    if (this.addGstinForm.valid) {
      this.gstinNo = this.addGstinForm.value.stateCode + '' + this.addGstinForm.value.pan + '' + this.addGstinForm.value.entityNo;
      this.addGstinForm.value.entitytype = 'FILING';
      this.addGstinForm.value.gstinno = this.gstinNo;
      this.addGstinForm.value.parentid = this.parentId;
      this.addGstinForm.value.registartionDate = this.datePipe.transform(this.addGstinForm.value.registartionDate, 'yyyy-MM-dd');
      this.BS.addGstinFunction(this.addGstinForm.value).subscribe((response: BaseResponse) => {
        this.isDisabled = false;
        if (response.status == 'SUCCESS') {
          this.toaster.showSuccess(response.message);
          this.router.navigate(['settings']);
        } else {
          this.toaster.showError(response.message);
        }
        this.isSubmitted = false;
      });
    } else {
      this.isDisabled = false;
    }
  }

  nicSubmit() {
    this.isSubmitted = true;
    if (this.addGstinForm.valid) {
      let data;
      data = this.nicForm.value;
      data.nicUserNameOnyx = this.addGstinForm.value.nicUserNameOnyx;
      // if (this.addGstinForm.value.nicUserNameTopaz)
      //   data.nicUserNameTopaz = this.addGstinForm.value.nicUserNameTopaz;
      // data.nicPasswordOnyx = this.addGstinForm.value.nicPasswordOnyx;
      // if (this.addGstinForm.value.nicPasswordTopaz)
      //   data.nicPasswordTopaz = this.addGstinForm.value.nicPasswordTopaz;
      data.isTopazNicCredential = true;
      data.gstin = this.addGstinForm.value.stateCode + '' + this.addGstinForm.value.pan + '' + this.addGstinForm.value.entityNo;
      this.businessSerivce.updateNIC(data).subscribe((response: BaseResponse) => {
        if (response.status == 'SUCCESS') {
          this.toaster.showSuccess(response.message);
        } else if (response.status == 'FAILURE') {
          this.toaster.showWarning(response.message);
        }
      //   setTimeout (() => {
      //     console.log("Hello from setTimeout");
      //     this.addGstin();
      //  }, 1000);
      });
    }

  }

  setStateCode(event: any) {
    this.addGstinForm.get('stateCode').setValue(event.target.value);
  }

  setAsAboveVal() {
    if (this.addGstinForm.get('isTopazNicCredential').value === true) {
      this.isDisableTopazField = true;
      this.addGstinForm.get('nicUserNameTopaz').setValue(this.addGstinForm.get('nicUserNameOnyx').value);
      this.addGstinForm.get('nicPasswordTopaz').setValue(this.addGstinForm.get('nicPasswordOnyx').value);
    } else {
      this.isDisableTopazField = false;
      this.addGstinForm.get('nicUserNameTopaz').setValue('');
      this.addGstinForm.get('nicPasswordTopaz').setValue('');
    }
  }
  // getGstinDetails = function (entityNo) {
  //   if (entityNo != null && entityNo != '' && entityNo.length == '3') {
  //     this.gstinNo = this.addGstinForm.stateCode + "" + this.addGstinForm.pan + "" + this.addGstinForm.entityNo;
  //     this.gstinService.getGstinData(this.gstinNo).subscribe((response: BaseResponse) => {
  //       if (response.status == 'SUCCESS' && response.response != '' && response.response.error == null) {
  //         this.pan = response.response.panNo;
  //       } else if (response.status == 'SUCCESS' && response.response != '' && response.response.error) {
  //         this.toaster.showError('Not a valid GSTIN');
  //       }
  //       else if (response.status == 'FAILURE') {
  //         this.toaster.showWarning(response.message);
  //       }
  //     }, (e: any) => {
  //       this.toaster.showError('Not a valid GSTIN');
  //       console.log(e, 'EXCEPTION');
  //     });
  //   }
  // }

  dateSelection(type) {
    if (type == 'regDt') {
      this.docToDate = new Date(this.addGstinForm.value.registartionDate);
    }
  }


}
