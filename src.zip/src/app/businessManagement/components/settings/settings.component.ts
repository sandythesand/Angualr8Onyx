import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GetterSetterService } from '../../../shared/services/getter-setter.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  userFlag: string;
  navData: any;

  constructor(
    private router: Router,
    private getSet: GetterSetterService
  ) { }

  ngOnInit() {
    this.navData = JSON.parse(this.getSet.getNavContextData());
    this.userFlag = 'Business';
  }

  userSettings() {
    this.userFlag = 'User';
    //this.router.navigate(['/settings/user']);
  }

  templateList() {
    this.router.navigate(['/settings/templates']);
  }

  businessHierarchy() {
    this.userFlag = 'Business';
  }
  userSftp() {
    this.userFlag = 'userSetting';
  }

}
