import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserAccessComponent } from './user-access/user-access.component';
import { SettingsComponent } from './settings.component';
import { AuthGuard } from '../../../auth/guards/auth.guard';
import { AddGstinComponent } from './add-gstin/add-gstin.component';
import { AddPOBComponent } from './add-pob/add-pob.component';
import { InvoiceTemplateEditorComponent } from './invoice-template-editor/invoice-template-editor.component';
import { UserSettingComponent } from './user-setting/user-setting.component';
import { ImageResolverService } from 'src/app/shared/resolvers/invoice-template-image-resolver';
import { NewTemplateResolver } from 'src/app/shared/resolvers/invoice-template-resolver';
import { InvoiceTemplateListComponent } from './invoice-template-list/invoice-template-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthGuard],
        component: SettingsComponent
    },
    {
        path: 'business-hierarchy',
        canActivate: [AuthGuard],
        component: SettingsComponent
    },
    {
        path: 'user-setting',
        canActivate: [AuthGuard],
        component: SettingsComponent
    },
    {
        path: 'user',
        canActivate: [AuthGuard],
        component: SettingsComponent
    },
    {
        path: 'addGstin',
        canActivate: [AuthGuard],
        component: AddGstinComponent
    },
    {
        path: 'addPlaceOfBusiness',
        canActivate: [AuthGuard],
        component: AddPOBComponent
    },
    {
      path: 'invoiceEditor/:templateId',
      resolve: { images: ImageResolverService, template: NewTemplateResolver },
      canActivate: [AuthGuard],
      component: InvoiceTemplateEditorComponent
    },
    {
      path: 'templates',
      canActivate: [AuthGuard],
      component: InvoiceTemplateListComponent
    },
]

@NgModule({
    imports: [RouterModule.forChild(routes)]
})
export class SettingsRoutingModule { }
