import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { UserSettingsService } from '../../../services/user-settings.service';
import { BaseResponse } from '../../../../models/response';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { paginationPrams } from '../../../../shared/constant';
import { ToasterService } from '../../../../shared/services/toaster.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { GetterSetterService } from '../../../../shared/services/getter-setter.service';

@Component({
  selector: 'app-user-access',
  templateUrl: './user-access.component.html',
  styleUrls: ['./user-access.component.scss']
})
export class UserAccessComponent implements OnInit {
  companyId: string;
  userList: any;
  roleList: any;
  navData: any;
  // clonedUser: any;
  inviteForm: FormGroup;
  isSubmitted: boolean = false;
  @ViewChild('closeModal', { static: false }) closeModal: ElementRef;
  userID: any;

  constructor(
    private US: UserSettingsService,
    private toaster: ToasterService,
    private fb: FormBuilder,
    private GS: GetterSetterService
  ) {
  }

  ngOnInit() {
    this.navData = JSON.parse(this.GS.getNavContextData());
    this.getRoleList();
    this.initializeData();
    this.initializeForm();
  }


  initializeForm() {
    this.inviteForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      role: ['', [Validators.required]],
      apiUsr: [false, []],
    });
  }

  getRoleList() {
    let i;
    this.US.fetchRoleList().subscribe((response: BaseResponse) => {
      if (response.status === 'SUCCESS') {
        /* remvoe the schedular and maker from the role list*/
        for (i = 0; i < response.response.length; i++) {
          if(response.response[i].name == "Scheduler" || response.response[i].name == "Maker") {
            response.response.splice(i,2);
          }
        }
        this.roleList = response.response;
        for (i = 0; i < this.roleList.length; i++) {
          this.roleList[i].label = this.roleList[i]['name'];
          this.roleList[i].value = this.roleList[i]['name'];
          delete this.roleList[i].name;
        }
      }
    })
  }

  initializeData() {
    if (this.navData.entityType == 'Business') {
      this.companyId = this.GS.getSetCompanyId();
    } else {
      this.companyId = this.navData.companyId;
    }
    this.US.fetchUserList(this.companyId).subscribe((response: BaseResponse) => {
      if (response.status === 'SUCCESS') {
        this.userList = response.response;
      }
    })
  }


  changeRole(user) {
    let roleId = null;
    this.roleList.forEach(element => {
      if (element.label == user.role) {
        roleId = element.id
      }
    });
    let viewHierarchy_id = sessionStorage.getItem("viewHierarchy_id");
    if (viewHierarchy_id && user) {
      this.US.changeUserRole(roleId, user.userid, viewHierarchy_id).subscribe((response: BaseResponse) => {
        if (response.status == "SUCCESS") {
          this.toaster.showSuccess("User role has changed successfuly!");
          // getUserListWithRoleAssigned();
        } else {
          this.toaster.showError("User role can not be changed!");
        }
      }, (e) => {
        console.log(e, 'EXCEPTION');
      })
    } else {
      this.toaster.showError("User role can not be changed!");
    }
  }

  deleteUser(user, index) {
    let viewHierarchy_id = sessionStorage.getItem("viewHierarchy_id");
    if (viewHierarchy_id && user) {
        this.US.deleteUserRole(user, viewHierarchy_id).subscribe((response: BaseResponse) => {
          if (response.status == "SUCCESS") {
            this.toaster.showSuccess("User role has deleted successfully!");
            this.initializeData();
            // getUserListWithRoleAssigned();
          } else {
            this.toaster.showError("User role can not be deleted!");
          }
        }, (e) => {
          console.log(e, 'EXCEPTION');
        })
      } else {
        this.toaster.showError("User role can not be deleted!");
      }
  }

  onRowEditInit(user) {
    // this.clonedCars[car.vin] = {...car};
  }

  inviteUser() {
    this.isSubmitted = true;
    let userData = {};
    if (this.inviteForm.valid) {
      let parentId = sessionStorage.getItem("viewHierarchy_id");
      if (!parentId) {
        parentId = this.GS.getSetCompanyId();
      }
      userData['email'] = this.inviteForm.value.email;
      userData['roleid'] = this.inviteForm.value.role;
      userData['apiUsr'] = this.inviteForm.value.apiUsr?this.inviteForm.value.apiUsr:false;
      userData['companyid'] = parentId;

      this.US.inviteUser(userData).subscribe((response: BaseResponse) => {
        this.isSubmitted = false;
        if (response.status === 'SUCCESS') {
            this.inviteForm.reset();
            this.toaster.showSuccess(response.message);           
            this.closeModal.nativeElement.click();
            this.initializeData();
        } else {
          this.toaster.showError(response.message);
        }
      })
    }
  }

  setUserId(userId: any) {
    this.userID = userId;
  }
}
