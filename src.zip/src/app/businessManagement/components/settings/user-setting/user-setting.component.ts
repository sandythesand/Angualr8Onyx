import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { UserSettingsService } from '../../../services/user-settings.service';
import { BaseResponse } from '../../../../models/response';
import { ToasterService } from '../../../../shared/services/toaster.service';
import { GetterSetterService } from '../../../../shared/services/getter-setter.service';

@Component({
  selector: 'app-user-setting',
  templateUrl: './user-setting.component.html',
  styleUrls: ['./user-setting.component.scss']
})
export class UserSettingComponent implements OnInit {

  sftpForm: FormGroup;
  sftpVal: any = false;
  isVisible: any = false;
  navContData: any;
  code: any;

  constructor(
    private fBuild: FormBuilder,
    private UserSettingsService: UserSettingsService,
    private toaster: ToasterService,
    private getSet: GetterSetterService
  ) { }

  ngOnInit() {
    this.navContData = JSON.parse(this.getSet.getNavContextData());
    this.code = this.navContData.pan;
    this.initialData();
  }

  initialData() {
    this.UserSettingsService.fetchSftp().subscribe((response: BaseResponse) => {
      this.isVisible = true;
      if (response.status === 'SUCCESS') {
        this.sftpVal = response.response.isGarnetAdmin;
        this.formInitialization();
      } else {
        this.toaster.showError(response.message);
      }
    });
  }

  formInitialization() {
    this.sftpForm = this.fBuild.group({
      isAdmin: [this.sftpVal, [Validators.required]],
      enableBulkPrint: [null, []],
    });
  }

  submitForm() {
    if(this.sftpForm.valid) {
      this.UserSettingsService.saveFtp(this.sftpForm.value.isAdmin).subscribe((response: BaseResponse) => {
        this.isVisible = true;
        if (response.status === 'SUCCESS') {
          this.toaster.showSuccess(response.message);
        } else {
          this.toaster.showError(response.message);
        }
      });
      let req = {
        allowbulkprint: this.sftpForm.value.enableBulkPrint ? 1 : 0,
        allowsftp: 0,
      } 
      this.UserSettingsService.bulkPrintAllow(this.code,req).subscribe((response: BaseResponse) => {
        this.isVisible = true;
        if (response.status === 'SUCCESS') {
          this.toaster.showSuccess(response.message);
        } else {
          this.toaster.showError(response.message);
        }
      });
    }
  }

}
