import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { BusinessService } from 'src/app/businessManagement/services/business.service';
import { ToasterService } from 'src/app/shared/services/toaster.service';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-invoice-template-list',
  templateUrl: './invoice-template-list.component.html',
  styleUrls: ['./invoice-template-list.component.scss']
})
export class InvoiceTemplateListComponent implements OnInit {

  templateList = [];
  addAssetForm: any;
  isSubmitted = false;
  @ViewChild('closeModal', { static: false }) closeModal: ElementRef;
  @ViewChild('closeModal1', { static: false }) closeModal1: ElementRef;
  modalHeader: string;
  modalBody: string;
  templateId: any;
  constructor(
    private router: Router,
    private BMS: BusinessService,
    private toaster: ToasterService,
    private fb: FormBuilder,
  ) { }
  ngOnInit() {
    this.initializeForm();
    this.init();
  }

  initializeForm() {
    this.addAssetForm = this.fb.group({
      name: ['', [Validators.required]],
      img: ['', [Validators.required]]
    });
  }

  delTemplate(id){
    this.BMS.delTemplate(id).subscribe((resp) => {
      this.toaster.showSuccess('Deleted!');
      this.init();
    });
  }

  init() {

    this.BMS.getAllTemplates().subscribe((response) => this.templateList = response['response']);
  }

  newTemplate() {
    this.router.navigate(['/settings/invoiceEditor/0']);
  }

  editTemplate(id) {
    this.router.navigate([`/settings/invoiceEditor/${id}`]);
  }

  commonModalInitialize(obj, id) {
    if (obj == 'Delete') {
      this.modalHeader = 'Delete Template';
      this.modalBody = `This will delete the template. Continue? Note down template name\
                  and get in touch with backend team if want to recover it at a later stage`;
      // }
      this.templateId = id;
    }
  }

  confirm(modalHeader) {
    this.closeModal1.nativeElement.click();
    this.delTemplate(this.templateId);
  }

  activateTemplate(id) {
    this.BMS.changeTemplateStatus({id, status: 1}).subscribe((resp) => {
      this.toaster.showSuccess('Activated!');
      this.init();
    });
  }

  deactivateTemplate(id) {
    this.BMS.changeTemplateStatus({id, status: 0}).subscribe((resp) => {
      this.toaster.showSuccess('Deactivated!');
      this.init();
    });
  }

  uploadAsset() {
    this.isSubmitted = true;
    console.log(this.addAssetForm.value);
    this.BMS.uploadAsset(this.addAssetForm.get('name').value, this.addAssetForm.get('img').value).subscribe(
      (resp) => {
        this.toaster.showSuccess('Upload');
        this.closeModal.nativeElement.click();
      });
  }

  onFileSelect(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.addAssetForm.get('img').setValue(file);
    }
  }

}
