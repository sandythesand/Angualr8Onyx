import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPOBComponent } from './add-pob.component';

describe('AddPOBComponent', () => {
  let component: AddPOBComponent;
  let fixture: ComponentFixture<AddPOBComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPOBComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPOBComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
