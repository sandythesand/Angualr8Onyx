import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StateListService } from '../../../../shared/services/state-list.service';
import { BaseResponse } from '../../../../models/response';
import { ToasterService } from '../../../../shared/services/toaster.service';
import { GetterSetterService } from '../../../../shared/services/getter-setter.service';
import { Router } from '@angular/router';
import { BusinessService } from '../../../services/business.service';
import { STATE_LIST } from '../../../../shared/constant';
import { APP_NAME } from 'src/app/shared/constant';

@Component({
  selector: 'app-add-pob',
  templateUrl: './add-pob.component.html',
  styleUrls: ['./add-pob.component.scss']
})
export class AddPOBComponent implements OnInit {
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  addPOBForm: FormGroup;
  stateList: any;
  parentGSTIN = sessionStorage.getItem('company');
  isSubmitted: boolean;
  isDisabled: boolean = false;

  constructor(
    private fb: FormBuilder,
    private stateService: StateListService,
    private toaster: ToasterService,
    private getterSetter: GetterSetterService,
    private router: Router,
    private BS: BusinessService,

  ) {
    this.APP_NAME = APP_NAME;
   }

  ngOnInit() {
    console.log('oioioi')
    //this.initalStateData();
    this.formInitialization();
    this.stateList = STATE_LIST;
  }

  initalStateData() {
    this.stateService.getStatesList().subscribe((response: BaseResponse) => {
      if (response.status == 'SUCCESS') {
        this.stateList = response.response;
      } else if (response.status == 'FAILURE') {
        this.toaster.showWarning(response.message);
      }
    });
  }

  formInitialization() {
    this.addPOBForm = this.fb.group({
      companyname: [null, [Validators.required, Validators.minLength(1)]],
      address: [null],
      address1: [null],
      city: [null],
      pincode: ['', [Validators.required,Validators.minLength(1)]],
      state: ['', [Validators.required]],
      pobCode: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(50)]],//Validators.pattern(new RegExp('^[a-zA-Z0-9_-]*$'))
      phone: [null, [ Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$"), Validators.minLength(10), Validators.maxLength(10)]],
      email: [null, [ Validators.email] ],
    });
  }
  toDashboard(){
    this.router.navigate([`${this.APP_NAME.ONYX}`]);
  }
  addPOB() {
    let data;
    this.isSubmitted = true;
    this.isDisabled = true;
    if (this.addPOBForm.valid) {
      data = this.addPOBForm.value;
      data.parentid = this.getterSetter.getviewHierarchy_id();
      data.entitytype = "POB";
      this.BS.addBusinessFunction(data).subscribe((response: BaseResponse) => {
        this.isDisabled = false;
        if (response.status == 'SUCCESS') {
          this.toaster.showSuccess(response.message);
          this.router.navigate(['settings']);
        } else {
          this.toaster.showError(response.errors[0].field);
        }
        this.isSubmitted = false;
      });
    } else {
      this.isDisabled = false;
    }
  }

}
