import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessHierarchyComponent } from './business-hierarchy.component';

describe('BusinessHierarchyComponent', () => {
  let component: BusinessHierarchyComponent;
  let fixture: ComponentFixture<BusinessHierarchyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessHierarchyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessHierarchyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
