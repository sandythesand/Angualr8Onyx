import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { BaseResponse } from '../../../../models/response';
import { ToasterService } from '../../../../shared/services/toaster.service';
import { paginationPrams, taxpayerTypes, STATE_LIST } from '../../../../shared/constant';
import { BusinessService } from '../../../services/business.service';
import { GetterSetterService } from '../../../../shared/services/getter-setter.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { APP_NAME } from 'src/app/shared/constant';
import { Router } from '@angular/router';
import { StateListService } from '../../../../shared/services/state-list.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-business-hierarchy',
  templateUrl: './business-hierarchy.component.html',
  styleUrls: ['./business-hierarchy.component.scss']
})
export class BusinessHierarchyComponent implements OnInit {

  updateBusiness: FormGroup;
  addLegalForm: FormGroup;
  fillingForm: FormGroup;
  companyId: any = 10;
  businessList: any = [];
  isFiling: boolean = false;
  isPOB: boolean = false;
  formData: any = {};
  pagination: any;
  navContextData: any;
  companyName: string;
  entityName: string;
  businessName: string;
  isBusinessName: boolean = false;
  isSubmitted: boolean = false;
  APP_NAME: { ONYX: string; TOPAZ: string; Saphhire: string; };
  $: any;
  stateList: any;
  taxpayerList: { key: string; displayName: string; }[];
  parentBusinessCompany = sessionStorage.getItem('company');
  pobForm: FormGroup;
  nicForm: FormGroup;
  nicFlag: boolean;
  isTopazLogin: boolean = false;
  isOnyxLogin: boolean = false;
  currentProductAccess: any;
  isTopazAccess: boolean = false;
  isOnyxAccess: boolean = false;
  @ViewChild('closeModal', { static: false }) closeModal: ElementRef;
  req: any;
  isDisableTopazField: boolean = false;
  docToDate: Date;
  maxDate = new Date();
  currentYear: any;
  regDate: Date;
  isDisabled: boolean = false;

  constructor(
    private fBuild: FormBuilder,
    private toaster: ToasterService,
    private businessService: BusinessService,
    private getterSetter: GetterSetterService,
    private router: Router,
    private stateService: StateListService,
    private datePipe: DatePipe
  ) {
    this.navContextData = JSON.parse(this.getterSetter.getNavContextData());
    this.pagination = paginationPrams;
    this.companyName = this.getterSetter.getSetCompany();
    this.APP_NAME = APP_NAME;
    this.taxpayerList = taxpayerTypes;
  }

  ngOnInit() {
    this.currentYear = (new Date()).getFullYear();
    this.req = JSON.parse(sessionStorage.getItem('selectedFilling'));
    this.currentProductAccess = sessionStorage.getItem('products');
    let tempArrProduct = this.currentProductAccess.split(',');
    if(tempArrProduct) {
      tempArrProduct.forEach(e => {
      if(e == 'TOPAZ') {
        this.isTopazAccess = true;
      }
      if(e == 'ONYX') {
        this.isOnyxAccess = true;
      }
    });
    }
    // this.initalStateData();
    this.stateList = STATE_LIST;
    this.validateForms();
    this.initializeData();

  }


  initalStateData() {
    this.stateService.getStatesList().subscribe((response: BaseResponse) => {
      if (response.status == 'SUCCESS') {
        this.stateList = response.response;
      } else if (response.status == 'FAILURE') {
        this.toaster.showWarning(response.message);
      }
    });
  }


  validateForms() {
    this.addLegalForm = this.fBuild.group({
      companyname: [null, [Validators.required]],
      pan: [null, [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(new RegExp('^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$'))]],
    });
  }

  initializeData() {
    if (this.navContextData.companyId != null) {
      this.companyId = this.navContextData.companyId;
    } else {
      this.companyId = this.getterSetter.getSetCompanyId();
    }
    this.businessService.viewEntity(this.companyId).subscribe((response: BaseResponse) => {
      if (response.status === "SUCCESS") {
        if (response.response !== null && response.response !== "") {
          this.formData = response.response;
          if (response.response.entityType == "FILING") {
            this.isFiling = true;
            this.isBusinessName = false;
            this.isPOB = false;
            this.getterSetter.getSetFilingGstin(response.response.gstin);
            this.entityName = "Taxpayer Name";
            if(this.formData.registartionDate)
              this.regDate = new Date(this.formData.registartionDate);
            this.fillingFormInitialize();
          } else if (response.response.entityType == "POB") {
            this.isPOB = true;
            this.isFiling = false;
            this.isBusinessName = false;
            this.entityName = "POB Name";
            this.businessName = this.getterSetter.getSetfilingEntityName();
            this.pobFormInitialize();
          } else {
            this.entityName = "Legal Entity Name";
            this.isBusinessName = true;
            if (this.getterSetter.getviewHierarchy_id() == this.getterSetter.getSetCompanyId()) {
              this.entityName = "Business Name";
            }
            this.formValidationUpdateBusiness();
          }
        }
      } else {
        this.toaster.showError(response.message);
      }
    });
  }


  pobFormInitialize() {
    this.pobForm = this.fBuild.group({
      companyname: [this.formData.companyName, [Validators.required]],
      address: [this.formData.cmpAddress],
      address1: [this.formData.cmpAddress1],
      city: [this.formData.city],
      pincode: [this.formData.cmpPincode, [Validators.required]],
      state: [this.formData.stateCode, [Validators.required]],
      phone: [this.formData.cmpPhone, [ Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$"), Validators.minLength(10), Validators.maxLength(10)]],
      email: [this.formData.cmpEmail, [ Validators.email]],
    });
  }

  fillingFormInitialize() {
    this.fillingForm = this.fBuild.group({
      companyname: [this.formData.companyName, [Validators.required, Validators.minLength(1)]],
      gstinno: [this.formData.gstnNo],
      taxpayerType: [this.formData.taxpayerType],
      nicUserName: [this.formData.nicUserNameOnyx],
      address: [this.formData.cmpAddress],
      address1: [this.formData.cmpAddress1],
      city: [this.formData.city],
      pincode: [this.formData.cmpPincode],
      state: [this.formData.stateCode],
      // phone: [],
      // email: [],
      phone: [this.formData.cmpPhone, [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$"), Validators.minLength(10), Validators.maxLength(10)]],
      email: [this.formData.cmpEmail, [Validators.required, Validators.email]],
      registartionDate: [this.regDate?this.regDate:null],
    });
  }

  nicFormInitialize() {
    this.nicFlag = true;
    this.nicForm = this.fBuild.group({
      nicUserNameOnyx: [this.formData.nicUserName, [Validators.required]],
      nicPasswordOnyx: ['', [Validators.required]],
      nicUserNameTopaz: [null],
      nicPasswordTopaz: [null],
      isTopazNicCredential: [null],
    });
    // this.setTopazFormValidity();
  }

  setTopazFormValidity() {
    let tempTopaznicUname = this.nicForm.get('nicUserNameTopaz');
    let tempTopaznicPassword = this.nicForm.get('nicPasswordTopaz');
    if(this.isTopazAccess) {
      tempTopaznicUname.setValidators([Validators.required]);
      tempTopaznicPassword.setValidators([Validators.required]);
    }
  }

  formValidationUpdateBusiness() {
    this.updateBusiness = this.fBuild.group({
      companyname: [this.formData.companyName, [Validators.required]],
      pan: [this.formData.panNo, [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(new RegExp('^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$'))]],
      address: [this.formData.cmpAddress],
      phone: [this.formData.cmpPhone],
      fax: [this.formData.faxNo],
      email: [this.formData.cmpEmail],
      website: [this.formData.website]
    });
  }

  setAsAboveVal() {
    if(this.nicForm.get('isTopazNicCredential').value === true){
      this.isDisableTopazField = true;
      this.nicForm.get('nicUserNameTopaz').setValue(this.nicForm.get('nicUserNameOnyx').value);
      this.nicForm.get('nicPasswordTopaz').setValue(this.nicForm.get('nicPasswordOnyx').value);
    } else {
      this.isDisableTopazField = false;
      this.nicForm.get('nicUserNameTopaz').setValue('');
      this.nicForm.get('nicPasswordTopaz').setValue('');
    }
  }

  updateBusinessForm() {
    this.isSubmitted = true;
    this.isDisabled = true;
    if (this.updateBusiness.valid) {
      if (this.companyId) {
        this.updateBusiness.value.companyid = this.formData.companyId;
        this.updateBusiness.value.taxpayerType = "NORMAL";
        this.updateBusiness.value.entitytype = this.formData.entityType;
      }
      this.businessService.updateBusiness(this.updateBusiness.value).subscribe((response: BaseResponse) => {
        this.isDisabled = false;
        if (response.status == 'SUCCESS') {
          this.formData = {};
          this.toaster.showSuccess(response.message);
          this.router.navigate([`${this.APP_NAME.ONYX}`]);
        } else if (response.status == 'FAILURE') {
          this.toaster.showWarning(response.message);
        }
        this.isSubmitted = false;
      });
    } else {
      this.isDisabled = false;
    }
  }

  gotoDash() {
    this.router.navigate([`${this.APP_NAME.ONYX}`]);
  }

  addGstins() {
    this.router.navigate(['/settings/addGstin']);
  }

  addLegal() {
    let parentId = this.getterSetter.getviewHierarchy_id();
    let model = {
      'companyname': this.addLegalForm.value.companyname,
      'pan': this.addLegalForm.value.pan,
      'parentid': parentId,
      'entitytype': 'LEGAL'
    };
    this.isSubmitted = true;
    if (this.addLegalForm.valid) {
      this.businessService.addBusinessFunction(model).subscribe((response: BaseResponse) => {
        if (response.status == 'SUCCESS') {
          this.addLegalForm.reset();
          this.toaster.showSuccess('Legal Entity added successfully.');
         // this.router.navigate[`${this.APP_NAME.ONYX}`];
          this.closeModal.nativeElement.click();
        } else {
          this.toaster.showError(response.errors[0].field);
        }
        this.isSubmitted = false;
      });
    }

  }

  addPOB() {
    this.router.navigate(['/settings/addPlaceOfBusiness']);
  }
  toDashboard(){
    this.router.navigate([`${this.APP_NAME.ONYX}`]);
  }


  updateFilling() {
    this.isSubmitted = true;
    let data;
    if (this.fillingForm.valid) {
      data = this.fillingForm.value;
      data.companyid = this.formData.companyId;
      data.entitytype = "FILING";
      data.registartionDate = this.datePipe.transform(this.fillingForm.value.registartionDate, 'yyyy-MM-dd');
      this.businessService.updateBusiness(data).subscribe((response: BaseResponse) => {
        if (response.status == 'SUCCESS') {
          this.formData = {};
          this.toaster.showSuccess(response.message);
          this.router.navigate([`${this.APP_NAME.ONYX}`]);
        } else {
          this.toaster.showError(response.message);
        }
        this.isSubmitted = false;
      });
    }
  }

  pobUpdate() {
    this.isSubmitted = true;
    let data;
    if (this.pobForm.valid) {
      data = this.pobForm.value;
      data.companyid = this.formData.companyId;
      data.entitytype = "POB"
      this.businessService.updateBusiness(data).subscribe((response: BaseResponse) => {
        if (response.status == 'SUCCESS') {
          this.formData = {};
          this.toaster.showSuccess(response.message);
          this.router.navigate([`${this.APP_NAME.ONYX}`]);
        } else {
          this.toaster.showError(response.message);
        }
        this.isSubmitted = false;
      });
    }
  }

  nicSubmit() {
    let data;
    if (this.nicForm.valid) {
      data = this.nicForm.value;
      data.gstin = this.req.gstin;
      delete this.nicForm.value['isTopazNicCredential'];
      this.businessService.updateNIC(this.nicForm.value).subscribe((response: BaseResponse) => {
        if (response.status == 'SUCCESS') {
          this.formData = {};
          this.toaster.showSuccess(response.message);
        } else if (response.status == 'FAILURE') {
          this.toaster.showWarning(response.message);
        }
      });
    }
  }

  dateSelection(type) {
    if(type == 'regDt'){
      this.docToDate = new Date(this.fillingForm.value.registartionDate);
    }
  }

}

