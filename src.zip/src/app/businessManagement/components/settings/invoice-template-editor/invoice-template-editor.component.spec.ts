import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceTemplateEditorComponent } from './invoice-template-editor.component';

describe('InvoiceTemplateEditorComponent', () => {
  let component: InvoiceTemplateEditorComponent;
  let fixture: ComponentFixture<InvoiceTemplateEditorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceTemplateEditorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceTemplateEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
