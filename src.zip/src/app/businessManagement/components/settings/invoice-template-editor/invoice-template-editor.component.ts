import { Component, OnInit, OnDestroy } from '@angular/core';
import { BusinessService } from 'src/app/businessManagement/services/business.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subject, AsyncSubject, interval } from 'rxjs';
import { maxLength } from './maxlength-validator';
import { takeWhile, debounceTime} from 'rxjs/operators';
import { ToasterService } from 'src/app/shared/services/toaster.service';
declare var tinymce: any;
@Component({
  selector: 'app-invoice-template-editor',
  templateUrl: './invoice-template-editor.component.html',
  styleUrls: ['./invoice-template-editor.component.scss']
})
export class InvoiceTemplateEditorComponent implements OnInit, OnDestroy {

  transactionTypes = [
    {name: 'Regular', value: 'Regular'},
    {name: 'Bill To Ship To', value: 'BTST'},
    {name: 'Bill From Dispatch From', value: 'BFDF'},
    {name: 'Bill To Ship To and Bill From Dispatch From', value: 'BOTH'}
  ];

  documentTypes = [
    {name: 'RI', value: 'RI'},
    {name: 'BS', value: 'BS'},
    {name: 'C', value: 'C'},
    {name: 'D', value: 'D'},
    {name: 'R', value: 'R'},
    {name: 'BOE', value: 'BOE'},
    {name: 'DC', value: 'DC'},
    {name: 'OTH', value: 'OTH'},
  ];

  dateFormats = [
    {name: 'dd-MMM-yyyy', value: 'dd-MMM-yyyy'},
    {name: 'dd-MM-yyyy', value: 'dd-MM-yyyy'},
    {name: 'dd-MM-yy', value: 'dd-MM-yy'},
    {name: 'yyyy-MM-dd', value: 'yyyy-MM-dd'},
  ];

  footerReqTypes = [
    {name: 'Yes', value: 1},
    {name: 'No', value: 0}
  ];

  invoiceTypes = [
    {name: 'B2B', value: 'B2B'},
    {name: 'B2CL', value: 'B2CL'},
    {name: 'B2CS', value: 'B2CS'},
    {name: 'SEWP', value: 'SEWP'},
    {name: 'SEWOP', value: 'SEWOP'},
    {name: 'DE', value: 'DE'},
    {name: 'CWB', value: 'CWB'},
    {name: 'EXWP', value: 'EXWP'},
    {name: 'EXWOP', value: 'EXWOP'},

  ];
  levels = [
    {name: 'Root', value: 0},
    {name: 'Legal', value: 1},
    {name: 'GSTIN', value: 2},
    {name: 'POB', value: 3}
  ];
  status = [
    {name: 'Inactive', value: -1},
    {name: 'Active', value: 1},
    {name: 'Draft', value: 0}
  ];

  orientation = [
    {name: 'Portrait', value: 1},
    {name: 'Landscape', value: 2}
  ];

  allTypes = [];
  isActive = false;
  autoSave$: any;
  show = false;
  template: any;
  constructor(
    private businessManagement: BusinessService,
    private route: ActivatedRoute,
    private toaster: ToasterService,
    private router: Router
  ) {
  }

  initialConfig;
  images;
  formAlive = true;
  loading = -1;
  editorSubject: Subject<any> = new AsyncSubject();

  invoiceTemplateForm = new FormGroup({
    id: new FormControl(-1),
    name: new FormControl(''),
    level: new FormControl(''),
    identifier: new FormControl(''),
    ctin: new FormControl(''),
    dscReqd: new FormControl(0),
    signReqd: new FormControl(0),
    type: new FormControl(''),
    html: new FormControl('', Validators.required), // maxLength(this.editorSubject, 10)
    status: new FormControl(-1, Validators.required), // maxLength(this.editorSubject, 10)
    orientation: new FormControl(1),
    dateFormat: new FormControl(''),
    docType: new FormControl(''),
    footerReq: new FormControl(''),
    xpos: new FormControl(''),
    ypos: new FormControl(''),
  });
  handleEditorInit(e) {
    this.editorSubject.next(e.editor);
    // this.editorSubject.complete();
  }

  get html() {
    return this.invoiceTemplateForm.get('html') as FormControl;
  }

  templateStatus() {
    this.isActive = this.invoiceTemplateForm.get('status').value <= 0 ? false : true;
  }

  toggleStatusDraft() {
    this.isActive = false;
  }

  ngOnInit() {

    this.invoiceTemplateForm.get('orientation').valueChanges.subscribe((value) => {
      if (value === 1) {
        this.initialConfig.height = 800;
        this.initialConfig.width = 1000;
      } else {
        this.initialConfig.height = 1000;
        this.initialConfig.width = 800;
      }
      console.log(this.initialConfig);
    });

    this.invoiceTemplateForm.statusChanges.pipe(
      debounceTime(3000),
      takeWhile(() => this.formAlive)
      ).
      subscribe(
        (status) =>
        {
          this.loading += 1;
          if (status === 'VALID' && this.loading > 0)  {
            this.autoSaveFunction();
            // this.toaster.showInfo({message: 'Draft auto-saved!'});
          }
        });
    this.images = this.route.snapshot.data.images['response'];
    this.template = this.route.snapshot.data.template['response'];
    this.invoiceTemplateForm.patchValue(this.template);
    this.initialConfig = {
          setup: (editor) => {
            editor.on('init', (e) => {
              console.log('Editor was init');
              this.show = true;
            });
          },
          height: 800,
          width: 1000,
          menubar: true,
          plugins: [
            'advlist autolink lists link image charmap print',
            'preview anchor searchreplace visualblocks code',
            'fullscreen insertdatetime media table paste',
            'help wordcount'
          ],
          formats: {
            mark: { selector: 'tr', classes: 'repeatable' }
          },
          image_advtab: true,
          external_plugins: {
            'build': 'https://docs-irisgst-com.s3.ap-south-1.amazonaws.com/plugs/plugin.min.v02_dev.js'
          },
          contextmenu: 'link image inputformat mark addHeader addQRCodePlaceholder taxSummary group barcode qrCode formula cessSummary hsnGroupSummary nicLogo',
          toolbar:
            'undo redo | formatselect | bold italic | \
            alignleft aligncenter alignright alignjustify | \
            bullist numlist outdent indent| help',
          file_picker_types: 'image',
          /* and here's our custom image picker*/
          // images_upload_url: 'https://api.kraken.io/v1/upload',
          // images_upload_credentials: true,
          image_list: this.images,
      };
      this.templateStatus(); // Set Initial Active/Deactivate Show Status

  }

  saveTemplate() {
    this.businessManagement.saveTemplate(this.invoiceTemplateForm.value).subscribe((response) => {
      this.toaster.showInfo({message: 'Template Saved'});
      this.toggleStatusDraft();
  });

  }

  autoSaveFunction() {
    // console.log(this.invoiceTemplateForm.value);
    this.businessManagement.saveTemplate(this.invoiceTemplateForm.value).subscribe((response) => {
      this.toaster.showInfo({message: 'Template Auto-saved'});
      this.toggleStatusDraft();
    });

    // console.log(this.invoiceTemplateForm.value);
  }

  activateTemplate(id) {
    this.businessManagement.changeTemplateStatus({id, status: 1}).subscribe((resp) => {
      this.toaster.showSuccess('Activated!');
      this.router.navigate([`/settings/templates`]);
    });
  }

  deactivateTemplate(id) {
    this.businessManagement.changeTemplateStatus({id, status: 0}).subscribe((resp) => {
      this.toaster.showSuccess('Deactivated!');
      this.router.navigate([`/settings/templates`]);
    });
  }

  showPDF(data): void {
    this.businessManagement.previewPDF({html: data, orientation: this.invoiceTemplateForm.get('orientation').value})
        .subscribe(x => {
            // It is necessary to create a new blob object with mime-type explicitly set
            // otherwise only Chrome works like it should
            const newBlob = new Blob([x], { type: "application/pdf" });

            // IE doesn't allow using a blob object directly as link href
            // instead it is necessary to use msSaveOrOpenBlob
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(newBlob);
                return;
            }

            // For other browsers:
            // Create a link pointing to the ObjectURL containing the blob.
            const data = window.URL.createObjectURL(newBlob);

            const link = document.createElement('a');
            link.href = data;
            link.download = 'Preview.pdf';
            // this is necessary as link.click() does not work on the latest firefox
            link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

            setTimeout(() => {
                // For Firefox it is necessary to delay revoking the ObjectURL
                window.URL.revokeObjectURL(data);
                link.remove();
            }, 100);
        });
  }

  copy() {
    navigator.clipboard.writeText(this.invoiceTemplateForm.get('html').value);
  }

  setText($event) {
    this.invoiceTemplateForm.get('html').setValue($event.target.value);
  }

  ngOnDestroy() {
    // this.autoSave$.unsubscribe();
    this.formAlive = false;
  }
}
