/*filter js*/
  
$(function() {
    $(".nav-settings").on("click", function() {
      $("#right-sidebar").toggleClass("open");
    });
    $(".settings-close").on("click", function() {
      $("#right-sidebar,#theme-settings, #quickSort").removeClass("open");
    });

    $("#settings-trigger").on("click" , function(){
      $("#theme-settings").toggleClass("open");
    });
	 $("#sortFilterLbl").on("click" , function(){
      $("#theme-settings").toggleClass("open");
    });
	$("#quickSortBtn").on("click" , function(){
      $("#quickSort").toggleClass("open");
    });

  });
/*filter js*/