(function () {
  var build = (function () {
      'use strict';

      tinymce.PluginManager.add("build", function (editor, url) {

          /*
          Add a custom icon to TinyMCE
           */
          editor.ui.registry.addIcon('build', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path clip-rule="evenodd" d="M0 0h24v24H0z" fill="none"/><path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/></svg>');
          editor.ui.registry.addIcon('mark', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0zm0 0h24v24H0V0z" fill="none"/><path d="M16.59 7.58L10 14.17l-3.59-3.58L5 12l5 5 8-8zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"/></svg>');
          editor.ui.registry.addIcon('printshop', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('work', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/></svg>');
          editor.ui.registry.addIcon('description', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>');
          editor.ui.registry.addIcon('link', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z"/></svg>');
          editor.ui.registry.addIcon('post_add', '<svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24"><g><rect fill="none" height="24" width="24"/></g><g><g/><g><path d="M17,19.22H5V7h7V5H5C3.9,5,3,5.9,3,7v12c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2v-7h-2V19.22z"/><path d="M19,2h-2v3h-3c0.01,0.01,0,2,0,2h3v2.99c0.01,0.01,2,0,2,0V7h3V5h-3V2z"/><rect height="2" width="8" x="7" y="9"/><polygon points="7,12 7,14 15,14 15,12 12,12"/><rect height="2" width="8" x="7" y="15"/></g></g></svg>');
          editor.ui.registry.addIcon('contacts', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0zm0 0h24v24H0zm0 0h24v24H0z" fill="none"/><path d="M20 0H4v2h16V0zM4 24h16v-2H4v2zM20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-8 2.75c1.24 0 2.25 1.01 2.25 2.25s-1.01 2.25-2.25 2.25S9.75 10.24 9.75 9 10.76 6.75 12 6.75zM17 17H7v-1.5c0-1.67 3.33-2.5 5-2.5s5 .83 5 2.5V17z"/></svg>');
          editor.ui.registry.addIcon('assignment', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm0 4c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm6 12H6v-1.4c0-2 4-3.1 6-3.1s6 1.1 6 3.1V19z"/></svg>');
          editor.ui.registry.addIcon('room', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('local_grocery', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('swap_vertical', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM6.5 9L10 5.5 13.5 9H11v4H9V9H6.5zm11 6L14 18.5 10.5 15H13v-4h2v4h2.5z"/></svg>');
          editor.ui.registry.addIcon('receipt', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M18 17H6v-2h12v2zm0-4H6v-2h12v2zm0-4H6V7h12v2zM3 22l1.5-1.5L6 22l1.5-1.5L9 22l1.5-1.5L12 22l1.5-1.5L15 22l1.5-1.5L18 22l1.5-1.5L21 22V2l-1.5 1.5L18 2l-1.5 1.5L15 2l-1.5 1.5L12 2l-1.5 1.5L9 2 7.5 3.5 6 2 4.5 3.5 3 2v20z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('arrow_down', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 12l-4-4h8l-4 4z"/></svg>');
          editor.ui.registry.addIcon('info', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>');
          editor.ui.registry.addIcon('format_list', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M4 10.5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5 1.5-.67 1.5-1.5-.67-1.5-1.5-1.5zm0-6c-.83 0-1.5.67-1.5 1.5S3.17 7.5 4 7.5 5.5 6.83 5.5 6 4.83 4.5 4 4.5zm0 12c-.83 0-1.5.68-1.5 1.5s.68 1.5 1.5 1.5 1.5-.68 1.5-1.5-.67-1.5-1.5-1.5zM7 19h14v-2H7v2zm0-6h14v-2H7v2zm0-8v2h14V5H7z"/><path d="M0 0h24v24H0V0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('star', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('dollar', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('account', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>');
          editor.ui.registry.addIcon('shipping', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1.5 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>');
          editor.ui.registry.addIcon('style', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M2.53 19.65l1.34.56v-9.03l-2.43 5.86c-.41 1.02.08 2.19 1.09 2.61zm19.5-3.7L17.07 3.98c-.31-.75-1.04-1.21-1.81-1.23-.26 0-.53.04-.79.15L7.1 5.95c-.75.31-1.21 1.03-1.23 1.8-.01.27.04.54.15.8l4.96 11.97c.31.76 1.05 1.22 1.83 1.23.26 0 .52-.05.77-.15l7.36-3.05c1.02-.42 1.51-1.59 1.09-2.6zM7.88 8.75c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-2 11c0 1.1.9 2 2 2h1.45l-3.45-8.34v6.34z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('menu', '<svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24"><g><rect fill="none" height="24" width="24"/></g><g><g/><g><path d="M21,5c-1.11-0.35-2.33-0.5-3.5-0.5c-1.95,0-4.05,0.4-5.5,1.5c-1.45-1.1-3.55-1.5-5.5-1.5S2.45,4.9,1,6v14.65 c0,0.25,0.25,0.5,0.5,0.5c0.1,0,0.15-0.05,0.25-0.05C3.1,20.45,5.05,20,6.5,20c1.95,0,4.05,0.4,5.5,1.5c1.35-0.85,3.8-1.5,5.5-1.5 c1.65,0,3.35,0.3,4.75,1.05c0.1,0.05,0.15,0.05,0.25,0.05c0.25,0,0.5-0.25,0.5-0.5V6C22.4,5.55,21.75,5.25,21,5z M21,18.5 c-1.1-0.35-2.3-0.5-3.5-0.5c-1.7,0-4.15,0.65-5.5,1.5V8c1.35-0.85,3.8-1.5,5.5-1.5c1.2,0,2.4,0.15,3.5,0.5V18.5z"/><g><path d="M17.5,10.5c0.88,0,1.73,0.09,2.5,0.26V9.24C19.21,9.09,18.36,9,17.5,9c-1.7,0-3.24,0.29-4.5,0.83v1.66 C14.13,10.85,15.7,10.5,17.5,10.5z"/><path d="M13,12.49v1.66c1.13-0.64,2.7-0.99,4.5-0.99c0.88,0,1.73,0.09,2.5,0.26V11.9c-0.79-0.15-1.64-0.24-2.5-0.24 C15.8,11.66,14.26,11.96,13,12.49z"/><path d="M17.5,14.33c-1.7,0-3.24,0.29-4.5,0.83v1.66c1.13-0.64,2.7-0.99,4.5-0.99c0.88,0,1.73,0.09,2.5,0.26v-1.52 C19.21,14.41,18.36,14.33,17.5,14.33z"/></g></g></g></svg>');
          editor.ui.registry.addIcon('sort', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M3 18h6v-2H3v2zM3 6v2h18V6H3zm0 7h12v-2H3v2z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('addBox', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
          editor.ui.registry.addIcon('filter', '<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M15.96 10.29l-2.75 3.54-1.96-2.36L8.5 15h11l-3.54-4.71zM3 5H1v16c0 1.1.9 2 2 2h16v-2H3V5zm18-4H7c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V3c0-1.1-.9-2-2-2zm0 16H7V3h14v14z"/></svg>');
          editor.ui.registry.addIcon('menuBook', '<svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24"><g><rect fill="none" height="24" width="24"/></g><g><g/><g><path d="M21,5c-1.11-0.35-2.33-0.5-3.5-0.5c-1.95,0-4.05,0.4-5.5,1.5c-1.45-1.1-3.55-1.5-5.5-1.5S2.45,4.9,1,6v14.65 c0,0.25,0.25,0.5,0.5,0.5c0.1,0,0.15-0.05,0.25-0.05C3.1,20.45,5.05,20,6.5,20c1.95,0,4.05,0.4,5.5,1.5c1.35-0.85,3.8-1.5,5.5-1.5 c1.65,0,3.35,0.3,4.75,1.05c0.1,0.05,0.15,0.05,0.25,0.05c0.25,0,0.5-0.25,0.5-0.5V6C22.4,5.55,21.75,5.25,21,5z M21,18.5 c-1.1-0.35-2.3-0.5-3.5-0.5c-1.7,0-4.15,0.65-5.5,1.5V8c1.35-0.85,3.8-1.5,5.5-1.5c1.2,0,2.4,0.15,3.5,0.5V18.5z"/><g><path d="M17.5,10.5c0.88,0,1.73,0.09,2.5,0.26V9.24C19.21,9.09,18.36,9,17.5,9c-1.7,0-3.24,0.29-4.5,0.83v1.66 C14.13,10.85,15.7,10.5,17.5,10.5z"/><path d="M13,12.49v1.66c1.13-0.64,2.7-0.99,4.5-0.99c0.88,0,1.73,0.09,2.5,0.26V11.9c-0.79-0.15-1.64-0.24-2.5-0.24 C15.8,11.66,14.26,11.96,13,12.49z"/><path d="M17.5,14.33c-1.7,0-3.24,0.29-4.5,0.83v1.66c1.13-0.64,2.7-0.99,4.5-0.99c0.88,0,1.73,0.09,2.5,0.26v-1.52 C19.21,14.41,18.36,14.33,17.5,14.33z"/></g></g></g></svg>');
          /*
          Use to store the instance of the Dialog
           */
          var _dialog = false;

          /*
          An array of options to appear in the "Type" select box.
           */
          var _typeOptions = [];

          /**
           * Get the Dialog Configuration Object
           *
           * @returns {{buttons: *[], onSubmit: onSubmit, title: string, body: {}}}
           * @private
           */
          function _getDialogConfig(title)
          {
              return {
                  title: title,
                  body: {
                      type: 'panel',
                      items: [{
                          type: 'selectbox',
                          name: 'type',
                          label: 'Select',
                          items: _typeOptions,
                          flex: true
                      }]
                  },
                  onSubmit: function (api) {
                      // insert markup
                      editor.insertContent('${' + api.getData().type + '}');

                      // close the dialog
                      api.close();
                  },
                  buttons: [
                      {
                          text: 'Close',
                          type: 'cancel',
                          onclick: 'close'
                      },
                      {
                          text: 'Insert',
                          type: 'submit',
                          primary: true,
                          enabled: false
                      }
                  ]
              };
          }

          /**
           * Plugin behaviour for when the Toolbar or Menu item is selected
           *
           * @private
           */
          function _onAction1()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Issuer Details"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                // We're assuming this is what runs after the server call is performed
                // We'd probably need to loop through a response from the server, and update
                // the _typeOptions array with new values. We're just going to hard code
                // those for now.
                _typeOptions = [{'text': 'GSTIN of User', 'value': 'gstin'}, {'text': 'Place of Business', 'value': 'companyId'}];

                // re-build the dialog
                _dialog.redial(_getDialogConfig("Issuer Details"));

                // unblock the dialog
                _dialog.unblock();

              },100);
          }

          function _onAction2()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Transaction Info"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Supply Type', 'value': 'supplyType'}, {'text': 'Nature of Transaction', 'value': 'ntr'}, {'text': 'Invoice type', 'value': 'catg'}, {'text': 'Transaction Mode', 'value': 'trnTyp'}, {'text': 'Reverse Charge', 'value': 'rchrg'}, {'text': 'Place of Supply', 'value': 'pos'}, {'text': 'E-commerce GSTIN', 'value': 'etin'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Transaction Info"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction3()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Document Info"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Document Type', 'value': 'docType'}, {'text': 'Document Status', 'value': 'dst'}, {'text': 'Document Number', 'value': 'no'}, {'text': 'Document Date', 'value': 'dt'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Document Info"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction4()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Invoice - Reference Fields"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Reference Invoice Number', 'value': 'refinum'}, {'text': 'Reference Invoice Date', 'value': 'refidt'}, {'text': 'Invoice Remarks', 'value': 'invRmk'}, {'text': 'Invoice period start date', 'value': 'invStDt'}, {'text': 'Invoice Period End date', 'value': 'invEndDt'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Invoice - Reference Fields"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction5()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Invoice - Extra Fields"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Differential percentage', 'value': 'diffprcnt'}, {'text': 'Original Month', 'value': 'omon'}, {'text': 'Original Document Type', 'value': 'odty'}, {'text': 'Original Invoice Type', 'value': 'oinvtyp'}, {'text': 'Original GSTIN/UIN Number', 'value': 'octin'}, {'text': 'Flag for Supply covered under sec 7 of IGST Act', 'value': 'sec7act'}, {'text': 'Supplier claiming refund', 'value': 'clmrfnd'}, {'text': 'Flag indicating whether document to be auto-populated to refunds', 'value': 'rfndelg'}, {'text': 'Supply to DTA on BOE', 'value': 'boef'}, {'text': 'Tax Scheme', 'value': 'taxSch'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Invoice - Extra Fields"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction6()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Supplier Details"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Supplier Gstin', 'value': 'sgstin'}, {'text': 'Supplier Trade Name', 'value': 'strdNm'}, {'text': 'Supplier Legal Name', 'value': 'slglNm'}, {'text': 'Supplier Address 1', 'value': 'sbnm'}, {'text': 'Supplier Address 2', 'value': 'sflno'}, {'text': 'Supplier Location', 'value': 'sloc'}, {'text': 'Supplier District', 'value': 'sdst'}, {'text': 'Supplier State code', 'value': 'sstcd'}, {'text': 'Supplier Pincode', 'value': 'spin'}, {'text': 'Supplier Phone or Mobile No.', 'value': 'sph'}, {'text': 'Supplier E-mail id', 'value': 'sem'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Supplier Details"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction7()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Buyer Details"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Buyer GSTIN', 'value': 'bgstin'}, {'text': 'Buyer Trade Name', 'value': 'btrdNm'}, {'text': 'Buyer Legal Name', 'value': 'blglNm'}, {'text': 'Buyer Address 1', 'value': 'bbnm'}, {'text': 'Buyer Address 2', 'value': 'bflno'}, {'text': 'Buyer Location', 'value': 'bloc'}, {'text': 'Buyer District', 'value': 'bdst'}, {'text': 'Buyer State code', 'value': 'bstcd'}, {'text': 'Buyer Pincode', 'value': 'bpin'}, {'text': 'Buyer Phone or Mobile No.', 'value': 'bph'}, {'text': 'Buyer E-mail id', 'value': 'bem'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Buyer Details"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction8()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Dispatch From Details"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Dispatch From GSTIN', 'value': 'dgstin'}, {'text': 'Dispatch From Trade Name', 'value': 'dtrdNm'}, {'text': 'Dispatch From Legal Name', 'value': 'dlglNm'}, {'text': 'Dispatch From Address 1', 'value': 'dbnm'}, {'text': 'Dispatch From Address 2', 'value': 'dflno'}, {'text': 'Dispatch From Location', 'value': 'dloc'}, {'text': 'Dispatch From District', 'value': 'ddst'}, {'text': 'Dispatch From State Code', 'value': 'dstcd'}, {'text': 'Dispatch From Pincode', 'value': 'dpin'}, {'text': 'Dispatch From Phone or Mobile No.', 'value': 'dph'}, {'text': 'Dispatch From E-mail id', 'value': 'dem'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Dispatch From Details"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction9()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Ship To Details"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Ship To GSTIN', 'value': 'togstin'}, {'text': 'Ship To Trade Name', 'value': 'totrdNm'}, {'text': 'Ship To Legal Name', 'value': 'tolglNm'}, {'text': 'Ship To Address 1', 'value': 'tobnm'}, {'text': 'Ship To Address 2', 'value': 'toflno'}, {'text': 'Ship To Location', 'value': 'toloc'}, {'text': 'Ship To District', 'value': 'todst'}, {'text': 'Ship To State Code', 'value': 'tostcd'}, {'text': 'Ship To Pincode', 'value': 'topin'}, {'text': 'Ship To Phone or Mobile No.', 'value': 'toph'}, {'text': 'Ship To E-mail id', 'value': 'toem'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Ship To Details"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction10()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Export Details"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Shipping Bill No.', 'value': 'sbnum'}, {'text': 'Shipping Bill Date', 'value': 'sbdt'}, {'text': 'Port Code', 'value': 'port'}, {'text': 'Country', 'value': 'cntcd'}, {'text': 'Foreign Currency', 'value': 'forCur'}, {'text': 'Total Invoice value in Foreign Currency', 'value': 'invForCur'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Export Details"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction11()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Invoice Totals"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Final Invoice value', 'value': 'totinvval'}, {'text': 'Discount on invoice value if any', 'value': 'totdisc'}, {'text': 'Freight', 'value': 'totfrt'}, {'text': 'Insurance', 'value': 'totins'}, {'text': 'Packaging and Forwarding', 'value': 'totpkg'}, {'text': 'Other charges if any', 'value': 'totothchrg'}, {'text': 'Total Assessable/ Taxable value of all items', 'value': 'tottxval'}, {'text': 'Total IGST value of all items', 'value': 'totiamt'}, {'text': 'Total CGST value of all items', 'value': 'totcamt'}, {'text': 'Total SGST value of all items', 'value': 'totsamt'}, {'text': 'Total CESS value of all items', 'value': 'totcsamt'}, {'text': 'Total State CESS value of all items', 'value': 'totstcsamt'}, {'text': 'Rounding off amount', 'value': 'rndOffAmt'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Invoice Totals"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction12()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Item Info - Extra"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Serial Number', 'value': 'num'}, {'text': 'Bar code', 'value': 'barcde'}, {'text': 'Batch number/name', 'value': 'bchnm'}, {'text': 'Expiry Date', 'value': 'bchExpDt'}, {'text': 'Warranty Date', 'value': 'bchWrDt'}, {'text': 'Pre tax value', 'value': 'preTaxVal'}, {'text': 'Order line referencee', 'value': 'ordLineRef'}, {'text': 'Orgin Country', 'value': 'orgCntry'}, {'text': 'Serial number in case of each item having a unique number.', 'value': 'prdSlNo'}, {'text': 'Attribute details of the item', 'value': 'attNm'}, {'text': 'Attribute value of the item', 'value': 'attVal'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Item Info - Extra"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction13()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Item Info - HSN"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Product Name', 'value': 'prdNm'}, {'text': 'Product Description', 'value': 'prdDesc'}, {'text': 'HSN code', 'value': 'hsnCd'}, {'text': 'Specify whether the supply is service or not', 'value': 'isServc'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Item Info - HSN"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction14()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Item Info - Core"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Quantity', 'value': 'qty'}, {'text': 'Free quantity', 'value': 'freeQty'}, {'text': 'Unit', 'value': 'unit'}, {'text': 'Unit Price', 'value': 'unitPrice'}, {'text': 'Total Amount', 'value': 'sval'}, {'text': 'Discount amount', 'value': 'disc'}, {'text': 'Other Charges', 'value': 'othchrg'}, {'text': 'Assessable Amount/ Taxable Value', 'value': 'txval'}, {'text': 'Total Item Value', 'value': 'itmVal'}, {'text': 'Tax applicability', 'value': 'txp'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Item Info - Core"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction15()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Item Info - Tax Rates"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Rate', 'value': 'rt'}, {'text': 'IGSTRate', 'value': 'irt'}, {'text': 'CGSTRate', 'value': 'crt'}, {'text': 'SGSTRate', 'value': 'srt'}, {'text': 'CESSRate', 'value': 'csrt'}, {'text': 'State CESS Rate', 'value': 'stcsrt'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Item Info - Tax Rates"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction16()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Item Info - Tax Amounts"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'IGST Amount as per item', 'value': 'iamt'}, {'text': 'CGST Amount as per item', 'value': 'camt'}, {'text': 'SGST Amount as per item', 'value': 'samt'}, {'text': 'CESS Amount as per item (Advolorem)', 'value': 'csamt'}, {'text': 'State cess amount as per item (Advalorem)', 'value': 'stcsamt'}, {'text': 'Cess Non-Advol Amount', 'value': 'cesNonAdval'}, {'text': 'State CESS Non advol Amount', 'value': 'stCesNonAdvl'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Item Info - Tax Amounts"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction17()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Payment Details"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Payee name', 'value': 'payNm'}, {'text': 'Bank account number of payee', 'value': 'acctdet'}, {'text': 'Mode of Payment', 'value': 'mode'}, {'text': 'Financial Institution Branch (IFSC Code)', 'value': 'ifsc'}, {'text': 'Terms of Payment', 'value': 'payTerm'}, {'text': 'Payment Instruction', 'value': 'payInstr'}, {'text': 'Credit Transfer', 'value': 'crTrn'}, {'text': 'Direct Debit', 'value': 'dirDr'}, {'text': 'Credit Days', 'value': 'crDay'}, {'text': 'Balance Amount to be paid', 'value': 'balAmt'}, {'text': 'Paid amount', 'value': 'paidAmt'}, {'text': 'Due Date of Payment', 'value': 'payDueDt'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Payment Details"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction18()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Transport Details"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Ewaybill no','value':'ewbNo'},{'text': 'Transporter ID', 'value': 'transId'}, {'text': 'Sub types of Supply', 'value': 'subSplyTyp'}, {'text': 'Other Sub Supply Description', 'value': 'subSplyDes'}, {'text': 'Reference Invoice Number in case of CKD/SKD', 'value': 'kdrefinum'}, {'text': 'Reference Invoice date in case of CKD/SKD', 'value': 'kdrefidt'}, {'text': 'Mode of transportation', 'value': 'transMode'}, {'text': 'Type of Vehicle', 'value': 'vehTyp'}, {'text': 'Distance of transportation (in Kms)', 'value': 'transDist'}, {'text': 'Transporter Name', 'value': 'transName'}, {'text': 'Transporter Document No.', 'value': 'transDocNo'}, {'text': 'Transporter Document Date', 'value': 'transDocDate'}, {'text': 'Vehicle No.', 'value': 'vehNo'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Transport Details"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction19()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("IRIS Generic Fields"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Generic Field 1', 'value': 'gen11'}, {'text': 'Generic Field 2', 'value': 'gen12'}, {'text': 'Generic Field 3', 'value': 'gen13'}, {'text': 'Generic Field 4', 'value': 'gen14'}, {'text': 'Generic Field 5', 'value': 'gen15'}, {'text': 'Generic Field 6', 'value': 'gen16'}, {'text': 'Generic Field 7', 'value': 'gen17'}, {'text': 'Generic Field 8', 'value': 'gen18'}, {'text': 'Generic Field 9', 'value': 'gen19'}, {'text': 'Generic Field 10', 'value': 'gen20'}, {'text': 'Generic Field 11', 'value': 'gen21'}, {'text': 'Generic Field 12', 'value': 'gen22'}, {'text': 'Generic Field 13', 'value': 'gen23'}, {'text': 'Generic Field 14', 'value': 'gen24'}, {'text': 'Generic Field 15', 'value': 'gen25'}, {'text': 'Generic Field 16', 'value': 'gen26'}, {'text': 'Generic Field 17', 'value': 'gen27'}, {'text': 'Generic Field 18', 'value': 'gen28'}, {'text': 'Generic Field 19', 'value': 'gen29'}, {'text': 'Generic Field 20', 'value': 'gen30'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("IRIS Generic Fields"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction20()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("IRIS Additional Fields"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Fiscal Year', 'value': 'fy'}, {'text': 'Internal Reference Document number', 'value': 'refnum'}, {'text': 'Posting date', 'value': 'pdt'}, {'text': 'Invoice status', 'value': 'ivst'}, {'text': 'Internal Counterparty Code', 'value': 'cptycde'}, {'text': 'Area code', 'value': 'gen1'}, {'text': 'Plant code', 'value': 'gen2'}, {'text': 'Project Reference Code', 'value': 'gen3'}, {'text': 'Department Code', 'value': 'gen4'}, {'text': 'Division Code', 'value': 'gen5'}, {'text': 'Cost Center', 'value': 'gen6'}, {'text': 'Branch Code', 'value': 'gen7'}, {'text': 'User Name', 'value': 'gen8'}, {'text': 'Transaction Category', 'value': 'gen9'}, {'text': 'GL Code', 'value': 'gen10'}];
                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("IRIS Additional Fields"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction21()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("E-invoicing Fields"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'IRN No.', 'value': 'irn'}, {'text': 'IRN Status', 'value': 'irnStatus'}, {'text': 'Acknowledgement date', 'value': 'ackDt'}, {'text': 'Acknowledgement FY', 'value': 'ackFinYear'}, {'text': 'Acknowledgement month', 'value': 'ackMonth'}, {'text': 'Acknowledgement no', 'value': 'ackNo'}, {'text': 'Cancel Date', 'value': 'cancelledDate'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("E-invoicing Fields"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction22()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Item Info - Generic Fields"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Item Level Generic Field 1', 'value': 'itmgen1'}, {'text': 'Item Level Generic Field 2', 'value': 'itmgen2'}, {'text': 'Item Level Generic Field 3', 'value': 'itmgen3'}, {'text': 'Item Level Generic Field 4', 'value': 'itmgen4'}, {'text': 'Item Level Generic Field 5', 'value': 'itmgen5'}, {'text': 'Item Level Generic Field 6', 'value': 'itmgen6'}, {'text': 'Item Level Generic Field 7', 'value': 'itmgen7'}, {'text': 'Item Level Generic Field 8', 'value': 'itmgen8'}, {'text': 'Item Level Generic Field 9', 'value': 'itmgen9'}, {'text': 'Item Level Generic Field 10', 'value': 'itmgen10'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Item Info - Generic Fields"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction23()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Invoice - Reference Details-Preceding"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Preceding Invoice Number', 'value': 'oinum'}, {'text': 'Preceding Invoice Date', 'value': 'oidt'}, {'text': 'Other Reference', 'value': 'othRefNo'}];

                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Invoice - Reference Details-Preceding"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction24()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Invoice - Reference Details-Contract"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Receipt Advice No.', 'value': 'raref'}, {'text': 'Receipt Advice Date', 'value': 'radt'}, {'text': 'Lot/Batch Reference No.', 'value': 'tendref'}, {'text': 'Contract Reference Number', 'value': 'contref'}, {'text': 'Any other reference', 'value': 'extref'}, {'text': 'Project Reference Number', 'value': 'projref'}, {'text': 'Vendor PO Reference Number', 'value': 'poref'}, {'text': 'Vendor PO Reference date', 'value': 'porefdt'}];
                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Invoice - Reference Details-Contract"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onAction25()
          {
              // Open a Dialog, and update the dialog instance var
              _dialog = editor.windowManager.open(_getDialogConfig("Invoice - Additional Document Details"));

              // block the Dialog, and commence the data update
              // Message is used for accessibility
              _dialog.block('Loading...');

              // Do a server call to get the items for the select box
              // We'll pretend using a setTimeout call
              setTimeout(function () {

                  // We're assuming this is what runs after the server call is performed
                  // We'd probably need to loop through a response from the server, and update
                  // the _typeOptions array with new values. We're just going to hard code
                  // those for now.
                  _typeOptions = [{'text': 'Supporting document URL', 'value': 'url'}, {'text': 'Supporting document', 'value': 'docs'}, {'text': 'Any additional Info', 'value': 'infoDtls'}];
                  // re-build the dialog
                  _dialog.redial(_getDialogConfig("Invoice - Additional Document Details"));

                  // unblock the dialog
                  _dialog.unblock();

              },100);
          }

          function _onMarkAction(){
            // editor.focus();
            var select = tinymce.activeEditor.selection.getNode();
            var parent = tinymce.DOM.getParent(select, 'tr');
            if (tinymce.DOM.hasClass(parent, 'repeat')) {
              alert("Unmarking Repeatable Item");
              tinymce.activeEditor.dom.removeClass(parent, 'repeat');
            } else {
              alert("Marking Repeatable Item");
              tinymce.activeEditor.dom.addClass(parent, 'repeat');
            }

          }

          function _addHeaderAction() {
            var select = tinymce.activeEditor.selection.getNode();
            if (tinymce.DOM.hasClass(select, 'header')) {
              alert("Unmarking header Item");
              tinymce.activeEditor.dom.removeClass(select, 'header');
            } else {
              alert("Marking header Item");
              tinymce.activeEditor.dom.addClass(select, 'header');
            }
          }

          function _addHSNGroupAction() {
            var select1 = tinymce.activeEditor.selection.getNode();
            var select = tinymce.DOM.getParent(select1, 'tr');
            if (tinymce.DOM.hasClass(select, 'hsn-group')) {
              alert("Unmarking hsn-group Item");
              tinymce.activeEditor.dom.removeClass(select, 'hsn-group');
            } else {
              alert("Marking hsn-group Item");
              tinymce.activeEditor.dom.addClass(select, 'hsn-group');
            }
          }

          function _addTaxSummaryAction() {
            var select = tinymce.activeEditor.selection.getNode();
            var parent = tinymce.DOM.getParent(select, 'tr');
            if (tinymce.DOM.hasClass(parent, 'tax-summary')) {
              alert("Unmarking Tax Summary Item");
              tinymce.activeEditor.dom.removeClass(parent, 'tax-summary');
            } else {
              alert("Marking Tax Summary Item");
              tinymce.activeEditor.dom.addClass(parent, 'tax-summary');
            }
          }

          function _addQRAction() {
            editor.insertContent("<img src='data:image/png;base64,${qrcode}' alt='EINV QRCODE' width='100' height='100' />");
          }
          function _addBarCodeAction(field) {
            var toBeInserted = "<img id='" + field + "' class='barcode' src='barcode' alt='EINV " + field + " BARCODE' width='100' height='100'/>";
            editor.insertContent(toBeInserted);
          }
          function _addNicLogoAction(field) {
            var toBeInserted = "<div id='niclogo' style='text-align: right;'>"+ field +"</div>";
            editor.insertContent(toBeInserted);
          }
          function _addQRCodeAction(field) {
            var toBeInserted = "<img id='" + field + "' class='qrcode' src='qrcode' alt='EINV " + field + " QRCODE' width='100' height='100'/>";
            editor.insertContent(toBeInserted);
          }
          // Define the Toolbar button

          // editor.ui.registry.addButton('build', {
          //     text: "Invoice",
          //     icon: 'build',
          //     onAction: _onAction
          // });

          // Define the Menu Item
          editor.ui.registry.addNestedMenuItem('inputformat', {
            text: 'Input Format Category',
            icon: 'build',
            getSubmenuItems: () => {
              return [{
                type: 'menuitem',
                text: 'Issuer Details',
                icon: 'printshop',
                onAction: _onAction1
              },
              {
                type: 'menuitem',
                text: 'Transaction Info',
                icon: 'work',
                onAction: _onAction2
              },
              {
                type: 'menuitem',
                text: 'Document Info',
                icon: 'description',
                onAction: _onAction3
              },
              {
                type: 'menuitem',
                text: 'Invoice - Reference Fields',
                icon: 'link',
                onAction: _onAction4
              },
              {
                type: 'menuitem',
                text: 'Invoice - Extra Fields',
                icon: 'post_add',
                onAction: _onAction5
              },
              {
                type: 'menuitem',
                text: 'Supplier Details',
                icon: 'contacts',
                onAction: _onAction6
              },
              {
                type: 'menuitem',
                text: 'Buyer Details',
                icon: 'assignment',
                onAction: _onAction7
              },
              {
                type: 'menuitem',
                text: 'Dispatch From Details',
                icon: 'room',
                onAction: _onAction8
              },
              {
                type: 'menuitem',
                text: 'Ship To Details',
                icon: 'local_grocery',
                onAction: _onAction9
              },
              {
                type: 'menuitem',
                text: 'Export Details',
                icon: 'swap_vertical',
                onAction: _onAction10
              },
              {
                type: 'menuitem',
                text: 'Invoice Totals',
                icon: 'receipt',
                onAction: _onAction11
              },
              {
                type: 'menuitem',
                text: 'Item Info - Extra',
                icon: 'arrow_down',
                onAction: _onAction12
              },
              {
                type: 'menuitem',
                text: 'Item Info - HSN',
                icon: 'info',
                onAction: _onAction13
              },
              {
                type: 'menuitem',
                text: 'Item Info - Core',
                icon: 'format_list',
                onAction: _onAction14
              },
              {
                type: 'menuitem',
                text: 'Item Info - Tax Rates',
                icon: 'star',
                onAction: _onAction15
              },
              {
                type: 'menuitem',
                text: 'Item Info - Tax Amounts',
                icon: 'dollar',
                onAction: _onAction16
              },
              {
                type: 'menuitem',
                text: 'Payment Details',
                icon: 'account',
                onAction: _onAction17
              },
              {
                type: 'menuitem',
                text: 'Transport Details',
                icon: 'shipping',
                onAction: _onAction18
              },
              {
                type: 'menuitem',
                text: 'IRIS Generic Fields',
                icon: 'menu',
                onAction: _onAction19
              },
              {
                type: 'menuitem',
                text: 'IRIS Additional Fields',
                icon: 'style',
                onAction: _onAction20
              },
              {
                type: 'menuitem',
                text: 'E-invoicing Fields',
                icon: 'description',
                onAction: _onAction21
              },
              {
                type: 'menuitem',
                text: 'Item Info - Generic Fields',
                icon: 'menuBook',
                onAction: _onAction22
              },
              {
                type: 'menuitem',
                text: 'Invoice - Reference Details-Preceding',
                icon: 'sort',
                onAction: _onAction23
              },
              {
                type: 'menuitem',
                text: 'Invoice - Reference Details-Contract',
                icon: 'addBox',
                onAction: _onAction24
              },
              {
                type: 'menuitem',
                text: 'Invoice - Additional Document Details',
                icon: 'filter',
                onAction: _onAction25
              },

            ];
            }
          });

          editor.ui.registry.addMenuItem('mark', {
            text: "Mark Repeatable",
            icon: 'mark',
            onAction: _onMarkAction
          });

          editor.ui.registry.addMenuItem('addHeader', {
            text: 'Add a header',
            context: 'insert',
            icon: 'mark',
            onAction: _addHeaderAction
        });

          editor.ui.registry.addMenuItem('addQRCodePlaceholder', {
            text: 'Add IRN QRCode Placeholder',
            context: 'insert',
            icon: 'mark',
            onAction: _addQRAction
          });

          editor.ui.registry.addMenuItem('taxSummary', {
            text: 'Mark Tax Summary',
            context: 'insert',
            icon: 'mark',
            onAction: _addTaxSummaryAction
          });

          editor.ui.registry.addMenuItem("hsnGroupSummary", {
            text: "HSN code summary with tax",
            context: "insert",
            icon: "mark",
            onAction: function () {
                var e = tinymce.activeEditor.selection.getNode(),
                    t = tinymce.DOM.getParent(e, "tr");
                tinymce.DOM.hasClass(t, "hsntax-group")
                    ? (alert("Unmarking Tax Summary Item"), tinymce.activeEditor.dom.removeClass(t, "hsntax-group"))
                    : (alert("Marking Tax Summary Item"), tinymce.activeEditor.dom.addClass(t, "hsntax-group"));
            },
        }),
        editor.ui.registry.addMenuItem("cessSummary", {
            text: "Mark Cess Tax Summary",
            context: "insert",
            icon: "mark",
            onAction: function () {
                var e = tinymce.activeEditor.selection.getNode(),
                    t = tinymce.DOM.getParent(e, "tr");
                tinymce.DOM.hasClass(t, "cess-tax-summary")
                    ? (alert("Unmarking Cess Tax Summary Item"), tinymce.activeEditor.dom.removeClass(t, "cess-tax-summary"))
                    : (alert("Marking Cess Tax Summary Item"), tinymce.activeEditor.dom.addClass(t, "cess-tax-summary"));
            },
        }),

          editor.ui.registry.addMenuItem('group', {
            text: 'Mark HSN Group',
            context: 'insert',
            icon: 'mark',
            onAction: _addHSNGroupAction
          });

          editor.ui.registry.addNestedMenuItem("formula", {
            text: "Mark/Unmark Formula",
            icon: "build",
            getSubmenuItems: () => [
                {
                    type: "menuitem",
                    text: "Mark",
                    icon: "mark",
                    onAction: () =>
                        (function () {
                            var e = tinymce.activeEditor.selection.getNode(),
                                t = tinymce.activeEditor.selection.getContent({ format: "text" }).toString().split("=");
                            e.setAttribute("id", t[1]), tinymce.activeEditor.selection.setContent(t[0]);
                            var n = tinymce.DOM.getParent(e, "tr");
                            tinymce.DOM.hasClass(n, "repeat")
                                ? (alert("Marking repeat formula"), tinymce.activeEditor.dom.removeClass(e, "formula"), tinymce.activeEditor.dom.addClass(e, "repeat-formula"))
                                : (alert("Marking formula"), tinymce.activeEditor.dom.removeClass(e, "repeat-formula"), tinymce.activeEditor.dom.addClass(e, "formula"));
                        })(),
                },
                {
                    type: "menuitem",
                    text: "Unmark",
                    icon: "mark",
                    onAction: () =>
                        (function () {
                            var e = tinymce.activeEditor.selection.getNode();
                            tinymce.activeEditor.dom.removeClass(e, "formula"), tinymce.activeEditor.dom.removeClass(e, "repeat-formula"), alert("Cleared formula");
                        })(),
                },
            ],
        }),

          editor.ui.registry.addMenuItem('nicLogo', {
            text: 'NIC Logo Placeholder',
            context: 'insert',
            icon: 'mark',
            onAction: () => _addNicLogoAction('NIC LOGO')
          });

          editor.ui.registry.addNestedMenuItem('barcode', {
            text: 'Add Custom BarCode Placeholder',
            icon: 'build',
            getSubmenuItems: () => {
              return [{
                type: 'menuitem',
                text: 'GSTIN',
                context: 'insert',
                icon: 'mark',
                onAction: () => _addBarCodeAction('gstin')
              },
              {
                type: 'menuitem',
                text: 'EWB',
                context: 'insert',
                icon: 'mark',
                onAction: () => _addBarCodeAction('ewbNo')
              },
            ]}
            });

          editor.ui.registry.addNestedMenuItem('qrCode', {
            text: 'Add Custom QRCode Placeholder',
            icon: 'build',
            getSubmenuItems: () => {
              return [{
                type: 'menuitem',
                text: 'GSTIN',
                context: 'insert',
                icon: 'mark',
                onAction: () => _addQRCodeAction('gstin')
              },
              {
                type: 'menuitem',
                text: 'EWB',
                context: 'insert',
                icon: 'mark',
                onAction: () => _addQRCodeAction('ewbNo')
              },
            ]}
            });

          // Return details to be displayed in TinyMCE's "Help" plugin, if you use it
          // This is optional.
          return {
              getMetadata: function () {
                  return {
                      name: "Custom IRIS Invoice Template Field Mapping",
                      url: "https://irisgst.com"
                  };
              }
          };
      });
  }());
})();
